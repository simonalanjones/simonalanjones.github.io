import pygame
import math
import sys

# Game state control
STATE_START = 0
STATE_PLAY = 10
STATE_END = 20

gameState = STATE_START

SCREEN_MAX_X = 800
SCREEN_MAX_Y = 600

playerShip = {
    "position": {"x": 100, "y": 60},
    "velocity": {"speed": 0, "direction": 0},
    "acceleration": 1,
    "rotation": 0,
    "rotationSpeed": 0.07,
    "thrust_power": 0.2,
    "max_speed": 7,
    "friction": 0.99,
}

pygame.init()
screen = pygame.display.set_mode((SCREEN_MAX_X, SCREEN_MAX_Y))
clock = pygame.time.Clock()

# Load the player ship sprite
player_ship_image = pygame.image.load("graphics/ship.png")
player_ship_rect = player_ship_image.get_rect(
    center=(playerShip["position"]["x"], playerShip["position"]["y"])
)


def rotate_image(image, angle):
    return pygame.transform.rotate(image, -math.degrees(angle))


def check_player_buttons():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        playerShip["rotation"] -= playerShip["rotationSpeed"]
    if keys[pygame.K_RIGHT]:
        playerShip["rotation"] += playerShip["rotationSpeed"]
    playerShip["rotation"] = keep_angle_in_range(playerShip["rotation"])


def keep_angle_in_range(angle):
    while angle < 0:
        angle += 2 * math.pi
    while angle > 2 * math.pi:
        angle -= 2 * math.pi
    return angle


def move_point_by_velocity(object):
    components = get_vector_components(object["velocity"])
    new_position = {
        "x": object["position"]["x"] + components["xComp"],
        "y": object["position"]["y"] + components["yComp"],
    }
    return new_position


def move_player_ship():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        player_ship_thrust()
    playerShip["velocity"]["speed"] *= playerShip["friction"]
    if playerShip["velocity"]["speed"] < 0.01:
        playerShip["velocity"]["speed"] = 0
    playerShip["position"] = move_point_by_velocity(playerShip)
    playerShip["position"] = wrap_position(playerShip["position"])


def player_ship_thrust():
    thrust_force = {
        "speed": playerShip["thrust_power"],
        "direction": playerShip["rotation"]
        - (math.pi / 2),  # Subtracting 90 degrees in radians
    }
    new_velocity = add_vectors(playerShip["velocity"], thrust_force)
    if new_velocity["speed"] > playerShip["max_speed"]:
        new_velocity["speed"] = playerShip["max_speed"]
    playerShip["velocity"] = new_velocity


def add_vectors(vector1, vector2):
    v1Comp = get_vector_components(vector1)
    v2Comp = get_vector_components(vector2)
    resultant_x = v1Comp["xComp"] + v2Comp["xComp"]
    resultant_y = v1Comp["yComp"] + v2Comp["yComp"]
    return comp_to_vector(resultant_x, resultant_y)


def get_vector_components(vector):
    xComp = vector["speed"] * math.cos(vector["direction"])
    yComp = vector["speed"] * math.sin(vector["direction"])
    return {"xComp": xComp, "yComp": yComp}


def comp_to_vector(x, y):
    magnitude = math.sqrt((x * x) + (y * y))
    direction = math.atan2(y, x)
    direction = keep_angle_in_range(direction)
    return {"speed": magnitude, "direction": direction}


def wrap_position(position):
    if position["x"] >= SCREEN_MAX_X:
        position["x"] = 0
    elif position["x"] < 0:
        position["x"] = SCREEN_MAX_X - 1
    if position["y"] >= SCREEN_MAX_Y:
        position["y"] = 0
    elif position["y"] < 0:
        position["y"] = SCREEN_MAX_Y - 1
    return position


def do_start_screen():
    screen.fill((0, 0, 0))
    font = pygame.font.Font(None, 36)
    text = font.render("ASTEROIDS", True, (255, 255, 255))
    screen.blit(text, (80, 40))
    text = font.render("press Z to start", True, (255, 255, 255))
    screen.blit(text, (60, 60))
    pygame.display.flip()


def do_end_screen():
    screen.fill((0, 0, 0))
    font = pygame.font.Font(None, 36)
    text = font.render("GAME OVER", True, (255, 255, 255))
    screen.blit(text, (80, 40))
    text = font.render("press Z to start", True, (255, 255, 255))
    screen.blit(text, (60, 60))
    pygame.display.flip()


def do_play_game():
    screen.fill((0, 0, 0))
    check_player_buttons()
    move_player_ship()

    # Rotate and draw the player ship sprite
    rotated_ship_image = rotate_image(player_ship_image, playerShip["rotation"])
    player_ship_rect = rotated_ship_image.get_rect(
        center=(playerShip["position"]["x"], playerShip["position"]["y"])
    )
    screen.blit(rotated_ship_image, player_ship_rect.topleft)

    pygame.display.flip()


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_z:
                if gameState == STATE_START or gameState == STATE_END:
                    gameState = STATE_PLAY
                elif gameState == STATE_PLAY:
                    gameState = STATE_END

    if gameState == STATE_START:
        do_start_screen()
    elif gameState == STATE_PLAY:
        do_play_game()
    elif gameState == STATE_END:
        do_end_screen()

    clock.tick(60)
