from noise import pnoise1
from typing import List
import pygame
import sys
from pytmx.util_pygame import load_pygame
import math
import pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 1280, 720
GRAVITY = 0.02
# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Camera System")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

player_pos = [400, 4000]
player_speed = 5
player_size = 50


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class LayerManager:
    def __init__(self, tmx_file, layer_names, tile_size=128):
        self.tmx_data = load_pygame(tmx_file)
        self.layer_names = layer_names
        self.tile_size = tile_size
        self.tile_layers = {name: pygame.sprite.Group() for name in layer_names}
        self.quadtrees = {}
        self.world_width, self.world_height = self._initialize_layers()
        self.cache = {name: {"rect": None, "sprites": None} for name in layer_names}

    def _initialize_layers(self):
        max_x, max_y = 0, 0
        for layer in self.tmx_data.visible_layers:
            if layer.name in self.layer_names:
                for x, y, surf in layer.tiles():
                    pos = (x * self.tile_size, y * self.tile_size)
                    Tile(pos=pos, surf=surf, groups=self.tile_layers[layer.name])
                    if x > max_x:
                        max_x = x
                    if y > max_y:
                        max_y = y

        world_width = (max_x + 1) * self.tile_size
        world_height = (max_y + 1) * self.tile_size

        for name in self.layer_names:
            boundary = pygame.Rect(0, 0, world_width, world_height)

            self.quadtrees[name] = Quadtree(boundary, 4)

            sprite_group = pygame.sprite.Group()
            for sprite in self.tile_layers[name]:
                sprite_group.add(sprite)
            self.quadtrees[name].insert_group(sprite_group)

        return world_width, world_height

    def get_visible_foreground_sprites(self):
        foreground_layer = self.layer_names[0]
        foreground_sprites = self.get_last_query_sprites(foreground_layer)
        return foreground_sprites

    def get_last_query_sprites(self, layer_name: str) -> List[pygame.sprite.Sprite]:
        cached_data = self.cache[layer_name]
        if cached_data["sprites"] is not None:
            return cached_data["sprites"]
        else:
            query_rect = pygame.Rect(0, 0, self.world_width, self.world_height)
            return self.query_visible_sprites(layer_name, query_rect)

    def query_visible_sprites(
        self, layer_name: str, query_rect: pygame.Rect
    ) -> List[pygame.sprite.Sprite]:
        cached_data = self.cache[layer_name]
        if cached_data["rect"] == query_rect:
            return cached_data["sprites"]

        visible_sprites = self.quadtrees[layer_name].query(query_rect)
        self.cache[layer_name] = {"rect": query_rect, "sprites": visible_sprites}
        return visible_sprites

    def get_cached_sprites(self, layer_name: str) -> List[pygame.sprite.Sprite]:
        """Returns the cached sprites for a layer, if available."""
        return (
            self.cache[layer_name]["sprites"]
            if self.cache[layer_name]["sprites"]
            else []
        )

    def get_sprites_around_sprite(
        self, layer_name: str, sprite: pygame.sprite.Sprite, padding: int = 200
    ) -> List[pygame.sprite.Sprite]:
        """
        Returns sprites from a specific layer around a given sprite, using a padded rectangle for the query.
        """
        query_rect = sprite.rect.inflate(padding, padding)
        return self.query_visible_sprites(layer_name, query_rect)

    def get_world_dimensions(self):
        return self.world_width, self.world_height


class Quadtree:
    def __init__(self, boundary, capacity):
        self.boundary = boundary
        self.capacity = capacity
        self.tiles = []
        self.divided = False

    def count_tiles(self):
        count = len(self.tiles)
        if self.divided:
            count += self.northeast.count_tiles()
            count += self.northwest.count_tiles()
            count += self.southeast.count_tiles()
            count += self.southwest.count_tiles()
        return count

    def subdivide(self):
        x, y, w, h = self.boundary
        half_w, half_h = w // 2, h // 2

        self.northeast = Quadtree(
            pygame.Rect(x + half_w, y, half_w, half_h), self.capacity
        )
        self.northwest = Quadtree(pygame.Rect(x, y, half_w, half_h), self.capacity)
        self.southeast = Quadtree(
            pygame.Rect(x + half_w, y + half_h, half_w, half_h), self.capacity
        )
        self.southwest = Quadtree(
            pygame.Rect(x, y + half_h, half_w, half_h), self.capacity
        )

        self.divided = True

    def insert_group(self, sprite_group):
        for sprite in sprite_group:
            self.insert(sprite)

    def insert(self, tile):
        if not self.boundary.colliderect(tile.rect):
            return False

        if len(self.tiles) < self.capacity:
            self.tiles.append(tile)
            return True
        else:
            if not self.divided:
                self.subdivide()

            if self.northeast.insert(tile):
                return True
            if self.northwest.insert(tile):
                return True
            if self.southeast.insert(tile):
                return True
            if self.southwest.insert(tile):
                return True

    def query(self, range, found=None):
        if found is None:
            found = []

        if not self.boundary.colliderect(range):
            return found

        for tile in self.tiles:
            if range.colliderect(tile.rect):
                found.append(tile)

        if self.divided:
            self.northeast.query(range, found)
            self.northwest.query(range, found)
            self.southeast.query(range, found)
            self.southwest.query(range, found)

        return found

    def draw(self, surface, offset):
        adjusted_boundary = self.boundary.move(-offset.x, -offset.y)
        pygame.draw.rect(surface, GREEN, adjusted_boundary, 1)

        if self.divided:
            self.northeast.draw(surface, offset)
            self.northwest.draw(surface, offset)
            self.southeast.draw(surface, offset)
            self.southwest.draw(surface, offset)


class Camera:
    def __init__(
        self,
        width,
        height,
        initial_pos,
        world_width,
        world_height,
        smoothing_enabled=True,
        smoothing_speed=0.1,
    ):
        self.camera = pygame.Rect(initial_pos[0], initial_pos[1], width, height)
        self.width = width
        self.height = height
        self.world_width = world_width
        self.world_height = world_height
        self.smoothing_enabled = smoothing_enabled
        self.smoothing_speed = smoothing_speed

        self.camera_margin_x = 150
        self.camera_margin_y = 100
        self.camera_speed = 5

    def apply(self, entity, speed_factor=1):
        x = math.floor(self.camera.x * speed_factor)
        y = math.floor(self.camera.y * speed_factor)

        # print(f"Entity position after camera apply: ({x}, {y})")
        return entity.rect.move(-x, -y)

    def update(self, target):
        target_x = target.rect.centerx
        target_y = target.rect.centery

        camera_left_margin = self.camera.x + self.camera_margin_x
        camera_right_margin = self.camera.x + self.width - self.camera_margin_x
        camera_top_margin = self.camera.y + self.camera_margin_y
        camera_bottom_margin = self.camera.y + self.height - self.camera_margin_y

        desired_x = self.camera.x
        desired_y = self.camera.y

        if target_x < camera_left_margin:
            desired_x = target_x - self.camera_margin_x
        elif target_x > camera_right_margin:
            desired_x = target_x - self.width + self.camera_margin_x

        if target_y < camera_top_margin:
            desired_y = target_y - self.camera_margin_y
        elif target_y > camera_bottom_margin:
            desired_y = target_y - self.height + self.camera_margin_y

        desired_x = max(0, min(desired_x, self.world_width - self.width))
        desired_y = max(0, min(desired_y, self.world_height - self.height))

        # Use math.floor to ensure positions are rounded down to nearest integer
        if self.smoothing_enabled:
            self.camera.x += math.floor(
                (desired_x - self.camera.x) * self.smoothing_speed
            )
            self.camera.y += math.floor(
                (desired_y - self.camera.y) * self.smoothing_speed
            )
        else:
            self.camera.x = desired_x
            self.camera.y = desired_y

        self.camera.x = self.camera.x
        self.camera.y = self.camera.y


class PhysicsObject(pygame.sprite.Sprite):
    def __init__(
        self,
        position,
        velocity,
        acceleration,
        rotation,
        rotationSpeed,
        max_speed,
        friction,
        mass,
    ):
        super().__init__()
        self.position = position
        self.velocity = velocity
        self.acceleration = acceleration
        self.rotation = rotation
        self.rotationSpeed = rotationSpeed
        self.max_speed = max_speed
        self.friction = friction
        self.mass = mass
        self.image = None
        self.rect = None
        self.hit_rect = None

    def update_physics(self):
        self.apply_gravity()
        self.velocity["speed"] *= self.friction
        if self.velocity["speed"] < 0.01:
            self.velocity["speed"] = 0
        self.move_point_by_velocity()
        self.rotate_image()

    def apply_gravity(self):
        vertical_velocity = self.velocity["speed"] * math.sin(
            self.velocity["direction"]
        )
        vertical_velocity += GRAVITY / self.mass
        self.velocity = self.comp_to_vector(
            self.velocity["speed"] * math.cos(self.velocity["direction"]),
            vertical_velocity,
        )

    def move_point_by_velocity(self):
        components = self.get_vector_components(self.velocity)
        self.position["x"] += components["xComp"]
        self.position["y"] += components["yComp"]

    def rotate_image(self):
        if self.image:
            self.image = pygame.transform.rotate(
                self.original_image, -math.degrees(self.rotation)
            )
            self.rect = self.image.get_rect(
                center=(self.position["x"], self.position["y"])
            )
            self.hit_rect.center = self.rect.center

    def keep_angle_in_range(self, angle):
        while angle < 0:
            angle += 2 * math.pi
        while angle > 2 * math.pi:
            angle -= 2 * math.pi
        return angle

    def add_vectors(self, vector1, vector2):
        v1Comp = self.get_vector_components(vector1)
        v2Comp = self.get_vector_components(vector2)
        resultant_x = v1Comp["xComp"] + v2Comp["xComp"]
        resultant_y = v1Comp["yComp"] + v2Comp["yComp"]
        return self.comp_to_vector(resultant_x, resultant_y)

    def get_vector_components(self, vector):
        xComp = vector["speed"] * math.cos(vector["direction"])
        yComp = vector["speed"] * math.sin(vector["direction"])
        return {"xComp": xComp, "yComp": yComp}

    def comp_to_vector(self, x, y):
        magnitude = math.sqrt((x * x) + (y * y))
        direction = math.atan2(y, x)
        direction = self.keep_angle_in_range(direction)
        return {"speed": magnitude, "direction": direction}


class Player(PhysicsObject):
    def __init__(self):
        position = {"x": 320, "y": 200}
        velocity = {"speed": 0, "direction": 0}
        acceleration = 1
        rotation = 0
        rotationSpeed = 0.07
        max_speed = 7
        friction = 0.99
        mass = 1
        super().__init__(
            position,
            velocity,
            acceleration,
            rotation,
            rotationSpeed,
            max_speed,
            friction,
            mass,
        )

        self.thrust_power = 0.2
        self.image = pygame.image.load("graphics/ship.png")
        self.original_image = self.image
        self.rect = self.image.get_rect(center=(self.position["x"], self.position["y"]))
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        self.hit_rect.center = self.rect.center

        self.landed = False
        self.landing_max_velocity = 3
        self.landing_rotation_left_threshold = 24
        self.landing_rotation_right_threshold = 340
        self.landing_tile_position_threshold = 20

    def check_landing_velocity_and_rotation(self):
        if self.vy < self.landing_max_velocity and (
            self.rotation < self.landing_rotation_left_threshold
            or self.rotation > self.landing_rotation_right_threshold
        ):
            return True
        else:
            return False

    def land_ship(self):
        self.vx = 0
        self.vy = 0
        self.landed = True
        self.rotation = 0

    def get_total_collision_rect(self, sprite_group):
        # Might be landing between two sprites
        # Calculate the bounding box of the combined area covered by all (usually max two) sprites in the group
        left = min(sprite.rect.left for sprite in sprite_group)
        top = min(sprite.rect.top for sprite in sprite_group)
        right = max(sprite.rect.right for sprite in sprite_group)
        bottom = max(sprite.rect.bottom for sprite in sprite_group)

        # amount to add to either side of the tile collision group
        tolerance = self.landing_tile_position_threshold

        combined_rect = pygame.Rect(
            left - tolerance,
            top,
            right - left + tolerance * 2,  # Add tolerance to both left and right sides
            bottom - top,
        )
        return combined_rect

    def can_land_on_rect(self, total_collision_rect):
        # Check if the player is within the horizontal bounds of the combined area
        if (
            self.rect.bottom < total_collision_rect.centery
            and self.rect.left > total_collision_rect.left
            and self.rect.right < total_collision_rect.right
        ):
            return True
        return False

    def collision_direction_word(self, tile):
        collision = pygame.sprite.collide_rect(self, tile)
        if collision:
            player_rect = self.rect
            tile_rect = tile.rect

            player_center_x = player_rect.centerx
            player_center_y = player_rect.centery
            tile_center_x = tile_rect.centerx
            tile_center_y = tile_rect.centery

            dx = player_center_x - tile_center_x
            dy = player_center_y - tile_center_y

            if abs(dx) > abs(dy):
                if dx < 0:
                    return "right"
                else:
                    return "left"
            else:
                if dy < 0:
                    return "bottom"
                else:
                    return "top"

    def check_collisions(self, sprite_group):
        if not self.landed:
            hits = pygame.sprite.spritecollide(
                self, sprite_group, False, self.collide_hit_rect
            )
            if hits:
                sprite = hits[0]
                collision_word = self.collision_direction_word(sprite)
                print(collision_word)
                # Bounce away, reduce velocity, and reposition
                self.bounce_away(collision_word, sprite)

    def bounce_away(self, collision_word, colliding_object):
        # Calculate the bounce amount
        bounce_amount = 5

        # Reduce velocity by half
        self.velocity["speed"] *= 0.5

        # Adjust the player's position based on the collision direction
        if collision_word == "bottom":
            self.position["y"] = (
                colliding_object.rect.top - bounce_amount - self.rect.height / 2
            )
        elif collision_word == "top":
            self.position["y"] = (
                colliding_object.rect.bottom + bounce_amount + self.rect.height / 2
            )
        elif collision_word == "right":
            self.position["x"] = (
                colliding_object.rect.left - bounce_amount - self.rect.width / 2
            )
        elif collision_word == "left":
            self.position["x"] = (
                colliding_object.rect.right + bounce_amount + self.rect.width / 2
            )

        # Reflect the velocity vector against the normal vector of the collision surface
        if collision_word == "bottom" or collision_word == "top":
            normal_vector = (0, 1 if collision_word == "bottom" else -1)
        else:
            normal_vector = (1 if collision_word == "right" else -1, 0)

        # Calculate velocity components
        vx = self.velocity["speed"] * math.cos(self.velocity["direction"])
        vy = self.velocity["speed"] * math.sin(self.velocity["direction"])

        # Reflect the velocity components
        vx, vy = self.reflect_vector((vx, vy), normal_vector)

        # Convert back to speed and direction
        self.velocity = self.comp_to_vector(vx, vy)

        # Update rect and hit_rect
        self.rect.center = (self.position["x"], self.position["y"])
        self.hit_rect.center = self.rect.center

    def reflect_vector(self, velocity, normal):
        dot_product = velocity[0] * normal[0] + velocity[1] * normal[1]
        reflected = (
            velocity[0] - 2 * dot_product * normal[0],
            velocity[1] - 2 * dot_product * normal[1],
        )
        return reflected

    # move this to base object
    def reduce_velocity_by_half(self):
        self.velocity["speed"] *= 0.5

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def update(self):
        self.update_physics()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rotation -= self.rotationSpeed
        if keys[pygame.K_RIGHT]:
            self.rotation += self.rotationSpeed
        self.rotation = self.keep_angle_in_range(self.rotation)
        if keys[pygame.K_UP]:
            self.thrust()
        self.vx = self.velocity["speed"] * math.cos(self.velocity["direction"])
        self.vy = self.velocity["speed"] * math.sin(self.velocity["direction"])

    def thrust(self):
        thrust_force = {
            "speed": self.thrust_power / self.mass,
            "direction": self.rotation - (math.pi / 2),
        }
        new_velocity = self.add_vectors(self.velocity, thrust_force)
        if new_velocity["speed"] > self.max_speed:
            new_velocity["speed"] = self.max_speed
        self.velocity = new_velocity


class Viewport:
    def __init__(
        self, x, y, width, height, camera, layer_manager, border_color=(0, 0, 0)
    ):
        self.rect = pygame.Rect(x, y, width, height)
        self.set_camera(camera)

        self.layer_manager = layer_manager
        self.border_color = border_color

        # Shake parameters
        self.shake_intensity = 0
        self.shake_duration = 0
        self.shake_timer = 0
        self.shake_offset = pygame.Vector2(0, 0)
        self.rotation_intensity = 0
        self.rotation_offset = 0

        # Perlin noise parameters
        self.noise_base_x = 0
        self.noise_base_y = (
            1000  # Separate base to ensure different noise patterns for x and y
        )
        self.noise_step = 0.1  # Step size for each frame

    def get_foreground_sprites(self):
        return self.layer_manager.get_visible_foreground_sprites()

    def sprites_around_player(self, sprite):
        return self.layer_manager.get_sprites_around_sprite("foreground", sprite)

    def set_camera(self, camera):
        if isinstance(camera, Camera):
            self.camera = camera

    def get_query_rect(self, speed_factor):
        query_rect = pygame.Rect(
            round(self.camera.camera.x * speed_factor),
            round(self.camera.camera.y * speed_factor),
            self.camera.camera.width,
            self.camera.camera.height,
        )
        tile_size = 128
        query_rect = query_rect.inflate(tile_size * 2, tile_size * 2)
        return query_rect

    def start_shake(self, intensity, duration, rotation_intensity=1):
        self.shake_intensity = intensity
        self.shake_duration = duration
        self.shake_timer = duration
        self.rotation_intensity = 0  # rotation_intensity

    def update_shake(self):
        if self.shake_timer > 0:
            self.shake_timer -= 1

            # Use Perlin noise to get the shake offset
            self.shake_offset.x = pnoise1(self.noise_base_x) * self.shake_intensity
            self.shake_offset.y = pnoise1(self.noise_base_y) * self.shake_intensity
            self.rotation_offset = (
                pnoise1(self.noise_base_x + self.noise_base_y) * self.rotation_intensity
            )
            print(self.shake_offset.x)

            # Update noise base for the next frame
            self.noise_base_x += self.noise_step
            self.noise_base_y += self.noise_step

            if self.shake_timer <= 0:
                self.shake_intensity = 0
                self.shake_offset = pygame.Vector2(0, 0)
                self.rotation_intensity = 0
                self.rotation_offset = 0

    def render(self, surface, target, parallax_factors):
        self.camera.update(target)
        self.update_shake()

        # Create a temporary surface for drawing with alpha support for rotation
        temp_surface = pygame.Surface(
            (self.rect.width, self.rect.height), pygame.SRCALPHA
        )
        temp_surface.fill("#71ddee")

        for layer_name, speed_factor in parallax_factors.items():
            # Create a query rect with the same dimensions as the camera but offset for parallax (speed factor)
            query_rect = self.get_query_rect(speed_factor)

            # Query the quadtree for visible sprites
            visible_sprites = self.layer_manager.query_visible_sprites(
                layer_name, query_rect
            )

            # Render visible sprites
            for sprite in visible_sprites:
                sprite_position = self.camera.apply(sprite, speed_factor)
                temp_surface.blit(sprite.image, sprite_position)

        # Draw the player
        player_position = self.camera.apply(target)
        temp_surface.blit(target.image, player_position)

        # Rotate the entire temporary surface
        if self.rotation_offset != 0:
            rotated_surface = pygame.transform.rotate(
                temp_surface, self.rotation_offset
            )
            rotated_rect = rotated_surface.get_rect(
                center=temp_surface.get_rect().center
            )
            surface.blit(
                rotated_surface,
                self.rect.topleft
                - pygame.Vector2(rotated_rect.topleft)
                + self.shake_offset,
            )
        else:
            surface.blit(temp_surface, self.rect.topleft + self.shake_offset)

        # Draw border around the inner rect (camera margins)
        border_rect = pygame.Rect(
            self.camera.camera_margin_x,
            self.camera.camera_margin_y,
            self.rect.width - 2 * self.camera.camera_margin_x,
            self.rect.height - 2 * self.camera.camera_margin_y,
        )

        pygame.draw.rect(temp_surface, self.border_color, border_rect, 2)

        # Draw the viewport border
        pygame.draw.rect(surface, self.border_color, self.rect, 2)


layer_names = ["foreground", "midground", "background"]
layer_manager = LayerManager("big-map16x16.tmx", layer_names)

# Retrieve world dimensions
WORLD_WIDTH, WORLD_HEIGHT = layer_manager.get_world_dimensions()

# Initialize player
player = Player()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

# Define parallax factors for layers
parallax_factors = {"background": 0.5, "midground": 0.75, "foreground": 1}
# parallax_factors = {"midground": 0.75, "foreground": 1}

# Initialize camera and viewport
initial_camera_pos = (
    player.rect.x - SCREEN_WIDTH // 2,
    player.rect.y - SCREEN_HEIGHT // 2,
)

second_camera_pos = (
    385,
    90,
)

# need to set player object also to camera pos

main_camera = Camera(
    SCREEN_WIDTH, SCREEN_HEIGHT, initial_camera_pos, WORLD_WIDTH, WORLD_HEIGHT
)

second_camera = Camera(
    SCREEN_WIDTH, SCREEN_HEIGHT, second_camera_pos, WORLD_WIDTH, WORLD_HEIGHT
)


main_viewport = Viewport(
    0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, main_camera, layer_manager, border_color=GREEN
)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                print("Space key is pressed down")
                main_viewport.start_shake(5, 90)

    player.update()

    # Render viewports

    screen.fill(BLACK)
    main_viewport.render(screen, player, parallax_factors)

    # foreground_sprites = main_viewport.get_foreground_sprites()
    sprites_around_player = main_viewport.sprites_around_player(player)
    player.check_collisions(sprites_around_player)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
