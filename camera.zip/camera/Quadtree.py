import pygame

GREEN = (0, 255, 0)


class Quadtree:
    def __init__(self, boundary, capacity):
        self.boundary = boundary
        self.capacity = capacity
        self.tiles = []
        self.divided = False

    def count_tiles(self):
        count = len(self.tiles)
        if self.divided:
            count += self.northeast.count_tiles()
            count += self.northwest.count_tiles()
            count += self.southeast.count_tiles()
            count += self.southwest.count_tiles()
        return count

    def subdivide(self):
        x, y, w, h = self.boundary
        half_w, half_h = w // 2, h // 2

        self.northeast = Quadtree(
            pygame.Rect(x + half_w, y, half_w, half_h), self.capacity
        )
        self.northwest = Quadtree(pygame.Rect(x, y, half_w, half_h), self.capacity)
        self.southeast = Quadtree(
            pygame.Rect(x + half_w, y + half_h, half_w, half_h), self.capacity
        )
        self.southwest = Quadtree(
            pygame.Rect(x, y + half_h, half_w, half_h), self.capacity
        )

        self.divided = True

    def insert(self, tile):
        if not self.boundary.colliderect(tile.rect):
            return False
        if len(self.tiles) < self.capacity:
            self.tiles.append(tile)
            return True
        else:
            if not self.divided:
                self.subdivide()
            if self.northeast.insert(tile):
                return True
            if self.northwest.insert(tile):
                return True
            if self.southeast.insert(tile):
                return True
            if self.southwest.insert(tile):
                return True

    def query(self, range, found=None, parallax_factor=1.0):
        if found is None:
            found = []

        expanded_range = range.inflate(
            self.boundary.width * (parallax_factor - 1),
            self.boundary.height * (parallax_factor - 1),
        )

        if not self.boundary.colliderect(expanded_range):
            return found

        for tile in self.tiles:
            if expanded_range.colliderect(tile.rect):
                found.append(tile)

        if self.divided:
            self.northeast.query(expanded_range, found, parallax_factor)
            self.northwest.query(expanded_range, found, parallax_factor)
            self.southeast.query(expanded_range, found, parallax_factor)
            self.southwest.query(expanded_range, found, parallax_factor)

        return found

    def draw(self, surface, offset):
        adjusted_boundary = self.boundary.move(-offset.x, -offset.y)
        pygame.draw.rect(surface, GREEN, adjusted_boundary, 1)
        if self.divided:
            self.northeast.draw(surface, offset)
            self.northwest.draw(surface, offset)
            self.southeast.draw(surface, offset)
            self.southwest.draw(surface, offset)
