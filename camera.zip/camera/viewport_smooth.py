import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600

# World dimensions
WORLD_WIDTH, WORLD_HEIGHT = 2000, 2000

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Camera System")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Player settings
player_pos = [100, 100]
player_speed = 5
player_size = 50

# Camera settings
camera_margin_x = 150  # Horizontal margin
camera_margin_y = 100  # Vertical margin
camera_speed = 5

# Smoothing settings
smoothing_enabled = True
smoothing_speed = 0.1  # Lower values = more smoothing


# Camera class
class Camera:
    def __init__(self, width, height, smoothing_enabled=True, smoothing_speed=0.1):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height
        self.smoothing_enabled = smoothing_enabled
        self.smoothing_speed = smoothing_speed

    def apply(self, entity):
        return entity.rect.move(-self.camera.x, -self.camera.y)

    def update(self, target):
        target_x = target.rect.centerx
        target_y = target.rect.centery

        # Calculate camera margins
        camera_left_margin = self.camera.x + camera_margin_x
        camera_right_margin = self.camera.x + self.width - camera_margin_x
        camera_top_margin = self.camera.y + camera_margin_y
        camera_bottom_margin = self.camera.y + self.height - camera_margin_y

        # Determine the desired camera position
        desired_x = self.camera.x
        desired_y = self.camera.y

        if target_x < camera_left_margin:
            desired_x = target_x - camera_margin_x
        elif target_x > camera_right_margin:
            desired_x = target_x - self.width + camera_margin_x

        if target_y < camera_top_margin:
            desired_y = target_y - camera_margin_y
        elif target_y > camera_bottom_margin:
            desired_y = target_y - self.height + camera_margin_y

        # Limit camera to the boundaries of the world
        desired_x = max(0, min(desired_x, WORLD_WIDTH - self.width))
        desired_y = max(0, min(desired_y, WORLD_HEIGHT - self.height))

        if self.smoothing_enabled:
            # Apply linear interpolation for smoothing
            self.camera.x += (desired_x - self.camera.x) * self.smoothing_speed
            self.camera.y += (desired_y - self.camera.y) * self.smoothing_speed
        else:
            # Move the camera directly to the desired position
            self.camera.x = desired_x
            self.camera.y = desired_y


# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((player_size, player_size))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.topleft = player_pos

    def update(self, keys):
        if keys[pygame.K_LEFT]:
            self.rect.x -= player_speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += player_speed
        if keys[pygame.K_UP]:
            self.rect.y -= player_speed
        if keys[pygame.K_DOWN]:
            self.rect.y += player_speed

        # Keep player within the boundaries of the world
        self.rect.x = max(0, min(self.rect.x, WORLD_WIDTH - player_size))
        self.rect.y = max(0, min(self.rect.y, WORLD_HEIGHT - player_size))


# Background sprite class
class BackgroundSprite(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)


# Function to create random background sprites
def create_background_sprites(num_sprites):
    sprites = pygame.sprite.Group()
    for _ in range(num_sprites):
        x = random.randint(0, WORLD_WIDTH - 30)
        y = random.randint(0, WORLD_HEIGHT - 30)
        sprite = BackgroundSprite(x, y)
        sprites.add(sprite)
    return sprites


# Viewport class
class Viewport:
    def __init__(self, x, y, width, height, border_color=BLACK, track_target=True):
        self.rect = pygame.Rect(x, y, width, height)
        self.camera = Camera(width, height)
        self.border_color = border_color
        self.track_target = track_target

    def render(self, surface, sprites, target):
        if self.track_target:
            self.camera.update(target)

        # Draw background
        temp_surface = pygame.Surface((self.rect.width, self.rect.height))
        temp_surface.fill(WHITE)
        for sprite in sprites:
            temp_surface.blit(sprite.image, self.camera.apply(sprite))

        # Draw player
        temp_surface.blit(target.image, self.camera.apply(target))

        # Draw border around the inner rect (camera margins)
        border_rect = pygame.Rect(
            camera_margin_x,
            camera_margin_y,
            self.rect.width - 2 * camera_margin_x,
            self.rect.height - 2 * camera_margin_y,
        )
        pygame.draw.rect(temp_surface, BLACK, border_rect, 2)

        # Blit to the main surface
        surface.blit(temp_surface, self.rect.topleft)

        # Draw viewport border
        pygame.draw.rect(surface, self.border_color, self.rect, 2)


# Initialize player
player = Player()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

# Create background sprites
background_sprites = create_background_sprites(250)

# Initialize viewports with different border colors
main_viewport = Viewport(
    0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, border_color=GREEN, track_target=True
)
mini_map_viewport = Viewport(
    600, 400, 200, 200, border_color=YELLOW, track_target=False
)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    player.update(keys)

    # Render viewports
    screen.fill(WHITE)
    main_viewport.render(screen, background_sprites, player)
    mini_map_viewport.render(screen, background_sprites, player)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
