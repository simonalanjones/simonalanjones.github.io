import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600

# World dimensions
WORLD_WIDTH, WORLD_HEIGHT = 2000, 2000

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Camera System")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Player settings
player_pos = [100, 100]
player_speed = 5
player_size = 50


# Camera class
class Camera:
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        return entity.rect.move(self.camera.topleft)

    def update(self, target):
        x = -target.rect.centerx + int(SCREEN_WIDTH / 2)
        y = -target.rect.centery + int(SCREEN_HEIGHT / 2)

        # Limit scrolling to map size
        x = min(0, x)  # Left
        y = min(0, y)  # Top
        x = max(-(self.width - SCREEN_WIDTH), x)  # Right
        y = max(-(self.height - SCREEN_HEIGHT), y)  # Bottom

        self.camera = pygame.Rect(x, y, self.width, self.height)


# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((player_size, player_size))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.topleft = player_pos

    def update(self, keys):
        if keys[pygame.K_LEFT]:
            self.rect.x -= player_speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += player_speed
        if keys[pygame.K_UP]:
            self.rect.y -= player_speed
        if keys[pygame.K_DOWN]:
            self.rect.y += player_speed

        # Boundary checks to prevent moving outside the world
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > WORLD_WIDTH:
            self.rect.right = WORLD_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > WORLD_HEIGHT:
            self.rect.bottom = WORLD_HEIGHT


# Background sprite class
class BackgroundSprite(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)


# Function to create random background sprites
def create_background_sprites(num_sprites):
    for _ in range(num_sprites):
        x = random.randint(0, WORLD_WIDTH - 30)
        y = random.randint(0, WORLD_HEIGHT - 30)
        sprite = BackgroundSprite(x, y)
        all_sprites.add(sprite)


# Initialize player
player = Player()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

# Create background sprites
create_background_sprites(50)

# Initialize camera
camera = Camera(WORLD_WIDTH, WORLD_HEIGHT)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    player.update(keys)

    camera.update(player)

    screen.fill(WHITE)
    for sprite in all_sprites:
        screen.blit(sprite.image, camera.apply(sprite))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
