import random
import pygame
import sys
from pytmx.util_pygame import load_pygame
import math

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 1280, 720

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Camera System")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

player_pos = [400, 4000]


class Particle(pygame.sprite.Sprite):

    def __init__(self, position, rotation):

        super().__init__()

        self.sprite_image = pygame.image.load("graphics/circle.png")
        self.vx = 0
        self.vy = 0

        self.acceleration = 0.7  # Acceleration due to thrust
        self.gravity = 0.7  # Gravity affecting the rocket
        self.thrust_power = 0.6  # Power of thrust
        self.mass = 0.4

        self.timer = random.randint(1, 4)

        offset_x = random.randint(-10, 10)
        offset_y = random.randint(-10, 10)

        self.x = position.x
        self.y = position.y
        self.rotation = rotation

        # Rotate offset based on ship's rotation
        offset_x_rotated = offset_x * math.cos(
            math.radians(rotation)
        ) - offset_y * math.sin(math.radians(rotation))

        offset_y_rotated = offset_x * math.sin(
            math.radians(rotation)
        ) + offset_y * math.cos(math.radians(rotation))

        # Apply offset to particle's position
        self.x += offset_x_rotated
        self.y += offset_y_rotated

        # Scale sprite based on timer (radius of circle)
        self.sprite = pygame.transform.scale(
            self.sprite_image, (int(self.timer / 0.7), int(self.timer / 0.7))
        )
        self.sprite = self.sprite_image
        self.rect = self.sprite.get_rect(center=(self.x, self.y))

    def update(self):
        self.timer -= 0.5

        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        # Calculate acceleration using Newton's second law: F = ma
        acceleration_x = thrust_force_x / self.mass
        acceleration_y = thrust_force_y / self.mass

        # Update velocity based on acceleration
        self.vx += acceleration_x
        self.vy += acceleration_y

        self.x -= self.vx
        self.y -= self.vy

        # Update sprite position
        self.rect.center = (self.x, self.y)

    def __update(self):
        self.timer -= 0.5
        ship_rotation = self.ship_rotation

        thrust_force_x = self.thrust_power * math.cos(math.radians(ship_rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(ship_rotation + 90))

        # Calculate acceleration using Newton's second law: F = ma
        acceleration_x = thrust_force_x / self.mass
        acceleration_y = thrust_force_y / self.mass

        # Update velocity based on acceleration
        self.vx += acceleration_x
        self.vy += acceleration_y

        self.x -= self.vx
        self.y -= self.vy

        # Update sprite position
        self.rect.center = (self.x, self.y)

    def draw(self, surface):
        surface.blit(self.sprite, self.rect)


class ParticleEmitter:

    def __init__(self, particle_container, get_ship):
        self.particle_container = particle_container
        self.get_ship = get_ship

    def update(self):
        self.particle_container.update()

    def emit(self, position, rotation):
        particle = Particle(position, rotation)
        self.particle_container.add(particle)

    def emit_from_ship_rear(self):
        ship = self.get_ship()

        position = ship.get_rear_exhaust_position()
        rotation = ship.rotation

        thrust = ship.current_thrust_power
        if thrust > 0.9:
            self.emit(position, rotation)
            self.emit(position, rotation)
            self.emit(position, rotation)
        elif thrust > 0.5:
            self.emit(position, rotation)
            self.emit(position, rotation)
        elif thrust > 0.2 or ship.current_thrust_power > 0:
            self.emit(position, rotation)

    def emit_from_ship_front(self, ship):
        pass

    def get_surface(self):
        return self.particle_container


class ParticleContainer(pygame.sprite.Group):

    def __init__(self):
        pygame.sprite.Group.__init__(self)
        # self.sprite_group = sprite_group

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def check_collisions(self, sprite_group):
        # only check collisions if container has particle sprites
        if len(self) > 0:
            collisions = pygame.sprite.groupcollide(
                self, sprite_group, False, False, collided=None
            )

            if collisions:
                for particle, tile in collisions.items():
                    particle.vy = -particle.vy
                    random_number = random.uniform(-5, 5)
                    particle.vx = random_number

    def spawn_particle(self, get_ship):
        # print("current ship thrust", ship.current_thrust_power)
        particle = Particle(get_ship)
        self.add(particle)

    def update(self):
        for particle in self.sprites():
            particle.update()
            if particle.timer <= 0:
                particle.kill()


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # move this to an event system and remove from player
        particle_container = ParticleContainer()
        self.particle_emitter = ParticleEmitter(particle_container, self.get_ship)

        self.image = pygame.image.load("graphics/ship.png").convert_alpha()

        # make a copy of the image untouched for reference later in rotation
        self.base_image = self.image

        # initial x and y position
        self.x, self.y = 300, 220

        # create a vector2 for the sprite position/rect
        self.pos = pygame.Vector2(self.x, self.y)

        # create a rect based on the size of the image
        self.rect = self.image.get_rect()
        # place the rect center at the x,y position
        self.rect.center = self.pos

        # create an alternative rect which is a constant 60,60 width x height
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        # make the centre of the hit-rect based on the normal rect
        self.hit_rect.center = self.rect.center

        # starting rotation
        self.rotation = 0

        self.rotate_speed = 4  # Base rotation speed
        self.max_rotate_speed = 5  # Maximum rotation speed
        self.scaling_factor = 0.4  # Starting value for the scaling factor

        self.thrusting = False
        self.back_thrusting = False

        self.max_backward_velocity = -3  # Maximum velocity achievable with back thrust

        self.ship_mass = 2.5  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.03  # Gravity affecting the rocket
        # self.thrust_power = 0.5  # Power of thrust

        self.current_thrust_power = 0  # Current thrust power
        self.max_thrust_power = 1.0  # Maximum thrust power
        self.thrust_increment = 0.02  # Incremental increase in thrust power
        self.thrust_decrement = 0.02  # Incremental decrease in thrust power

        # landing related vars
        self.landed = False
        self.landing_max_velocity = 3

        self.landing_rotation_left_threshold = 24
        self.landing_rotation_right_threshold = 340
        self.landing_tile_position_threshold = 20

    def get_ship(self):
        return self

    def get_thrusters(self):
        particles = player.particle_emitter.get_surface()
        for particle in particles:
            particle_offset = particle.rect.topleft - self.offset
            self.display_surface.blit(particle.sprite, particle_offset)

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def get_total_collision_rect(self, sprite_group):
        # Might be landing between two sprites
        # Calculate the bounding box of the combined area covered by all (usually max two) sprites in the group
        left = min(sprite.rect.left for sprite in sprite_group)
        top = min(sprite.rect.top for sprite in sprite_group)
        right = max(sprite.rect.right for sprite in sprite_group)
        bottom = max(sprite.rect.bottom for sprite in sprite_group)

        # amount to add to either side of the tile collision group
        tolerance = self.landing_tile_position_threshold

        combined_rect = pygame.Rect(
            left - tolerance,
            top,
            right - left + tolerance * 2,  # Add tolerance to both left and right sides
            bottom - top,
        )
        return combined_rect

    def can_land_on_rect(self, total_collision_rect):

        # Check if the player is within the horizontal bounds of the combined area
        if (
            self.rect.bottom < total_collision_rect.centery
            and self.rect.left > total_collision_rect.left
            and self.rect.right < total_collision_rect.right
        ):
            return True
        return False

    def collision_direction_word(self, tile):
        # Check for collision and handle overlaps
        player = self
        collision = pygame.sprite.collide_rect(player, tile)
        if collision:
            player_rect = player.rect
            tile_rect = tile.rect

            # Get the center points of the player and tile sprites
            player_center_x = player_rect.centerx
            player_center_y = player_rect.centery
            tile_center_x = tile_rect.centerx
            tile_center_y = tile_rect.centery

            # Calculate the horizontal and vertical distances between centers
            dx = player_center_x - tile_center_x
            dy = player_center_y - tile_center_y

            # Determine the direction of overlap based on the majority of the player sprite's position
            if abs(dx) > abs(dy):
                # Majority of player sprite is left or right of the tile
                if dx < 0:
                    return "right"
                else:
                    return "left"
            else:
                # Majority of player sprite is above or below the tile
                if dy < 0:
                    return "bottom"
                else:
                    return "top"

    def check_landing_velocity_and_rotation(self):
        if self.vy < self.landing_max_velocity and (
            self.rotation < self.landing_rotation_left_threshold
            or self.rotation > self.landing_rotation_right_threshold
        ):
            return True
        else:
            return False

    def land_ship(self):
        self.vx = 0
        self.vy = 0
        self.landed = True
        self.rotation = 0

    def check_collisions(self, sprite_group):

        # self.particle_container.check_collisions(sprite_group)

        if not self.landed:
            hits = pygame.sprite.spritecollide(
                self, sprite_group, False, self.collide_hit_rect
            )
            if hits:
                sprite = hits[0]

                collision_word = self.collision_direction_word(sprite)
                # print(collision_word)

                total_collision_rect = self.get_total_collision_rect(hits)

                if collision_word == "bottom":

                    if (
                        self.can_land_on_rect(total_collision_rect)
                        and self.check_landing_velocity_and_rotation()
                    ):
                        self.land_ship()

                    # collision below but doesn't satisfy landing requirements
                    else:
                        self.handle_collision_bottom(sprite)

                elif collision_word == "right":
                    self.handle_collision_right()

                elif collision_word == "left":
                    self.handle_collision_left()

                elif collision_word == "top":
                    self.handle_collision_top()

    def handle_collision_right(self):
        # print("right")
        if self.vx > 0 and self.vy > 0:
            # print("hit down to right")
            self.vx = -(self.vx / 2)
            self.pos.x -= 5
            return

        elif self.vx > 0 and self.vy < 0:
            # print("hit up to right")
            self.vx = -(self.vx / 2)
            self.pos.x -= 5

    def handle_collision_left(self):
        # print("left")
        if self.vx < 0 and self.vy > 0:
            # print("hit down to left")
            self.vx = -(self.vx / 2)
            self.pos.x += 5
            return
        elif self.vx < 0 and self.vy < 0:
            # print("hit up to left")
            self.vx = -(self.vx / 2)
            self.pos.x += 5

    def handle_collision_top(self):
        self.vy = -(self.vy / 2)
        self.pos.y += 5

    # not currently used
    def handle_correction(self):
        # reposition ship towards 0 degress with each bounce
        clockwise_difference = abs(self.rotation - 0)
        counterclockwise_difference = abs(360 - self.rotation)
        if clockwise_difference < counterclockwise_difference:
            self.rotation -= 5
        else:
            self.rotation += 5

    def handle_collision_bottom(self, sprite):
        print("cant land")
        self.pos.y = sprite.rect.top - (self.rect.height / 2)
        self.vx = -(self.vx / 2)
        self.vy = -self.vy / 2

    def get_rear_exhaust_position(self):
        rotation_radians = math.radians(self.rotation)

        distance_from_bottom = self.rect.height / 2
        offset_x = distance_from_bottom * math.sin(rotation_radians)
        offset_y = distance_from_bottom * math.cos(rotation_radians)

        exhaust_position = pygame.Vector2(self.pos.x + offset_x, self.pos.y + offset_y)
        return exhaust_position

    def update(self):

        # this should be an event driven rather than feeding the ship directly
        # feed the classes manually from invaders and wire them up
        # self.particle_emitter.emit_from_ship_rear()
        # self.particle_emitter.update()
        # if not self.rotation < 240 and self.rotation > 120:
        # print("stopping bt")
        #   self.back_thrusting = False

        rotation_radians = math.radians(self.rotation)

        distance_from_bottom = self.rect.height / 2
        offset_x = distance_from_bottom * math.sin(rotation_radians)
        offset_y = distance_from_bottom * math.cos(rotation_radians)

        self.exhaust_position = pygame.Vector2(
            self.pos.x + offset_x, self.pos.y + offset_y
        )

        # push this into particle container
        # ==== need to move this to event system ======
        # self.particle_container.update()

        if (
            self.thrusting or self.current_thrust_power > 0.6
        ) and not self.back_thrusting:
            self.particle_emitter.emit_from_ship_rear()

        if self.thrusting or self.back_thrusting:

            self.landed = False
            self.update_velocity()
        else:
            self.apply_drag()
            if self.current_thrust_power > 0:
                self.current_thrust_power -= self.thrust_decrement
                if self.current_thrust_power < 0:
                    self.current_thrust_power = 0

        if not self.landed:
            self.update_rotation()
            self.apply_gravity()

        # Update position based on velocity
        self.pos += pygame.Vector2(self.vx, self.vy)
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=self.pos)
        self.hit_rect.center = self.rect.center

    def update_rotation(self):
        if not self.landed:
            # Calculate velocity magnitude
            velocity_magnitude = pygame.math.Vector2(self.vx, self.vy).length()

            # Dampen rotation speed based on velocity magnitude
            if velocity_magnitude > 0:
                # Calculate a new rotation speed based on velocity magnitude
                new_rotate_speed = self.max_rotate_speed / (
                    velocity_magnitude * self.scaling_factor
                )

                # Clamp the rotation speed to avoid it becoming too high
                self.rotate_speed = min(new_rotate_speed, self.max_rotate_speed)
            else:
                # Reset rotation speed when velocity magnitude is zero
                self.rotate_speed = self.max_rotate_speed

    def update_velocity(self):

        if self.current_thrust_power < self.max_thrust_power:
            self.current_thrust_power += self.thrust_increment

        if self.thrusting:
            # Apply forward thrust
            thrust_force_x = self.current_thrust_power * math.cos(
                math.radians(self.rotation + 90)
            )
            thrust_force_y = -self.current_thrust_power * math.sin(
                math.radians(self.rotation + 90)
            )
            acceleration_x = thrust_force_x / self.ship_mass
            acceleration_y = thrust_force_y / self.ship_mass

        elif self.back_thrusting:  # and self.rotation < 240 and self.rotation > 120:

            back_thrust_force_x = self.current_thrust_power * math.cos(
                math.radians(self.rotation - 90)
            )
            back_thrust_force_y = -self.current_thrust_power * math.sin(
                math.radians(self.rotation - 90)
            )

            # Apply a scaling factor to limit back thrust compared to forward thrust
            back_thrust_scaling_factor = 0.3  # Adjust this factor as needed
            back_thrust_force_x *= back_thrust_scaling_factor
            back_thrust_force_y *= back_thrust_scaling_factor

            # Calculate acceleration using Newton's second law: F = ma
            acceleration_x = back_thrust_force_x / self.ship_mass
            acceleration_y = back_thrust_force_y / self.ship_mass
        else:
            # No thrust applied
            acceleration_x = 0
            acceleration_y = 0

        # Update velocity based on acceleration
        self.vx += acceleration_x
        self.vy += acceleration_y

        # Cap velocities
        self.vx = max(min(self.vx, 5), -5)
        self.vy = max(min(self.vy, 5), -5)

    def check_can_back_thrust(self):
        return not self.landed
        # if self.rotation < 240 and self.rotation > 120 and not self.landed:
        #    return True

    def apply_gravity(self):
        # Apply gravity based on ship orientation and mass
        gravity_force = self.gravity * self.ship_mass

        # Update velocity based on gravity
        # self.vy += gravity_force

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    def start_back_thrust(self):
        if self.check_can_back_thrust():
            self.back_thrusting = True
            self.current_thrust_power = 1

    def stop_back_thrust(self):
        self.back_thrusting = False
        self.current_thrust_power = 1

    # call when space key pressed
    def start_thrusting(self):
        self.landed = False
        self.thrusting = True

    # called when space key released
    def stop_thrust(self):
        self.thrusting = False
        # self.current_thrust_power = 0


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class LayerManager:
    def __init__(self, tmx_file, layer_names, tile_size=128):
        self.tmx_data = load_pygame(tmx_file)
        self.layer_names = layer_names
        self.tile_size = tile_size
        self.tile_layers = {name: pygame.sprite.Group() for name in layer_names}
        self.quadtrees = {}
        self.world_width, self.world_height = self._initialize_layers()

    def _initialize_layers(self):
        max_x, max_y = 0, 0
        for layer in self.tmx_data.visible_layers:
            if layer.name in self.layer_names:
                for x, y, surf in layer.tiles():
                    pos = (x * self.tile_size, y * self.tile_size)
                    Tile(pos=pos, surf=surf, groups=self.tile_layers[layer.name])
                    if x > max_x:
                        max_x = x
                    if y > max_y:
                        max_y = y

        world_width = (max_x + 1) * self.tile_size
        world_height = (max_y + 1) * self.tile_size

        for name in self.layer_names:
            boundary = pygame.Rect(0, 0, world_width, world_height)
            self.quadtrees[name] = Quadtree(boundary, 4)
            for sprite in self.tile_layers[name]:
                self.quadtrees[name].insert(sprite)

        return world_width, world_height

    def query_visible_sprites(self, layer_name, query_rect):
        return self.quadtrees[layer_name].query(query_rect)

    def get_world_dimensions(self):
        return self.world_width, self.world_height


class Quadtree:
    def __init__(self, boundary, capacity):
        self.boundary = boundary
        self.capacity = capacity
        self.tiles = []
        self.divided = False

    def count_tiles(self):
        count = len(self.tiles)
        if self.divided:
            count += self.northeast.count_tiles()
            count += self.northwest.count_tiles()
            count += self.southeast.count_tiles()
            count += self.southwest.count_tiles()
        return count

    def subdivide(self):
        x, y, w, h = self.boundary
        half_w, half_h = w // 2, h // 2

        self.northeast = Quadtree(
            pygame.Rect(x + half_w, y, half_w, half_h), self.capacity
        )
        self.northwest = Quadtree(pygame.Rect(x, y, half_w, half_h), self.capacity)
        self.southeast = Quadtree(
            pygame.Rect(x + half_w, y + half_h, half_w, half_h), self.capacity
        )
        self.southwest = Quadtree(
            pygame.Rect(x, y + half_h, half_w, half_h), self.capacity
        )

        self.divided = True

    def insert(self, tile):
        if not self.boundary.colliderect(tile.rect):
            return False

        if len(self.tiles) < self.capacity:
            self.tiles.append(tile)
            return True
        else:
            if not self.divided:
                self.subdivide()

            if self.northeast.insert(tile):
                return True
            if self.northwest.insert(tile):
                return True
            if self.southeast.insert(tile):
                return True
            if self.southwest.insert(tile):
                return True

    def query(self, range, found=None):
        if found is None:
            found = []

        if not self.boundary.colliderect(range):
            return found

        for tile in self.tiles:
            if range.colliderect(tile.rect):
                found.append(tile)

        if self.divided:
            self.northeast.query(range, found)
            self.northwest.query(range, found)
            self.southeast.query(range, found)
            self.southwest.query(range, found)

        return found

    def draw(self, surface, offset):
        adjusted_boundary = self.boundary.move(-offset.x, -offset.y)
        pygame.draw.rect(surface, GREEN, adjusted_boundary, 1)

        if self.divided:
            self.northeast.draw(surface, offset)
            self.northwest.draw(surface, offset)
            self.southeast.draw(surface, offset)
            self.southwest.draw(surface, offset)


class Camera:
    def __init__(
        self,
        width,
        height,
        initial_pos,
        world_width,
        world_height,
        smoothing_enabled=True,
        smoothing_speed=0.1,
    ):
        self.camera = pygame.Rect(initial_pos[0], initial_pos[1], width, height)
        self.width = width
        self.height = height
        self.world_width = world_width
        self.world_height = world_height
        self.smoothing_enabled = smoothing_enabled
        self.smoothing_speed = smoothing_speed

        self.camera_margin_x = 250
        self.camera_margin_y = 200
        self.camera_speed = 5

    def apply(self, entity, speed_factor=1):
        x = math.floor(self.camera.x * speed_factor)
        y = math.floor(self.camera.y * speed_factor)

        # print(f"Entity position after camera apply: ({x}, {y})")
        return entity.rect.move(-x, -y)

    def update(self, target):
        target_x = target.rect.centerx
        target_y = target.rect.centery

        camera_left_margin = self.camera.x + self.camera_margin_x
        camera_right_margin = self.camera.x + self.width - self.camera_margin_x
        camera_top_margin = self.camera.y + self.camera_margin_y
        camera_bottom_margin = self.camera.y + self.height - self.camera_margin_y

        desired_x = self.camera.x
        desired_y = self.camera.y

        if target_x < camera_left_margin:
            desired_x = target_x - self.camera_margin_x
        elif target_x > camera_right_margin:
            desired_x = target_x - self.width + self.camera_margin_x

        if target_y < camera_top_margin:
            desired_y = target_y - self.camera_margin_y
        elif target_y > camera_bottom_margin:
            desired_y = target_y - self.height + self.camera_margin_y

        desired_x = max(0, min(desired_x, self.world_width - self.width))
        desired_y = max(0, min(desired_y, self.world_height - self.height))

        # Use math.floor to ensure positions are rounded down to nearest integer
        if self.smoothing_enabled:
            self.camera.x += math.floor(
                (desired_x - self.camera.x) * self.smoothing_speed
            )
            self.camera.y += math.floor(
                (desired_y - self.camera.y) * self.smoothing_speed
            )
        else:
            self.camera.x = desired_x
            self.camera.y = desired_y

        self.camera.x = self.camera.x
        self.camera.y = self.camera.y


class Viewport:
    def __init__(self, x, y, width, height, camera, layer_manager, border_color=BLACK):
        self.rect = pygame.Rect(x, y, width, height)
        self.set_camera(camera)

        self.layer_manager = layer_manager
        self.border_color = border_color

    def set_camera(self, camera):
        if isinstance(camera, Camera):
            self.camera = camera

    def render(self, surface, target, parallax_factors):
        self.camera.update(target)

        # Create a temporary surface for drawing
        temp_surface = pygame.Surface((self.rect.width, self.rect.height))
        temp_surface.fill(WHITE)

        for layer_name, speed_factor in parallax_factors.items():
            # Create a query rect with the same dimensions as the camera but offset for parallax
            query_rect = pygame.Rect(
                round(self.camera.camera.x * speed_factor),
                round(self.camera.camera.y * speed_factor),
                self.camera.camera.width,
                self.camera.camera.height,
            )

            # print(f"Query rect position: ({query_rect.x}, {query_rect.y})")

            tile_size = 128
            query_rect = query_rect.inflate(tile_size * 2, tile_size * 2)

            # Query the quadtree for visible sprites
            visible_sprites = self.layer_manager.query_visible_sprites(
                layer_name, query_rect
            )

            # Render visible sprites
            for sprite in visible_sprites:
                temp_surface.blit(sprite.image, self.camera.apply(sprite, speed_factor))

        # Draw the player
        temp_surface.blit(target.image, self.camera.apply(target))

        # Draw border around the inner rect (camera margins)
        border_rect = pygame.Rect(
            self.camera.camera_margin_x,
            self.camera.camera_margin_y,
            self.rect.width - 2 * self.camera.camera_margin_x,
            self.rect.height - 2 * self.camera.camera_margin_y,
        )

        pygame.draw.rect(temp_surface, BLACK, border_rect, 2)

        # Blit the temporary surface to the main surface
        surface.blit(temp_surface, self.rect.topleft)

        # Draw the viewport border
        pygame.draw.rect(surface, self.border_color, self.rect, 2)


layer_names = ["foreground", "midground", "background"]
layer_manager = LayerManager("big-map16x16.tmx", layer_names)

# Retrieve world dimensions
WORLD_WIDTH, WORLD_HEIGHT = layer_manager.get_world_dimensions()

# Initialize player
player = Player()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

# Define parallax factors for layers
parallax_factors = {"background": 0.5, "midground": 0.75, "foreground": 1}

# Initialize camera and viewport
initial_camera_pos = (
    player.rect.x - SCREEN_WIDTH // 2,
    player.rect.y - SCREEN_HEIGHT // 2,
)

# need to set player object also to camera pos

main_camera = Camera(
    SCREEN_WIDTH, SCREEN_HEIGHT, initial_camera_pos, WORLD_WIDTH, WORLD_HEIGHT
)

main_viewport = Viewport(
    0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, main_camera, layer_manager, border_color=GREEN
)

# Main game loop
running = True
while running:
    pygame.display.set_caption("Fps: " + str(int(clock.get_fps())))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN and player.check_can_back_thrust():
                player.start_back_thrust()

        # stop back thrust
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_DOWN:
                player.stop_back_thrust()

        # thrust up
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                player.start_thrusting()

        # stop thrust up
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_UP:
                player.stop_thrust()

    if not player.landed:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player.rotate_left()
        if keys[pygame.K_RIGHT]:
            player.rotate_right()

    player.update()

    # Render viewports
    screen.fill(WHITE)
    main_viewport.render(screen, player, parallax_factors)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
