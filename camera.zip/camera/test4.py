import pygame
import math
import sys

SCREEN_MAX_X = 800
SCREEN_MAX_Y = 600

# Define gravity constant
GRAVITY = 0.05
GRAVITY = 0.02


class PlayerShip(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.position = {"x": x, "y": y}
        self.velocity = {"speed": 0, "direction": 0}
        self.acceleration = 1  # 0.7
        self.rotation = 0
        self.rotationSpeed = 0.07
        self.thrust_power = 0.2
        self.max_speed = 7
        self.friction = 0.99
        self.mass = 1  # 1.5
        self.image = pygame.image.load("graphics/ship.png")
        self.original_image = self.image
        self.rect = self.image.get_rect(center=(self.position["x"], self.position["y"]))

    def rotate_image(self):
        self.image = pygame.transform.rotate(
            self.original_image, -math.degrees(self.rotation)
        )
        self.rect = self.image.get_rect(center=(self.position["x"], self.position["y"]))

    def check_player_input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rotation -= self.rotationSpeed
        if keys[pygame.K_RIGHT]:
            self.rotation += self.rotationSpeed
        self.rotation = self.keep_angle_in_range(self.rotation)
        if keys[pygame.K_UP]:
            self.thrust()

    def keep_angle_in_range(self, angle):
        while angle < 0:
            angle += 2 * math.pi
        while angle > 2 * math.pi:
            angle -= 2 * math.pi
        return angle

    def move_point_by_velocity(self):
        components = self.get_vector_components(self.velocity)
        self.position["x"] += components["xComp"]
        self.position["y"] += components["yComp"]

    def move(self):
        self.apply_gravity()
        self.velocity["speed"] *= self.friction
        if self.velocity["speed"] < 0.01:
            self.velocity["speed"] = 0
        self.move_point_by_velocity()
        self.position = self.wrap_position(self.position)
        self.rotate_image()

    def apply_gravity(self):
        vertical_velocity = self.velocity["speed"] * math.sin(
            self.velocity["direction"]
        )
        vertical_velocity += GRAVITY / self.mass
        self.velocity = self.comp_to_vector(
            self.velocity["speed"] * math.cos(self.velocity["direction"]),
            vertical_velocity,
        )

    def thrust(self):
        thrust_force = {
            "speed": self.thrust_power / self.mass,
            "direction": self.rotation
            - (math.pi / 2),  # Subtracting 90 degrees in radians
        }
        new_velocity = self.add_vectors(self.velocity, thrust_force)
        if new_velocity["speed"] > self.max_speed:
            new_velocity["speed"] = self.max_speed
        self.velocity = new_velocity

    def add_vectors(self, vector1, vector2):
        v1Comp = self.get_vector_components(vector1)
        v2Comp = self.get_vector_components(vector2)
        resultant_x = v1Comp["xComp"] + v2Comp["xComp"]
        resultant_y = v1Comp["yComp"] + v2Comp["yComp"]
        return self.comp_to_vector(resultant_x, resultant_y)

    def get_vector_components(self, vector):
        xComp = vector["speed"] * math.cos(vector["direction"])
        yComp = vector["speed"] * math.sin(vector["direction"])
        return {"xComp": xComp, "yComp": yComp}

    def comp_to_vector(self, x, y):
        magnitude = math.sqrt((x * x) + (y * y))
        direction = math.atan2(y, x)
        direction = self.keep_angle_in_range(direction)
        return {"speed": magnitude, "direction": direction}

    def wrap_position(self, position):
        if position["x"] >= SCREEN_MAX_X:
            position["x"] = 0
        elif position["x"] < 0:
            position["x"] = SCREEN_MAX_X - 1
        if position["y"] >= SCREEN_MAX_Y:
            position["y"] = 0
        elif position["y"] < 0:
            position["y"] = SCREEN_MAX_Y - 1
        return position


def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_MAX_X, SCREEN_MAX_Y))
    clock = pygame.time.Clock()

    player_ship = PlayerShip(100, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        player_ship.check_player_input()
        player_ship.move()

        screen.fill((0, 0, 0))
        screen.blit(player_ship.image, player_ship.rect.topleft)
        pygame.display.flip()

        clock.tick(60)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
