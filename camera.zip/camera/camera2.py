import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600

# World dimensions
WORLD_WIDTH, WORLD_HEIGHT = 2000, 2000

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Camera System")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Player settings
player_pos = [100, 100]
player_speed = 5
player_size = 50

# Camera settings
# adjust these to push player further away from one edge
camera_margin_left = 200  # Left margin
camera_margin_right = 400  # Right margin
camera_margin_top = 150  # Top margin
camera_margin_bottom = 250  # Bottom margin
camera_speed = 5

# Smoothing settings
smoothing_enabled = True
smoothing_speed = 0.01  # Lower values = more smoothing


# Camera class
class Camera:
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        return entity.rect.move(-self.camera.x, -self.camera.y)

    def update(self, target):
        target_x = target.rect.centerx
        target_y = target.rect.centery

        # Calculate camera margins
        camera_left_margin = self.camera.x + camera_margin_left
        camera_right_margin = self.camera.x + self.width - camera_margin_right
        camera_top_margin = self.camera.y + camera_margin_top
        camera_bottom_margin = self.camera.y + self.height - camera_margin_bottom

        # Adjust camera position based on player movement
        if target_x < camera_left_margin:
            self.camera.x -= camera_speed
        elif target_x > camera_right_margin:
            self.camera.x += camera_speed
        if target_y < camera_top_margin:
            self.camera.y -= camera_speed
        elif target_y > camera_bottom_margin:
            self.camera.y += camera_speed

        # Limit camera to the boundaries of the world
        self.camera.x = max(0, min(self.camera.x, WORLD_WIDTH - self.width))
        self.camera.y = max(0, min(self.camera.y, WORLD_HEIGHT - self.height))


# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((player_size, player_size))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.topleft = player_pos

    def update(self, keys):
        if keys[pygame.K_LEFT]:
            self.rect.x -= player_speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += player_speed
        if keys[pygame.K_UP]:
            self.rect.y -= player_speed
        if keys[pygame.K_DOWN]:
            self.rect.y += player_speed

        # Keep player within the boundaries of the world
        self.rect.x = max(0, min(self.rect.x, WORLD_WIDTH - player_size))
        self.rect.y = max(0, min(self.rect.y, WORLD_HEIGHT - player_size))


# Background sprite class
class BackgroundSprite(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)


# Function to create random background sprites
def create_background_sprites(num_sprites):
    sprites = pygame.sprite.Group()
    for _ in range(num_sprites):
        x = random.randint(0, WORLD_WIDTH - 30)
        y = random.randint(0, WORLD_HEIGHT - 30)
        sprite = BackgroundSprite(x, y)
        sprites.add(sprite)
    return sprites


# Initialize player
player = Player()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

# Create background sprites
background_sprites = create_background_sprites(50)

# Initialize camera
camera = Camera(SCREEN_WIDTH, SCREEN_HEIGHT)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    player.update(keys)

    camera.update(player)

    # Draw background
    screen.fill(WHITE)
    for sprite in background_sprites:
        screen.blit(sprite.image, camera.apply(sprite))

    # Draw player
    screen.blit(player.image, camera.apply(player))

    # Draw border around the inner rect (camera margins)
    border_rect = pygame.Rect(
        camera.camera.x + camera_margin_left,
        camera.camera.y + camera_margin_top,
        SCREEN_WIDTH - (camera_margin_left + camera_margin_right),
        SCREEN_HEIGHT - (camera_margin_top + camera_margin_bottom),
    )
    pygame.draw.rect(screen, BLACK, border_rect, 2)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
