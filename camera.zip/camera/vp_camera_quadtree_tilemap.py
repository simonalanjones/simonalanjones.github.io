import pygame
import sys
from pytmx.util_pygame import load_pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600

# Initial world dimensions (to be updated based on the tilemap)
WORLD_WIDTH, WORLD_HEIGHT = 2000, 2000

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)

# Create screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("2D Camera System")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Player settings
player_pos = [100, 100]

bottom_position = WORLD_HEIGHT - SCREEN_HEIGHT  # Adjust SCREEN_HEIGHT for viewport size
# player_pos = (100, 7400)  # Adjust horizontal position as needed
player_pos = [200, 100]

player_speed = 5
player_size = 50

# Camera settings
camera_margin_x = 150
camera_margin_y = 100
camera_speed = 5

# Smoothing settings
smoothing_enabled = True
smoothing_speed = 0.1


# Camera class
class Camera:
    def __init__(self, width, height, smoothing_enabled=True, smoothing_speed=0.1):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height
        self.smoothing_enabled = smoothing_enabled
        self.smoothing_speed = smoothing_speed

    def apply(self, entity, speed_factor=1):
        return entity.rect.move(
            -self.camera.x * speed_factor, -self.camera.y * speed_factor
        )

    def update(self, target):
        target_x = target.rect.centerx
        target_y = target.rect.centery

        camera_left_margin = self.camera.x + camera_margin_x
        camera_right_margin = self.camera.x + self.width - camera_margin_x
        camera_top_margin = self.camera.y + camera_margin_y
        camera_bottom_margin = self.camera.y + self.height - camera_margin_y

        desired_x = self.camera.x
        desired_y = self.camera.y

        if target_x < camera_left_margin:
            desired_x = target_x - camera_margin_x
        elif target_x > camera_right_margin:
            desired_x = target_x - self.width + camera_margin_x

        if target_y < camera_top_margin:
            desired_y = target_y - camera_margin_y
        elif target_y > camera_bottom_margin:
            desired_y = target_y - self.height + camera_margin_y

        desired_x = max(0, min(desired_x, WORLD_WIDTH - self.width))
        desired_y = max(0, min(desired_y, WORLD_HEIGHT - self.height))

        if self.smoothing_enabled:
            self.camera.x += (desired_x - self.camera.x) * self.smoothing_speed
            self.camera.y += (desired_y - self.camera.y) * self.smoothing_speed
        else:
            self.camera.x = desired_x
            self.camera.y = desired_y


# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((player_size, player_size))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.topleft = player_pos

    def update(self, keys):
        if keys[pygame.K_LEFT]:
            self.rect.x -= player_speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += player_speed
        if keys[pygame.K_UP]:
            self.rect.y -= player_speed
        if keys[pygame.K_DOWN]:
            self.rect.y += player_speed

        # self.rect.x = max(0, min(self.rect.x, WORLD_WIDTH - player_size))
        # self.rect.y = max(0, min(self.rect.y, WORLD_HEIGHT - player_size))


class Quadtree:
    def __init__(self, boundary, capacity):
        self.boundary = boundary
        self.capacity = capacity
        self.tiles = []
        self.divided = False

    def count_tiles(self):
        count = len(self.tiles)
        if self.divided:
            count += self.northeast.count_tiles()
            count += self.northwest.count_tiles()
            count += self.southeast.count_tiles()
            count += self.southwest.count_tiles()
        return count

    def subdivide(self):
        x, y, w, h = self.boundary
        half_w, half_h = w // 2, h // 2

        self.northeast = Quadtree(
            pygame.Rect(x + half_w, y, half_w, half_h), self.capacity
        )
        self.northwest = Quadtree(pygame.Rect(x, y, half_w, half_h), self.capacity)
        self.southeast = Quadtree(
            pygame.Rect(x + half_w, y + half_h, half_w, half_h), self.capacity
        )
        self.southwest = Quadtree(
            pygame.Rect(x, y + half_h, half_w, half_h), self.capacity
        )

        self.divided = True

    def insert(self, tile):
        if not self.boundary.colliderect(tile.rect):
            return False

        if len(self.tiles) < self.capacity:
            self.tiles.append(tile)
            return True
        else:
            if not self.divided:
                self.subdivide()

            if self.northeast.insert(tile):
                return True
            if self.northwest.insert(tile):
                return True
            if self.southeast.insert(tile):
                return True
            if self.southwest.insert(tile):
                return True

    def query(self, range, found=None):
        if found is None:
            found = []

        # found.extend(self.tiles)

        if not self.boundary.colliderect(range):
            return found

        for tile in self.tiles:
            if range.colliderect(tile.rect):
                found.append(tile)

        if self.divided:
            self.northeast.query(range, found)
            self.northwest.query(range, found)
            self.southeast.query(range, found)
            self.southwest.query(range, found)

        return found

    def draw(self, surface, offset):
        adjusted_boundary = self.boundary.move(-offset.x, -offset.y)
        pygame.draw.rect(surface, GREEN, adjusted_boundary, 1)

        if self.divided:
            self.northeast.draw(surface, offset)
            self.northwest.draw(surface, offset)
            self.southeast.draw(surface, offset)
            self.southwest.draw(surface, offset)


# Viewport class
class Viewport:
    def __init__(self, x, y, width, height, border_color=BLACK, track_target=True):
        self.rect = pygame.Rect(x, y, width, height)
        self.camera = Camera(width, height)
        self.border_color = border_color
        self.track_target = track_target
        self.quadtrees = [
            Quadtree(pygame.Rect(0, 0, WORLD_WIDTH, WORLD_HEIGHT), 4) for _ in range(2)
        ]

    def insert_into_quadtrees(self, layers):
        for idx, (speed_factor, sprites) in enumerate(layers):
            for sprite in sprites:
                self.quadtrees[idx].insert(sprite)

    def render(self, surface, layers, target):
        if self.track_target:
            self.camera.update(target)

        # Create a temporary surface for drawing
        temp_surface = pygame.Surface((self.rect.width, self.rect.height))
        temp_surface.fill(WHITE)

        for idx, (speed_factor, sprites) in enumerate(layers):
            # Calculate the scroll offset based on the camera position and speed factor
            scroll_offset_x = self.camera.camera.x * (1 - speed_factor)
            scroll_offset_y = self.camera.camera.y * (1 - speed_factor)

            # Create a query rect with the same dimensions as the camera but offset for parallax
            query_rect = pygame.Rect(
                self.camera.camera.x * speed_factor,
                self.camera.camera.y * speed_factor,
                self.camera.camera.width,
                self.camera.camera.height,
            )
            tile_size = 128
            query_rect = query_rect.inflate(tile_size * 2, tile_size * 2)

            # Debug output
            # print(f"Layer {idx} ({'Background' if idx == 0 else 'Foreground'}):")
            # print(f"  Speed Factor: {speed_factor}")
            # print(f"  Camera Rect: {self.camera.camera}")
            # print(f"  Scroll Offset: ({scroll_offset_x}, {scroll_offset_y})")
            # print(f"  Query Rect: {query_rect}")

            # # Query the quadtree for visible sprites
            visible_sprites = self.quadtrees[idx].query(query_rect)
            # print(f"  Sprites: {len(visible_sprites)}")

            # Render visible sprites
            for sprite in visible_sprites:
                temp_surface.blit(sprite.image, self.camera.apply(sprite, speed_factor))

        # Draw the player
        temp_surface.blit(target.image, self.camera.apply(target))

        # Draw border around the inner rect (camera margins)
        border_rect = pygame.Rect(
            camera_margin_x,
            camera_margin_y,
            self.rect.width - 2 * camera_margin_x,
            self.rect.height - 2 * camera_margin_y,
        )
        pygame.draw.rect(temp_surface, BLACK, border_rect, 2)

        # Blit the temporary surface to the main surface
        surface.blit(temp_surface, self.rect.topleft)

        # Draw the viewport border
        pygame.draw.rect(surface, self.border_color, self.rect, 2)

    # def render(self, surface, layers, target):
    #     if self.track_target:
    #         self.camera.update(target)

    #     temp_surface = pygame.Surface((self.rect.width, self.rect.height))
    #     temp_surface.fill(WHITE)
    #     for idx, (speed_factor, sprites) in enumerate(layers):
    #         # Calculate the scroll offset based on the camera position and speed factor
    #         scroll_offset_x = self.camera.camera.x * (1 - speed_factor)
    #         scroll_offset_y = self.camera.camera.y * (1 - speed_factor)

    #         # Calculate the correct query rectangle size
    #         query_rect_width = self.rect.width / speed_factor
    #         query_rect_height = self.rect.height / speed_factor
    #         print(query_rect_width)
    #         print(query_rect_height)
    #         print("------")

    #         # Adjust the query rectangle based on the scroll offset
    #         query_rect = self.camera.camera.inflate(
    #             query_rect_width, query_rect_height
    #         ).move(scroll_offset_x, scroll_offset_y)

    #         # Debug output
    #         # print(f"Layer {idx} ({'Background' if idx == 0 else 'Foreground'}):")
    #         # print(f"  Speed Factor: {speed_factor}")
    #         # print(f"  Camera Rect: {self.camera.camera}")
    #         # print(f"  Scroll Offset: ({scroll_offset_x}, {scroll_offset_y})")
    #         # print(f"  Query Rect: {query_rect}")

    #         # Query the quadtree for visible sprites
    #         visible_sprites = self.quadtrees[idx].query(query_rect)

    #         # for idx, (speed_factor, sprites) in enumerate(layers):

    #         #     query_rect = self.camera.camera.inflate(
    #         #         self.rect.width / speed_factor, self.rect.height / speed_factor
    #         #     )
    #         #     # query_rect = self.camera.camera.inflate(
    #         #     #     (self.rect.width / speed_factor) + 512,
    #         #     #     (self.rect.height / speed_factor) + 512,
    #         #     # )

    #         #     visible_sprites = self.quadtrees[idx].query(query_rect)

    #         for sprite in visible_sprites:
    #             temp_surface.blit(sprite.image, self.camera.apply(sprite, speed_factor))

    #     temp_surface.blit(target.image, self.camera.apply(target))

    #     border_rect = pygame.Rect(
    #         camera_margin_x,
    #         camera_margin_y,
    #         self.rect.width - 2 * camera_margin_x,
    #         self.rect.height - 2 * camera_margin_y,
    #     )
    #     pygame.draw.rect(temp_surface, BLACK, border_rect, 2)

    #     surface.blit(temp_surface, self.rect.topleft)

    #     pygame.draw.rect(surface, self.border_color, self.rect, 2)


# Tile class for the tilemap
class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


# Load the tilemap
tmx_data = load_pygame("big-map.tmx")

# Create layers for the tilemap
layer_names = ["foreground", "background"]
tile_layers = {name: pygame.sprite.Group() for name in layer_names}

# Initialize the quadtree capacity for tile layers
quadtree_capacity = 1

# Populate the tile layers with tiles from the tilemap
max_x = max_y = 0
for layer in tmx_data.visible_layers:
    if layer.name in layer_names:
        for x, y, surf in layer.tiles():
            pos = (x * 128, y * 128)
            tile = Tile(pos=pos, surf=surf, groups=tile_layers[layer.name])
            if x > max_x:
                max_x = x
            if y > max_y:
                max_y = y

# Update WORLD_WIDTH and WORLD_HEIGHT based on the tilemap dimensions
WORLD_WIDTH = (max_x + 1) * 128
WORLD_HEIGHT = (max_y + 1) * 128

# Initialize player
player = Player()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

# Combine tile layers into layers for rendering
layers = [(0.5, tile_layers["background"]), (1, tile_layers["foreground"])]
# layers = [(1, tile_layers["foreground"])]

# Initialize viewports with different border colors
main_viewport = Viewport(
    0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, border_color=GREEN, track_target=True
)


# Insert sprites into quadtrees
main_viewport.insert_into_quadtrees(layers)
# mini_map_viewport.insert_into_quadtrees(layers)

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    player.update(keys)

    # Render viewports
    screen.fill(WHITE)
    main_viewport.render(screen, layers, player)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
