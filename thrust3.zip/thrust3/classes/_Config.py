import os


# class Config:
#     config_values = {
#         "original_screen_size": (640, 480),
#         "larger_screen_size": (640 * 2, 480 * 2),
#         "max_fps": 60,
#         "top_left": (0, 0),
#     }

#     @staticmethod
#     def get(key):
#         return Config.config_values.get(key)
