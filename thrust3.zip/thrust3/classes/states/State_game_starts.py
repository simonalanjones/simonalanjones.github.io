from classes.states.State_base import StateBase


class StateGameStarts(StateBase):
    def __init__(self):
        super().__init__()
        self.controllers = ["Tilemap"]
        self.add_listener("tilemap_loaded", self.on_tilemap_loaded)

    def enter(self, change_to):
        super().enter(change_to)
        self.callback_manager.callback("load_tilemap")
        print("here in enter")

    def update(self, events):
        super().update(events)

    def on_tilemap_loaded(self, data):
        print("on_tilemap_loaded")
        self.exit("GAME_PLAYING")
