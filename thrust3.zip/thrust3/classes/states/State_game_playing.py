from classes.states.State_base import StateBase


class StateGamePlaying(StateBase):
    def __init__(self):
        super().__init__()
        self.controllers = [
            "Player",
            "Input",
            "Tilemap",
            "PlayerMissile",
            "PlayerParticles",
            "Walker",
        ]

    def enter(self, change_to):
        super().enter(change_to)
        # print("in start game playing")

    def update(self, events):
        super().update(events)
