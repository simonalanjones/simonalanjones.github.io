import pygame
import random
from lib.Event_object import Event_object
from enum import Enum


class WalkerState(Enum):
    MOVING = 1
    WAVING = 2
    RUNNING_TO_PLAYER = 3


class Walker(pygame.sprite.Sprite, Event_object):
    def __init__(self, position):
        Event_object.__init__(self)
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load("graphics/lemming/walker_frame.png")
        self.position = position
        self.state = WalkerState.MOVING
        self.rect = self.image.get_rect(
            bottomleft=(self.position["x"], self.position["y"])
        )
        self.target = None

        self.boundary = None
        self.velocity_x = 1  # Initial velocity

        # Timer for changing direction
        self.change_direction_timer = random.randint(
            160, 200
        )  # Random frames until change
        self.frames_since_change = 0

    def set_target(self, target):
        self.target = target
        self.state = WalkerState.RUNNING_TO_PLAYER

    def clear_target(self):
        self.target = None
        self.state = WalkerState.MOVING

    def update(self, boundary):
        if self.state == WalkerState.MOVING:
            self.handle_boundary_collision(boundary)
            self.random_direction_change()
        elif self.state == WalkerState.RUNNING_TO_PLAYER and self.target:
            self.move_towards_target(boundary)

    def handle_boundary_collision(self, boundary):
        if self.rect.right >= boundary.rect.right:
            self.velocity_x = -1  # Move left
        elif self.rect.left <= boundary.rect.left:
            self.velocity_x = 1  # Move right
        self.rect.x += self.velocity_x

    def move_towards_target(self, boundary):
        if self.rect.x < self.target.rect.centerx:
            self.velocity_x = 1  # Move right towards the target
        elif self.rect.x > self.target.rect.centerx:
            self.velocity_x = -1  # Move left towards the target
        else:
            self.event_manager.notify("walker_saved", self)
            self.kill()
            return

        # Ensure movement stays within boundary limits
        if boundary.rect.left < self.rect.x < boundary.rect.right:
            self.rect.x += self.velocity_x

    def random_direction_change(self):
        self.frames_since_change += 1
        if self.frames_since_change >= self.change_direction_timer:
            self.change_direction()
            self.frames_since_change = 0
            self.change_direction_timer = random.randint(60, 100)  # Reset timer

    # def update(self, boundary):
    #     if self.state == WalkerState.MOVING:
    #         if self.rect.right >= boundary.rect.right:
    #             print("move left")
    #             self.velocity_x = -1  # Move left

    #         elif self.rect.left <= boundary.rect.left:
    #             print("move right")
    #             self.velocity_x = +1  # Move right

    #         self.rect.x += self.velocity_x
    #     # Boundary checking
    #     # if self.boundary and not self.boundary.check_collision(self):
    #     #   self.change_direction()

    #     self.frames_since_change += 1
    #     if self.frames_since_change >= self.change_direction_timer:
    #         self.change_direction()
    #         self.frames_since_change = 0
    #         self.change_direction_timer = random.randint(
    #             60, 100
    #         )  # Random frames until next change

    #     elif self.state == WalkerState.RUNNING_TO_PLAYER and self.target:

    #         if self.rect.x < self.target.rect.centerx:
    #             self.velocity_x = 1  # Move right towards the target
    #         elif self.rect.x > self.target.rect.centerx:
    #             self.velocity_x = -1  # Move left towards the target
    #         else:
    #             self.event_manager.notify("walker_saved", self)
    #             self.kill()

    #         if self.rect.x < boundary.rect.right and self.rect.x > boundary.rect.left:
    #             self.rect.x += self.velocity_x

    def set_boundary(self, boundary):
        self.boundary = boundary

    def change_direction(self):
        # Randomly choose a new direction (left or right) within the speed limit
        direction = random.choice([-1, 1])  # Randomly choose -1 (left) or 1 (right)
        self.velocity_x = direction  # Set velocity in the x direction

    # def handle_collision(self, other):
    #     # Change direction when colliding with another walker
    #     self.change_direction()
    #     other.change_direction()
