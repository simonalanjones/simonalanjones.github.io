import math
import pygame


class Player2(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        self.image = pygame.image.load("graphics/ship32x32.png").convert_alpha()

        # make a copy of the image untouched for reference later in rotation
        self.base_image = self.image

        # initial x and y position
        self.x, self.y = 300, 220

        # create a vector2 for the sprite position/rect
        self.pos = pygame.Vector2(self.x, self.y)

        # create a rect based on the size of the image
        self.rect = self.image.get_rect()
        # place the rect center at the x,y position
        self.rect.center = self.pos

        # create an alternative rect which is a constant 60,60 width x height
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        # make the centre of the hit-rect based on the normal rect
        self.hit_rect.center = self.rect.center

        # starting rotation
        self.rotation = 0

        self.rotate_speed = 4  # Base rotation speed
        self.max_rotate_speed = 5  # Maximum rotation speed
        self.scaling_factor = 0.4  # Starting value for the scaling factor

        self.thrusting = False
        self.back_thrusting = False

        self.max_backward_velocity = -3  # Maximum velocity achievable with back thrust

        self.ship_mass = 2.5  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.03  # Gravity affecting the rocket
        # self.gravity = 0.0
        # self.thrust_power = 0.5  # Power of thrust

        self.current_thrust_power = 0  # Current thrust power
        self.max_thrust_power = 0.3  # Maximum thrust power
        self.thrust_increment = 0.02  # Incremental increase in thrust power
        self.thrust_decrement = 0.02  # Incremental decrease in thrust power

        # landing related vars
        self.landed = False
        self.landing_max_velocity = 3

        self.landing_rotation_left_threshold = 24
        self.landing_rotation_right_threshold = 340
        self.landing_tile_position_threshold = 20

    def get_ship(self):
        return self

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def get_total_collision_rect(self, sprite_group):
        # Might be landing between two sprites
        # Calculate the bounding box of the combined area covered by all (usually max two) sprites in the group
        left = min(sprite.rect.left for sprite in sprite_group)
        top = min(sprite.rect.top for sprite in sprite_group)
        right = max(sprite.rect.right for sprite in sprite_group)
        bottom = max(sprite.rect.bottom for sprite in sprite_group)

        # amount to add to either side of the tile collision group
        tolerance = self.landing_tile_position_threshold

        combined_rect = pygame.Rect(
            left - tolerance,
            top,
            right - left + tolerance * 2,  # Add tolerance to both left and right sides
            bottom - top,
        )
        return combined_rect

    def can_land_on_rect(self, total_collision_rect):

        # Check if the player is within the horizontal bounds of the combined area
        if (
            self.rect.bottom < total_collision_rect.centery
            and self.rect.left > total_collision_rect.left
            and self.rect.right < total_collision_rect.right
        ):
            return True
        return False

    def collision_direction_word(self, tile):
        # Check for collision and handle overlaps
        player = self
        collision = pygame.sprite.collide_rect(player, tile)
        if collision:
            player_rect = player.rect
            tile_rect = tile.rect

            # Get the center points of the player and tile sprites
            player_center_x = player_rect.centerx
            player_center_y = player_rect.centery
            tile_center_x = tile_rect.centerx
            tile_center_y = tile_rect.centery

            # Calculate the horizontal and vertical distances between centers
            dx = player_center_x - tile_center_x
            dy = player_center_y - tile_center_y

            # Determine the direction of overlap based on the majority of the player sprite's position
            if abs(dx) > abs(dy):
                # Majority of player sprite is left or right of the tile
                if dx < 0:
                    return "right"
                else:
                    return "left"
            else:
                # Majority of player sprite is above or below the tile
                if dy < 0:
                    return "bottom"
                else:
                    return "top"

    def check_landing_velocity_and_rotation(self):
        if self.vy < self.landing_max_velocity and (
            self.rotation < self.landing_rotation_left_threshold
            or self.rotation > self.landing_rotation_right_threshold
        ):
            return True
        else:
            return False

    def land_ship(self):
        self.vx = 0
        self.vy = 0
        self.landed = True
        self.rotation = 0

    def check_collisions(self, sprite_group):

        # self.particle_container.check_collisions(sprite_group)

        if not self.landed:
            hits = pygame.sprite.spritecollide(
                self, sprite_group, False, self.collide_hit_rect
            )
            if hits:
                sprite = hits[0]

                collision_word = self.collision_direction_word(sprite)
                # print(collision_word)

                total_collision_rect = self.get_total_collision_rect(hits)

                if collision_word == "bottom":

                    if (
                        self.can_land_on_rect(total_collision_rect)
                        and self.check_landing_velocity_and_rotation()
                    ):
                        self.land_ship()

                    # collision below but doesn't satisfy landing requirements
                    else:
                        self.handle_collision_bottom(sprite)

                elif collision_word == "right":
                    self.handle_collision_right()

                elif collision_word == "left":
                    self.handle_collision_left()

                elif collision_word == "top":
                    self.handle_collision_top()

    def handle_collision_right(self):
        # print("right")
        if self.vx > 0 and self.vy > 0:
            # print("hit down to right")
            self.vx = -(self.vx / 2)
            self.pos.x -= 5
            return

        elif self.vx > 0 and self.vy < 0:
            # print("hit up to right")
            self.vx = -(self.vx / 2)
            self.pos.x -= 5

    def handle_collision_left(self):
        # print("left")
        if self.vx < 0 and self.vy > 0:
            # print("hit down to left")
            self.vx = -(self.vx / 2)
            self.pos.x += 5
            return
        elif self.vx < 0 and self.vy < 0:
            # print("hit up to left")
            self.vx = -(self.vx / 2)
            self.pos.x += 5

    def handle_collision_top(self):
        self.vy = -(self.vy / 2)
        self.pos.y += 5

    # not currently used
    def handle_correction(self):
        # reposition ship towards 0 degress with each bounce
        clockwise_difference = abs(self.rotation - 0)
        counterclockwise_difference = abs(360 - self.rotation)
        if clockwise_difference < counterclockwise_difference:
            self.rotation -= 5
        else:
            self.rotation += 5

    def handle_collision_bottom(self, sprite):
        print("cant land")
        self.pos.y = sprite.rect.top - (self.rect.height / 2)
        self.vx = -(self.vx / 2)
        self.vy = -self.vy / 2

    def get_rear_exhaust_position(self):
        rotation_radians = math.radians(self.rotation)

        distance_from_bottom = self.rect.height / 2
        offset_x = distance_from_bottom * math.sin(rotation_radians)
        offset_y = distance_from_bottom * math.cos(rotation_radians)

        exhaust_position = pygame.Vector2(self.pos.x + offset_x, self.pos.y + offset_y)
        return exhaust_position

    def update(self):

        # this should be an event driven rather than feeding the ship directly
        # feed the classes manually from invaders and wire them up
        # self.particle_emitter.emit_from_ship_rear()
        # self.particle_emitter.update()
        # if not self.rotation < 240 and self.rotation > 120:
        # print("stopping bt")
        #   self.back_thrusting = False

        rotation_radians = math.radians(self.rotation)

        distance_from_bottom = self.rect.height / 2
        offset_x = distance_from_bottom * math.sin(rotation_radians)
        offset_y = distance_from_bottom * math.cos(rotation_radians)

        # self.exhaust_position = pygame.Vector2(
        #     self.pos.x + offset_x, self.pos.y + offset_y
        # )

        # push this into particle container
        # ==== need to move this to event system ======
        # self.particle_container.update()

        # if (
        #     self.thrusting or self.current_thrust_power > 0.6
        # ) and not self.back_thrusting:
        #     self.particle_emitter.emit_from_ship_rear()

        if self.thrusting or self.back_thrusting:

            self.landed = False
            self.update_velocity()
        else:
            self.apply_drag()
            if self.current_thrust_power > 0:
                self.current_thrust_power -= self.thrust_decrement
                if self.current_thrust_power < 0:
                    self.current_thrust_power = 0

        if not self.landed:
            self.update_rotation()
            self.apply_gravity()

        # Update position based on velocity
        self.pos += pygame.Vector2(self.vx, self.vy)

        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=self.pos)
        self.hit_rect.center = self.rect.center

    def update_rotation(self):
        if not self.landed:
            # Calculate velocity magnitude
            velocity_magnitude = pygame.math.Vector2(self.vx, self.vy).length()

            # Dampen rotation speed based on velocity magnitude
            if velocity_magnitude > 0:
                # Calculate a new rotation speed based on velocity magnitude
                new_rotate_speed = self.max_rotate_speed / (
                    velocity_magnitude * self.scaling_factor
                )

                # Clamp the rotation speed to avoid it becoming too high
                self.rotate_speed = min(new_rotate_speed, self.max_rotate_speed)
            else:
                # Reset rotation speed when velocity magnitude is zero
                self.rotate_speed = self.max_rotate_speed

    def update_velocity(self):

        if self.current_thrust_power < self.max_thrust_power:
            self.current_thrust_power += self.thrust_increment

        if self.thrusting:
            # Apply forward thrust

            thrust_force_x = self.current_thrust_power * math.cos(
                math.radians(self.rotation + 90)
            )
            thrust_force_y = -self.current_thrust_power * math.sin(
                math.radians(self.rotation + 90)
            )
            acceleration_x = thrust_force_x / self.ship_mass
            acceleration_y = thrust_force_y / self.ship_mass

        elif self.back_thrusting:  # and self.rotation < 240 and self.rotation > 120:

            back_thrust_force_x = self.current_thrust_power * math.cos(
                math.radians(self.rotation - 90)
            )
            back_thrust_force_y = -self.current_thrust_power * math.sin(
                math.radians(self.rotation - 90)
            )

            # Apply a scaling factor to limit back thrust compared to forward thrust
            back_thrust_scaling_factor = 0.3  # Adjust this factor as needed
            back_thrust_force_x *= back_thrust_scaling_factor
            back_thrust_force_y *= back_thrust_scaling_factor

            # Calculate acceleration using Newton's second law: F = ma
            acceleration_x = back_thrust_force_x / self.ship_mass
            acceleration_y = back_thrust_force_y / self.ship_mass
        else:
            # No thrust applied
            acceleration_x = 0
            acceleration_y = 0

        # Update velocity based on acceleration
        self.vx += acceleration_x
        self.vy += acceleration_y

        # Cap velocities
        self.vx = max(min(self.vx, 5), -5)
        self.vy = max(min(self.vy, 5), -5)

    def check_can_back_thrust(self):
        return not self.landed
        # if self.rotation < 240 and self.rotation > 120 and not self.landed:
        #    return True

    def apply_gravity(self):
        # Apply gravity based on ship orientation and mass
        gravity_force = self.gravity * self.ship_mass

        # Update velocity based on gravity
        self.vy += gravity_force

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

    def rotate_left(self, data):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self, data):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    def start_back_thrust(self):
        if self.check_can_back_thrust():
            self.back_thrusting = True
            self.current_thrust_power = 1

    def stop_back_thrust(self):
        self.back_thrusting = False
        self.current_thrust_power = 1

    # call when space key pressed
    def start_thrusting(self, data):
        self.landed = False
        self.thrusting = True

    # called when space key released
    def stop_thrust(self, data):
        self.thrusting = False
        # self.current_thrust_power = 0
