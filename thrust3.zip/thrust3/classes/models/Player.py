import math
import pygame
from lib.Physics_object import PhysicsObject


class Player(PhysicsObject):
    def __init__(self):
        position = {"x": 64, "y": 64}
        velocity = {"speed": 0, "direction": 0}
        acceleration = 3
        rotation = 0
        # rotationSpeed = 0.07
        rotationSpeed = 20 * (math.pi / 180)  # 30 degrees in radians

        max_speed = 5
        friction = 0.99
        mass = 4.8

        super().__init__(
            position,
            velocity,
            acceleration,
            rotation,
            rotationSpeed,
            max_speed,
            friction,
            mass,
        )

        self.is_thrusting = False
        self.thrust_power = 0.2
        self.image = pygame.image.load("graphics/ship32x32.png")
        self.mask = pygame.mask.from_surface(self.image)
        self.original_image = self.image
        self.rect = self.image.get_rect(center=(self.position["x"], self.position["y"]))
        self.hit_rect = pygame.Rect(0, 0, 16, 16)
        self.hit_rect.center = self.rect.center

        self.landed = False
        self.landing_max_velocity_speed = 1

        self.landing_rotation_left_threshold = 24
        self.landing_rotation_right_threshold = 340
        self.landing_tile_position_threshold = 20

        self.rotation_delay = 0
        self.rotation_delay_max = 2

    # def update_rotation_delay(self):
    #     self.rotation_delay += 1
    #     if self.rotation_delay >= self.rotation_delay_max:
    #         self.rotation_delay = 0

    def snap_to_nearest_rotation(self):
        segment_angle = (
            2 * math.pi / 24
        )  # 12 segments in a full circle (30 degrees per segment)
        snapped_rotation = round(self.rotation / segment_angle) * segment_angle
        self.rotation = snapped_rotation

    def is_within_rotation_range(self):
        return self.rotation < 0.5 or self.rotation > 6

    def is_within_landing_speed(self):
        return self.velocity["speed"] < self.landing_max_velocity_speed

    def check_landing_velocity_and_rotation(self):
        if self.is_within_landing_speed() and self.is_within_rotation_range():
            return True
        else:
            return False

    def land_ship(self):
        print("landed")
        self.velocity = {"speed": 0, "direction": 0}
        self.landed = True
        self.rotation = 0
        self.rotate_image()
        self.event_manager.notify("player_landed")

    def get_total_collision_rect(self, sprite_group):
        # Might be landing between two sprites
        # Calculate the bounding box of the combined area covered by all (usually max two) sprites in the group
        left = min(sprite.rect.left for sprite in sprite_group)
        top = min(sprite.rect.top for sprite in sprite_group)
        right = max(sprite.rect.right for sprite in sprite_group)
        bottom = max(sprite.rect.bottom for sprite in sprite_group)

        # amount to add to either side of the tile collision group
        tolerance = self.landing_tile_position_threshold

        combined_rect = pygame.Rect(
            left - tolerance,
            top,
            right - left + tolerance * 2,  # Add tolerance to both left and right sides
            bottom - top,
        )
        return combined_rect

    def can_land_on_rect(self, total_collision_rect):
        # Check if the player is within the horizontal bounds of the combined area
        if (
            self.rect.bottom < total_collision_rect.centery
            and self.rect.left > total_collision_rect.left
            and self.rect.right < total_collision_rect.right
        ):
            return True
        return False

    def collision_direction_word(self, tile):
        collision = pygame.sprite.collide_rect(self, tile)
        if collision:
            player_rect = self.rect
            tile_rect = tile.rect

            player_center_x = player_rect.centerx
            player_center_y = player_rect.centery
            tile_center_x = tile_rect.centerx
            tile_center_y = tile_rect.centery

            dx = player_center_x - tile_center_x
            dy = player_center_y - tile_center_y

            if abs(dx) > abs(dy):
                if dx < 0:
                    return "right"
                else:
                    return "left"
            else:
                if dy < 0:
                    return "bottom"
                else:
                    return "top"

    def check_collisions(self, sprite_group):

        # when looping through the sprites for collision check if any are destructible?
        if not self.landed:
            # hits = pygame.sprite.spritecollide(
            #     self, sprite_group, False, self.collide_hit_rect
            # )
            hits = pygame.sprite.spritecollide(
                self, sprite_group, False, pygame.sprite.collide_mask
            )
            if hits:
                sprite = hits[0]
                collision_word = self.collision_direction_word(sprite)
                total_collision_rect = self.get_total_collision_rect(hits)

                if collision_word == "bottom":

                    if (
                        self.can_land_on_rect(total_collision_rect)
                        and self.check_landing_velocity_and_rotation()
                    ):
                        self.land_ship()

                self.reduce_velocity_by_half()
                self.bounce_away(collision_word, sprite)
                return True

    def bounce_away(self, collision_word, colliding_object):
        # Calculate the bounce amount
        bounce_amount = 1

        # Reduce velocity by half
        self.velocity["speed"] *= 0.5

        # Adjust the player's position based on the collision direction
        if collision_word == "bottom":
            self.position["y"] = (
                colliding_object.rect.top - bounce_amount - self.rect.height / 2
            )
        elif collision_word == "top":
            self.position["y"] = (
                colliding_object.rect.bottom + bounce_amount + self.rect.height / 2
            )
        elif collision_word == "right":
            self.position["x"] = (
                colliding_object.rect.left - bounce_amount - self.rect.width / 2
            )
        elif collision_word == "left":
            self.position["x"] = (
                colliding_object.rect.right + bounce_amount + self.rect.width / 2
            )

        # Reflect the velocity vector against the normal vector of the collision surface
        if collision_word == "bottom" or collision_word == "top":
            normal_vector = (0, 1 if collision_word == "bottom" else -1)
        else:
            normal_vector = (1 if collision_word == "right" else -1, 0)

        # Calculate velocity components
        vx = self.velocity["speed"] * math.cos(self.velocity["direction"])

        vy = self.velocity["speed"] * math.sin(self.velocity["direction"])

        # Reflect the velocity components
        vx, vy = self.reflect_vector((vx, vy), normal_vector)

        # Convert back to speed and direction
        self.velocity = self.comp_to_vector(vx, vy)

        # Update rect and hit_rect
        self.rect.center = (self.position["x"], self.position["y"])
        self.hit_rect.center = self.rect.center

    def reflect_vector(self, velocity, normal):
        dot_product = velocity[0] * normal[0] + velocity[1] * normal[1]
        reflected = (
            velocity[0] - 2 * dot_product * normal[0],
            velocity[1] - 2 * dot_product * normal[1],
        )
        return reflected

    # move this to base object
    def reduce_velocity_by_half(self):
        self.velocity["speed"] *= 0.5

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def on_rotate_right(self, data):
        self.rotation_delay += 1
        if self.rotation_delay >= self.rotation_delay_max:
            self.rotation_delay = 0
            if self.landed == False:
                self.rotation += self.rotationSpeed
                self.snap_to_nearest_rotation()

    def on_rotate_left(self, data):
        self.rotation_delay += 1
        if self.rotation_delay >= self.rotation_delay_max:
            self.rotation_delay = 0
            if self.landed == False:
                self.rotation -= self.rotationSpeed
                self.snap_to_nearest_rotation()

    def update(self):
        # print(self.velocity["speed"])
        if not self.landed:
            self.update_physics()

        if self.is_thrusting:
            self.landed = False
            self.player_thrust()

        self.rotation = self.keep_angle_in_range(self.rotation)

    def player_thrust(self):
        _direction = self.rotation - (math.pi / 2)
        _direction = math.floor(_direction * 10) / 10
        # print(_direction)

        thrust_force = {
            "speed": self.thrust_power / self.mass,
            "direction": _direction,
        }
        new_velocity = self.add_vectors(self.velocity, thrust_force)
        if new_velocity["speed"] > self.max_speed:
            new_velocity["speed"] = self.max_speed
        self.velocity = new_velocity
        # print(self.velocity)

    def start_thrusting(self):
        self.is_thrusting = True
        if self.velocity["speed"] == 0:
            self.event_manager.notify("player_launched")

    def stop_thrusting(self):
        self.is_thrusting = False
