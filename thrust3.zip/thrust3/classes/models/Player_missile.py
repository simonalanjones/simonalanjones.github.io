import math
import pygame
from lib.Physics_object import PhysicsObject


class PlayerMissile(PhysicsObject):
    def __init__(self, rotation, position):
        adjusted_rotation = (
            rotation - math.pi / 2
        )  # Adjusting rotation by 90 degrees counter-clockwise
        velocity = {
            "speed": 20,
            "direction": adjusted_rotation,
        }  # Fixed speed and direction based on rotation
        acceleration = 0
        max_speed = 2
        friction = 0.97  # No friction for the missile
        mass = 0.2
        super().__init__(
            position, velocity, acceleration, rotation, 0, max_speed, friction, mass
        )

        self.image = pygame.image.load("graphics/missile.png")
        self.original_image = self.image
        self.rect = self.image.get_rect(center=(self.position["x"], self.position["y"]))
        self.hit_rect = pygame.Rect(0, 0, 8, 24)
        self.hit_rect.center = self.rect.center
        self.mask = pygame.mask.from_surface(self.image)  # Create a mask from the image

    def update(self):
        self.update_physics()
        self.update_rotation_to_velocity()
        self.rotate_image()  # Ensure the image rotates correctly based on direction

    def update_rotation_to_velocity(self):
        # Calculate the angle from the velocity components
        vx = self.velocity["speed"] * math.cos(self.velocity["direction"])
        vy = self.velocity["speed"] * math.sin(self.velocity["direction"])
        # Calculate the rotation angle based on the velocity direction, adjusted by 90 degrees clockwise
        self.rotation = math.atan2(vy, vx) + math.pi / 2

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def check_collisions(self, sprites_around_missile):
        hits = pygame.sprite.spritecollide(
            self, sprites_around_missile, False, pygame.sprite.collide_mask
        )
        for sprite in hits:
            if hasattr(sprite, "is_destructible"):
                if sprite.is_destructible:
                    sprite.take_damage()
                    print(sprite.is_destructible)  # No parentheses here

        if hits:
            return True

    # def _check_collisions(self, sprites_around_missile):
    #     hits = pygame.sprite.spritecollide(
    #         self, sprites_around_missile, False, self.collide_hit_rect
    #     )
    #     for sprite in hits:
    #         if hasattr(sprite, "is_destructible"):
    #             sprite.take_damage()
    #             print(sprite.is_destructible)  # No parentheses here

    #     if hits:
    #         return True
