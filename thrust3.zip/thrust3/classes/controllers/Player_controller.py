from pygame.locals import *
from lib.Controller import Controller
from lib.Viewport_manager import ViewportManager
from classes.models.Player import Player

# from classes.models.Player import Player2

# from lib.Particles import ExhaustParticleEmitter
from lib.Tilemap_manager import TilemapManager


class PlayerController(Controller):
    def __init__(self):
        super().__init__()

        self.player = Player()
        self.register_callback("get_player", self.get_player)
        self.add_listener("left_button_pressed", self.player.on_rotate_left)
        self.add_listener("right_button_pressed", self.player.on_rotate_right)
        self.add_listener("on_player_start_thrust", self.on_player_start_thrust)
        self.add_listener("on_player_stop_thrust", self.on_player_end_thrust)

    def game_ready(self):
        self.tilemap_manager: TilemapManager = TilemapManager.get_instance()
        self.viewport = ViewportManager.get_instance().get_primary_viewport()
        self.viewport.add_layer("player_layer", 10)
        self.viewport.set_target(self.player)

    def update(self, events, dt=0):
        self.player.update()
        self.viewport.add_sprite_to_layer("player_layer", self.player)
        self.check_player_collisions()

    def check_player_collisions(self):
        sprites_around_player = self.tilemap_manager.get_sprites_around_sprite(
            "foreground",
            self.player,
        )

        # update shield, screen shake etc
        if self.player.check_collisions(sprites_around_player):
            pass

    def get_player(self):
        return self.player

    def on_player_start_thrust(self, data):
        self.player.start_thrusting()

    def on_player_end_thrust(self, data):
        self.player.stop_thrusting()
