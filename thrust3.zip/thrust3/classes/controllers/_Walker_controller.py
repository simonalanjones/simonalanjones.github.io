import math
import pygame
from lib.Controller import Controller
from lib.Tilemap_manager import TilemapManager
from lib.Viewport_manager import ViewportManager
from classes.models.Walker import Walker
from classes.containers.Walker_container import WalkerContainer
from lib.Boundary import Boundary


class WalkerController(Controller):
    def __init__(self):
        super().__init__()
        self.tilemap_manager = TilemapManager.get_instance()
        self.add_listener("player_landed", self.on_player_landed)
        self.add_listener("player_launched", self.on_player_launched)
        self.walker_containers = []

    def on_player_landed(self, data):
        player = self.callback_manager.callback("get_player")
        for container in self.walker_containers:
            if container.boundary and container.boundary.rect.colliderect(player.rect):
                container.notify_landed(player)

    def on_player_launched(self, data):
        player = self.callback_manager.callback("get_player")
        for container in self.walker_containers:
            if container.boundary and container.boundary.rect.colliderect(player.rect):
                print("launched")
                container.notify_launched()

    def game_ready(self):
        self.viewport = ViewportManager.get_instance().get_primary_viewport()
        data = self.tilemap_manager.get_data()

        # Process object groups
        for group in data.objectgroups:
            if group.name == "walkers":
                walker_container = WalkerContainer()
                for obj in group:
                    if obj.type == "walker":
                        walker = Walker(position={"x": obj.x, "y": obj.y})
                        walker_container.add_walker_sprite(walker)

                    elif obj.type == "boundary":
                        boundary = Boundary(
                            position=(obj.x, obj.y), size=(obj.width, obj.height)
                        )
                        walker_container.set_boundary(boundary)

                self.walker_containers.append(walker_container)

    def update(self, events, dt=0):

        player = self.callback_manager.callback("get_player")
        # if not player.landed:
        #     for container in self.walker_containers:

        #         center1 = container.boundary.rect.center
        #         center2 = player.rect.center

        #         # Calculate the distance between the centers
        #         distance = math.sqrt(
        #             (center1[0] - center2[0]) ** 2 + (center1[1] - center2[1]) ** 2
        #         )
        #         if distance < 450:
        #             print("close")

        for walker_container in self.walker_containers:
            center1 = walker_container.boundary.rect.center
            center2 = player.rect.center
            distance = math.sqrt(
                (center1[0] - center2[0]) ** 2 + (center1[1] - center2[1]) ** 2
            )
            if distance < 1300:
                walker_container.update()
                for walker_sprite in walker_container.get_walkers():
                    self.viewport.add_sprite_to_layer(
                        "player_missile_layer", walker_sprite
                    )
