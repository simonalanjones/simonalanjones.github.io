import math
import pygame
from pygame.locals import *
from lib.Controller import Controller
from lib.Viewport_manager import ViewportManager
from lib.Tilemap_manager import TilemapManager
from classes.models.Player_missile import PlayerMissile


class PlayerMissileController(Controller):
    def __init__(self):
        super().__init__()
        self.player_missile_group = pygame.sprite.Group()
        self.add_listener("fire_button_pressed", self.on_launch_missile)
        self.reset_frame_delay()
        self.missile_side = "left"  # This will keep track of which side to launch from

    def reset_frame_delay(self):
        self.frames_delay = 10
        self.can_relase_missile = True

    def game_ready(self):
        self.viewport = ViewportManager.get_instance().get_primary_viewport()
        self.tilemap_manager: TilemapManager = TilemapManager.get_instance()
        self.player = self.callback_manager.callback("get_player")

    def update(self, events, dt=0):
        # print('number of missiles active', len(self.player_missile_group))
        if not self.can_relase_missile:
            self.frames_delay -= 1
            if self.frames_delay <= 0:
                self.reset_frame_delay()

        for missile_sprite in self.player_missile_group:
            sprites_around_missile = self.tilemap_manager.get_sprites_around_sprite(
                "foreground",
                missile_sprite,
            )

            if not missile_sprite.check_collisions(sprites_around_missile):
                missile_sprite.update()
                self.viewport.add_sprite_to_layer(
                    "player_missile_layer", missile_sprite
                )
            else:
                # print("killed sprite")
                missile_sprite.kill()

    def on_launch_missile(self, player):
        if self.can_relase_missile:
            self.reset_frame_delay()
            self.can_relase_missile = False

            # Map rotation from [0, 6] to [0, 360] degrees
            angle = self.player.rotation * 60  # 6 * 60 = 360 degrees
            rad = math.radians(angle)  # Convert angle to radians

            # Define the offset distance for launching the missile
            offset_distance = 20

            # Calculate the offset position based on rotation
            offset_x = math.cos(rad) * offset_distance
            offset_y = math.sin(rad) * offset_distance

            if self.missile_side == "left":
                launch_position = {
                    "x": self.player.position["x"] - offset_x,
                    "y": self.player.position["y"] - offset_y,
                }
                self.missile_side = "right"
            else:
                launch_position = {
                    "x": self.player.position["x"] + offset_x,
                    "y": self.player.position["y"] + offset_y,
                }
                self.missile_side = "left"

            missile = PlayerMissile(self.player.rotation, launch_position)
            self.player_missile_group.add(missile)
