import pygame
from pygame.locals import *
from lib.Controller import Controller


# could be configured with allowed keys
# across different screens (game/highscore entry etc)
# maybe the init method could have a mode which would define the keys it tracks
# and it could be switched as well as set during config
class InputController(Controller):
    def __init__(self):
        super().__init__()

    def update(self, events, dt=0):

        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            self.event_manager.notify("left_button_pressed")
        elif keys[pygame.K_RIGHT]:
            self.event_manager.notify("right_button_pressed")
        elif keys[pygame.K_SPACE]:
            self.event_manager.notify("fire_button_pressed")

        for event in events:

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    self.event_manager.notify("escape_button_pressed")
                elif event.key == K_UP:
                    self.event_manager.notify("on_player_start_thrust")

            elif event.type == KEYUP:
                if event.key == K_F12:
                    self.event_manager.notify("pause_pressed")
                elif event.key == K_UP:
                    self.event_manager.notify("on_player_stop_thrust")
