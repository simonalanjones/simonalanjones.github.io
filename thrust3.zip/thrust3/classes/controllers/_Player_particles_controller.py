import pygame
from lib.Controller import Controller
from lib.Particles import ParticleEmitter, ParticleContainer, ExhaustEmitter
from lib.Viewport_manager import ViewportManager


class PlayerParticlesController(Controller):
    def __init__(self):
        super().__init__()

        self.particle_emitter = ExhaustEmitter()
        self.add_listener("on_player_start_thrust", self.on_player_start_thrust)
        self.add_listener("on_player_stop_thrust", self.on_player_end_thrust)

    def game_ready(self):
        self.viewport_manager: ViewportManager = ViewportManager.get_instance()
        self.viewport = self.viewport_manager.get_primary_viewport()
        self.viewport.add_layer("player_missile_layer", 9)
        self.player = self.callback_manager.callback("get_player")

    def on_player_start_thrust(self, data):
        player = self.player

        player_position = {
            "x": self.player.position["x"],
            "y": self.player.position["y"],
        }
        self.particle_emitter.emit(player_position, self.player.rotation)

        # particle = Particle(
        #     {"x": player.position["x"], "y": player.position["y"]}, player.rotation
        # )
        # particle.velocity["speed"] = -20

        # self.particle_group.add(particle)  # old way

        # self.particle_emitter.emit(player_position, player.rotation)

    def on_player_end_thrust(self, data):
        pass
        # print("Player end thrust!")

    def update(self, events, dt=0):

        particle_sprites = self.particle_emitter.get_particles()
        for particle in particle_sprites:
            particle.update()
            self.viewport.add_sprite_to_layer("player_missile_layer", particle)
