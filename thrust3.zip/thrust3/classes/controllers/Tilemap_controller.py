import pygame
from pygame.locals import *
from lib.Controller import Controller
from lib.Tilemap_manager import TilemapManager
from lib.Camera_manager import CameraManager
from lib.Camera import Camera
from lib.Viewport import Viewport
from lib.Viewport_manager import ViewportManager


class TilemapController(Controller):
    def __init__(self):
        super().__init__()
        self.viewport: Viewport
        self.tile_size: int = 32
        # self.layer_names = ["foreground", "midground", "background"]
        self.layer_names = ["foreground", "foreground-far"]
        # self.parallax_factors = {"background": 0.5, "midground": 0.75, "foreground": 1}
        self.parallax_factors = {"foreground": 1, "foreground-far": 1}

        self.tilemap_manager = TilemapManager.get_instance()
        self.viewport = ViewportManager.get_instance().get_primary_viewport()

    def game_ready(self):
        pass

    def get_foreground_sprites(self):
        pass
        # return self.

    def get_tilemap_query_rect(self, speed_factor):

        base_query_rect = self.viewport.get_camera_rect()

        # Apply the speed factor to x and y values
        query_rect = pygame.Rect(
            round(base_query_rect.x * speed_factor),
            round(base_query_rect.y * speed_factor),
            base_query_rect.width,
            base_query_rect.height,
        )

        return query_rect.inflate(self.tile_size * 2, self.tile_size * 2)

    def update(self, events, dt=0):
        for layer_name, speed_factor in self.parallax_factors.items():
            # Query the quadtree for visible sprites
            visible_sprites = self.tilemap_manager.query_visible_sprites(
                layer_name, self.get_tilemap_query_rect(speed_factor)
            )
            for sprite in visible_sprites:
                self.viewport.add_sprite_to_layer(layer_name, sprite)

            # check for collision with sprites

    """ 
    was going to have tilemap report collisions
    but what happens when you have object off screen that need
    to check their collisions
    """
    #

    # def collide_hit_rect(self, one, two):
    #     return one.hit_rect.colliderect(two.rect)

    # def check_collisions(self, sprites):
    #     hits = pygame.sprite.spritecollide(
    #         self, sprites, False, self.collide_hit_rect
    #     )
    #     if hits:
    #         return True
