from lib.Container import Container
from classes.models.Walker import Walker


class WalkerContainer(Container):
    def __init__(self):
        super().__init__()
        self.boundary = None

    def set_boundary(self, boundary):
        self.boundary = boundary

    def add_walker_sprite(self, walker):
        self.add(walker)

    def get_walkers(self):
        return self.sprites()

    def notify_landed(self, player):
        for walker in self.sprites():
            walker.set_target(player)

    def notify_launched(self):
        for walker in self.sprites():
            walker.clear_target()

    def update(self):

        # Update all walkers and handle collisions
        for walker in self.sprites():
            # Check boundaries and update walker
            # if self.boundary:
            #     if (
            #         walker.rect.right >= self.boundary.rect.right
            #         and walker.velocity_x > 0
            #     ):
            #         walker.velocity_x = -walker.velocity_x  # Move left
            #     elif (
            #         walker.rect.left <= self.boundary.rect.left
            #         and walker.velocity_x < 0
            #     ):
            #         walker.velocity_x = -walker.velocity_x  # Move right

            walker.update(self.boundary)

        # Handle collisions between walkers
        # for walker in self.sprites():
        #     # Check for collisions with other walkers
        #     for other in self.sprites():
        #         if walker != other and pygame.sprite.colliderect(walker, other):
        #             walker.handle_collision(other)
