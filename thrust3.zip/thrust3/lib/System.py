import importlib
import inspect
import os

from lib.Display import Display
from lib.Controller import Controller
from lib.State_machine import StateMachine
from lib.Event_object import Event_object
from lib.Camera_manager import CameraManager
from lib.Viewport_manager import ViewportManager
from lib.Tilemap_manager import TilemapManager
from lib.Camera import Camera
from lib.Viewport import Viewport
from classes.config.Game_config import GameConfig


class System(Event_object):

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = System()
        return cls._instance

    def __init__(self):
        super().__init__()
        self.config = GameConfig()
        self.screen_width, self.screen_height = self.config.get("original_screen_size")
        self.display = Display()
        self.is_paused = False
        self.event_manager.add_listener("pause_pressed", self.on_pause_pressed)

        self.state_machine = StateMachine()
        self.camera_manager = CameraManager.get_instance()
        self.viewport_manager = ViewportManager.get_instance()

        world_width, world_height = self.setup_tilemap()

        primary_viewport = self.setup_viewports()
        primary_viewport.set_camera(
            Camera(
                self.screen_width, self.screen_height, [0, 0], world_width, world_height
            )
        )

        self.load_controllers()

    def setup_tilemap(self):
        self.tilemap_manager = TilemapManager.get_instance()
        # self.layer_names = ["foreground", "midground", "background"]
        # self.parallax_factors = {"background": 0.5, "midground": 0.75, "foreground": 1}
        self.layer_names = ["foreground", "foreground-far"]
        self.parallax_factors = {"foreground": 1, "foreground-far": 1}

        world_width, world_height = self.tilemap_manager.load_map(
            "map32x32.tmx",
            self.layer_names,
            32,
            self.parallax_factors,
        )
        return [world_width, world_height]

    def setup_viewports(self):
        self.viewport_manager = ViewportManager.get_instance()
        viewport = Viewport(
            "main_viewport", 0, 0, self.screen_width, self.screen_height
        )

        for layer_name in self.layer_names:
            if layer_name in self.parallax_factors:
                viewport.add_layer(
                    layer_name,
                    self.parallax_factors[layer_name],
                )
            else:
                print("layer name not found:", layer_name)

        # register the main viewport as the primary(True) which allows: get_primary_viewport()
        self.viewport_manager.register_viewport("main_viewport", viewport, True)
        return self.viewport_manager.get_primary_viewport()

    def on_pause_pressed(self, data):
        if self.is_paused:
            self.is_paused = False
        else:
            self.is_paused = True
        print(self.is_paused)

    def update(self, events):
        # self.collision_manger.run_autorun_groups()
        if self.state_machine.has_valid_state():
            self.state_machine.update(events)

        if self.viewport_manager.count_viewports() == 0:
            print("No viewports registered")
        else:
            main_viewport = self.viewport_manager.get_primary_viewport()
            # clear all main viewport sprites in the group, this happens as sprites are dynamically added from Tilemap
            main_viewport.clear_sprites()

            for controller_instance in self.state_machine.get_state_controllers():
                if self.get_controller(controller_instance):
                    controller = self.get_controller(controller_instance)
                    if (
                        controller.__class__.__name__ == "InputController"
                        or not self.is_paused
                    ):
                        # Call the update method if it exists on the controller
                        if hasattr(controller, "update"):
                            controller.update(events)
                        else:
                            print(f"update method not found in: {controller_instance}")

            surfaces = []

            main_viewport.update()  # eventually loop through all and update
            viewport_surface = main_viewport.render()
            surfaces.append(viewport_surface)

            self.display.update(surfaces)

    def get_controller(self, target_controller):
        _controller = next(
            (
                controller
                for controller in self.controllers
                if controller.__class__.__name__.replace("Controller", "")
                == target_controller
            ),
            None,
        )
        return _controller

    def load_controllers(self):
        # Initialise an empty list to store the imported controllers
        self.controllers = []

        # Construct the full directory path for controllers
        controllers_directory = os.path.join("classes", "controllers")

        # Loop through files in the controllers directory
        for filename in os.listdir(controllers_directory):
            # to ignore certain controllers from autoloading, underscore the first char
            if filename.endswith("_controller.py") and not filename.startswith("_"):
                # Extract the module name without the extension
                module_name = filename[:-3]
                # Construct the full module path
                module_path = f"classes.controllers.{module_name}"
                # Import the module dynamically
                module = importlib.import_module(module_path)
                # Check if the module defines a controller class and add it to the list
                for name, obj in inspect.getmembers(module):
                    if (
                        inspect.isclass(obj)
                        and issubclass(obj, Controller)
                        and obj != Controller
                    ):
                        # Create an instance of the controller
                        controller_instance = obj()
                        if not hasattr(controller_instance, "rendering_order"):
                            controller_instance.rendering_order = 0

                        self.controllers.append(controller_instance)

                self.controllers.sort(key=lambda controller: controller.rendering_order)

        for controller_instance in self.controllers:
            if hasattr(controller_instance, "game_ready") and callable(
                controller_instance.game_ready
            ):
                controller_instance.game_ready()
