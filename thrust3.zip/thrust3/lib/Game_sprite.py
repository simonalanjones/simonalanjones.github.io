import pygame
from lib.Event_object import Event_object


class GameSprite(pygame.sprite.Sprite, Event_object):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        Event_object.__init__(self)
