# from classes.states.State_game_starts import StateGameStarts
from classes.states.State_game_playing import StateGamePlaying
from classes.states.State_game_over import StateGameOver


class StateMachine:
    def __init__(self):
        self.states = {
            # "GAME_START": StateGameStarts,
            "GAME_PLAYING": StateGamePlaying,
            "GAME_OVER": StateGameOver,
        }

        self.state = None
        self.change_to("GAME_PLAYING")

    def get_state_name(self):
        return self.state.name

    def has_valid_state(self):
        return self.state

    def get_state_controllers(self):
        if self.state:
            return self.state.controllers

    def change_to(self, new_state):
        if new_state in self.states:
            self.state = self.states[new_state]()
            self.enter_state()
        else:
            print(f"Invalid state change requested: {new_state}")

    def update(self, events):
        if self.state:
            self.state.update(events)

    def enter_state(self):
        self.state.enter(self.change_to)
