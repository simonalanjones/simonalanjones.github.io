import pygame


class SpriteSheet:
    def __init__(self):
        self.sprite_sheet = pygame.image.load("graphics/lemming.png").convert_alpha()
        self.sprite_lookup = {}

    def add_sprite(self, name, x, y, width, height):
        self.sprite_lookup[name] = (x, y, width, height)

    def get_sprite(self, name):
        sprite_rect = self.sprite_lookup.get(name)
        if sprite_rect:
            x, y, width, height = sprite_rect
            sprite = pygame.Surface((width, height), pygame.SRCALPHA)
            sprite.blit(self.sprite_sheet, (0, 0), (x, y, width, height))
            return sprite
        else:
            raise ValueError(f"Sprite with name '{name}' not found in the spritesheet.")


class WalkerSpriteSheet(SpriteSheet):
    def __init__(self):
        super().__init__()

        self.add_sprite("walker_frame1", 1, 1, 16, 8)
        self.add_sprite("walker_frame2", 1, 11, 16, 8)

        self.add_sprite("walker_frame3", 19, 1, 16, 8)
        self.add_sprite("walker_frame4", 19, 11, 16, 8)
        self.add_sprite("walker_frame5", 19, 11, 16, 8)
        self.add_sprite("walker_frame6", 19, 11, 16, 8)
        self.add_sprite("walker_frame7", 19, 11, 16, 8)
        self.add_sprite("walker_frame8", 19, 11, 16, 8)
        self.add_sprite("walker_frame9", 19, 11, 16, 8)
