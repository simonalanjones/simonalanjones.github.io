<?php

include_once('server/class.php');
$redirector = new UrlRedirector();
exit;
