// on page load focus the main input field
document.getElementById("url").focus();


// handle to main submit button press
document.getElementById('submit').addEventListener('click', function() {
    getShortUrl();
});

// also check if enter key is pressed inside main input field (alternative to submit button)
document.getElementById('url').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        getShortUrl();
    }
});


// reset the page, clearing everything back to default view
const resetPage = () => {
    document.getElementById('responseContainer').innerHTML = '';
    document.getElementById("url").focus();
    document.getElementById("url").value = "";
}

// put the short URL on the clipboard,
const copyUrl = (url) => {
    const tempInput = document.createElement('input');
    tempInput.value = url;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    document.getElementById("copiedMessageContainer").className="visible";

    // display confirm message for 1.5 seconds
    setTimeout(function () {
        document.getElementById("copiedMessageContainer").className="invisible";
    }, 1500);
}

// helper functions for display elements 
const createSvgIcon = () => `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="text-sky-600 size-6 mb-2">
        <path fill-rule="evenodd" d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd" />
    </svg>`;

const createButton = (text, onClick, styles) => `
    <button onclick="${onClick}" type="button" class="${styles}">${text}</button>`;

const createTooltip = () => `
    <div id="copiedMessageContainer" class="invisible">
        <div class="font-semibold text-xs text-sky-600 uppercase tracking-wider text-center mt-2">URL copied to clipboard</div>
    </div>`;



// main function to generate the short URL
const getShortUrl = async () => {
    const urlInput = document.getElementById('url');
    const url = urlInput.value.trim();
    const requestUrl = `server/ajax.php?url=${encodeURIComponent(url)}`;

    try {
        const response = await fetch(requestUrl);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json(); // parse the JSON data

        if (data.success) {
            // Handle the successful response
            const htmlBlock = `
                <div class="mb-12 mx-14 pb-4 rounded-lg mx-auto px-6">
                    <p class="pb-1 text-xs text-center uppercase tracking-wider font-semibold text-sky-600">short url</p>
                    <div class="flex justify-center items-center">
                        ${createSvgIcon()}                                    
                    </div>
                    <p class="text-center text-slate-600 text-base display-block truncate">
                        <a class="font-mono text-slate-600 hover:text-sky-600" href='${data.url}' target='_blank'>${data.url}</a>
                    </p>
                    <div class="mx-auto w-fit mt-6">
                        ${createButton('Copy URL', `copyUrl('${data.url}')`, 'text-white bg-sky-500 focus:outline-none hover:bg-sky-600 border-sky-300 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2')}
                        ${createButton('Reset', 'resetPage()', 'text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2')}
                        ${createTooltip()}
                    </div>
                </div>
            `;

            document.getElementById('responseContainer').innerHTML = htmlBlock;

        } else {
            console.error('Error:', data.error);
        }
    } catch (error) {
        console.error('Fetch error:', error);
    }
};


