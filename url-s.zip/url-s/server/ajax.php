<?php

include_once('class.php');
$shortener = new UrlShortener();

if (isset($_GET['url'])) {

    $url = $_GET['url'];

    try {
        $short_url = $shortener->shorten($url);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }

    echo json_encode(['success' => true, 'url' => $short_url]);
} else {
    // if the url is not set, return an error message
    echo json_encode(['success' => false, 'error' => 'URL parameter is missing']);
}
