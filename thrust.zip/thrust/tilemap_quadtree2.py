import pygame
from pygame.math import Vector2
from pytmx.util_pygame import load_pygame


# Define the Camera class
class Camera:
    def __init__(self, width, height):
        self.camera = pygame.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        return entity.rect.move(-self.camera.topleft[0], -self.camera.topleft[1])

    def update(self, dx, dy):
        # Update the camera position by dx and dy
        self.camera.x += dx
        self.camera.y += dy


# Define the Rectangle class
class Rectangle:
    def __init__(self, position, scale):
        self.position = position
        self.scale = scale
        self.color = (255, 0, 0)
        self.lineThickness = 1
        self.rect = pygame.Rect(position.x, position.y, scale.x, scale.y)

    def update(self, position):
        self.rect.topleft = (position.x, position.y)

    def containsSprite(self, sprite):
        return self.rect.colliderect(sprite.rect)

    def intersects(self, _range):
        return self.rect.colliderect(_range.rect)

    def draw(self, screen, camera):
        # Only offset the rectangle drawing by the camera's top-left position
        pygame.draw.rect(
            screen,
            self.color,
            self.rect.move(-camera.camera.topleft[0], -camera.camera.topleft[1]),
            self.lineThickness,
        )


class QuadTree:
    def __init__(self, capacity, boundary):
        self.capacity = capacity
        self.boundary = boundary
        self.sprites = []

        self.northWest = None
        self.northEast = None
        self.southWest = None
        self.southEast = None

    def subdivide(self):
        parent = self.boundary
        half_scale = parent.scale / 2
        half_position = (
            parent.position + half_scale
        )  # Calculate the position of the center of the parent boundary

        # Calculate the positions of the child boundaries relative to the center of the parent boundary
        boundary_nw = Rectangle(parent.position, half_scale)
        boundary_ne = Rectangle(Vector2(half_position.x, parent.position.y), half_scale)
        boundary_sw = Rectangle(Vector2(parent.position.x, half_position.y), half_scale)
        boundary_se = Rectangle(half_position, half_scale)

        # Create child nodes with the calculated boundaries
        self.northWest = QuadTree(self.capacity, boundary_nw)
        self.northEast = QuadTree(self.capacity, boundary_ne)
        self.southWest = QuadTree(self.capacity, boundary_sw)
        self.southEast = QuadTree(self.capacity, boundary_se)

        print(
            f"Subdivided: NW {boundary_nw.rect}, NE {boundary_ne.rect}, SW {boundary_sw.rect}, SE {boundary_se.rect}"
        )

    def __subdivide(self):
        parent = self.boundary
        half_scale = parent.scale / 2

        boundary_nw = Rectangle(
            Vector2(parent.position.x, parent.position.y), half_scale
        )
        boundary_ne = Rectangle(
            Vector2(parent.position.x + half_scale.x, parent.position.y), half_scale
        )
        boundary_sw = Rectangle(
            Vector2(parent.position.x, parent.position.y + half_scale.y), half_scale
        )
        boundary_se = Rectangle(
            Vector2(parent.position.x + half_scale.x, parent.position.y + half_scale.y),
            half_scale,
        )

        self.northWest = QuadTree(self.capacity, boundary_nw)
        self.northEast = QuadTree(self.capacity, boundary_ne)
        self.southWest = QuadTree(self.capacity, boundary_sw)
        self.southEast = QuadTree(self.capacity, boundary_se)

        print(
            f"Subdivided: NW {boundary_nw.rect}, NE {boundary_ne.rect}, SW {boundary_sw.rect}, SE {boundary_se.rect}"
        )

        # Reinsert existing sprites into the new child nodes
        for sprite in self.sprites:
            inserted = (
                self.northWest.insert(sprite)
                or self.northEast.insert(sprite)
                or self.southWest.insert(sprite)
                or self.southEast.insert(sprite)
            )
            if not inserted:
                print(f"Failed to reinsert sprite at {sprite.rect.topleft}")

        self.sprites = []  # Clear sprites from parent node

    def insert(self, sprite):
        if not self.boundary.containsSprite(sprite):
            print(
                f"Sprite at {sprite.rect.topleft} does not fit in boundary {self.boundary.rect.topleft} with size {self.boundary.rect.size}"
            )
            return False

        if len(self.sprites) < self.capacity and self.northWest is None:
            self.sprites.append(sprite)
            return True
        else:
            if self.northWest is None:
                self.subdivide()

            if self.northWest.insert(sprite):
                return True
            if self.northEast.insert(sprite):
                return True
            if self.southWest.insert(sprite):
                return True
            if self.southEast.insert(sprite):
                return True

        return False

    def queryRange(self, _rectangle):
        spritesInRange = []

        if not self.boundary.intersects(_rectangle):
            return spritesInRange

        for sprite in self.sprites:
            if _rectangle.containsSprite(sprite):
                spritesInRange.append(sprite)

        if self.northWest is not None:
            spritesInRange += self.northWest.queryRange(_rectangle)
            spritesInRange += self.northEast.queryRange(_rectangle)
            spritesInRange += self.southWest.queryRange(_rectangle)
            spritesInRange += self.southEast.queryRange(_rectangle)

        return spritesInRange

    def show(self, screen, camera):
        self.boundary.draw(screen, camera)
        if self.northWest is not None:
            self.northWest.show(screen, camera)
            self.northEast.show(screen, camera)
            self.southWest.show(screen, camera)
            self.southEast.show(screen, camera)


# Define the QuadTree class
class __QuadTree:
    def __init__(self, capacity, boundary):
        self.capacity = capacity
        self.boundary = boundary
        self.sprites = []

        self.northWest = None
        self.northEast = None
        self.southWest = None
        self.southEast = None

    def subdivide(self):
        parent = self.boundary
        half_scale = parent.scale / 2

        boundary_nw = Rectangle(
            Vector2(parent.position.x, parent.position.y), half_scale
        )
        boundary_ne = Rectangle(
            Vector2(parent.position.x + half_scale.x, parent.position.y), half_scale
        )
        boundary_sw = Rectangle(
            Vector2(parent.position.x, parent.position.y + half_scale.y), half_scale
        )
        boundary_se = Rectangle(
            Vector2(parent.position.x + half_scale.x, parent.position.y + half_scale.y),
            half_scale,
        )

        self.northWest = QuadTree(self.capacity, boundary_nw)
        self.northEast = QuadTree(self.capacity, boundary_ne)
        self.southWest = QuadTree(self.capacity, boundary_sw)
        self.southEast = QuadTree(self.capacity, boundary_se)

        for sprite in self.sprites:
            self.northWest.insert(sprite)
            self.northEast.insert(sprite)
            self.southWest.insert(sprite)
            self.southEast.insert(sprite)

    def insert(self, sprite):
        if not self.boundary.containsSprite(sprite):
            print(
                f"Sprite at {sprite.rect.topleft} does not fit in boundary {self.boundary.rect.topleft} with size {self.boundary.rect.size}"
            )
            return False

        if len(self.sprites) < self.capacity and self.northWest is None:
            self.sprites.append(sprite)
            return True
        else:
            if self.northWest is None:
                self.subdivide()

            if self.northWest.insert(sprite):
                return True
            if self.northEast.insert(sprite):
                return True
            if self.southWest.insert(sprite):
                return True
            if self.southEast.insert(sprite):
                return True

        return False

    def queryRange(self, _rectangle):
        spritesInRange = []

        if not self.boundary.intersects(_rectangle):
            return spritesInRange

        for sprite in self.sprites:
            if _rectangle.containsSprite(sprite):
                spritesInRange.append(sprite)

        if self.northWest is not None:
            spritesInRange += self.northWest.queryRange(_rectangle)
            spritesInRange += self.northEast.queryRange(_rectangle)
            spritesInRange += self.southWest.queryRange(_rectangle)
            spritesInRange += self.southEast.queryRange(_rectangle)

        return spritesInRange

    def show(self, screen, camera):
        self.boundary.draw(screen, camera)
        if self.northWest is not None:
            self.northWest.show(screen, camera)
            self.northEast.show(screen, camera)
            self.southWest.show(screen, camera)
            self.southEast.show(screen, camera)


# Example Tile class
class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


# Initialize Pygame and Camera
pygame.init()
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
camera = Camera(screen_width, screen_height)
clock = pygame.time.Clock()

# Define the boundary of the entire tilemap (adjust as needed)
tilemap_width, tilemap_height = 8000, 8000  # Example dimensions
boundary = Rectangle(Vector2(0, 0), Vector2(tilemap_width, tilemap_height))
quadtree = QuadTree(100, boundary)

# Load sprites from TMX data and insert them into the quadtree
tmx_data = load_pygame("big-map.tmx")
tile_sprite_group = pygame.sprite.Group()

for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        tile = Tile(pos=pos, surf=surf, groups=tile_sprite_group)
        quadtree.insert(tile)

# Main game loop
running = True
while running:
    running = False

    offset = [0, 0]
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        offset = (0, -3)
    if keys[pygame.K_s]:
        offset = (0, 3)
    if keys[pygame.K_a]:
        offset = (-3, 0)
    if keys[pygame.K_d]:
        offset = (3, -0)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update camera position (e.g., based on player movement)
    camera.update(offset[0], offset[1])  # Example: Move right by 1 pixel each frame

    # Query the quadtree for sprites within the camera view
    camera_rect = Rectangle(
        Vector2(camera.camera.x, camera.camera.y), Vector2(screen_width, screen_height)
    )
    visible_sprites = quadtree.queryRange(camera_rect)
    print(len(visible_sprites))

    # Draw everything
    screen.fill("#71ddee")
    pygame.display.set_caption("Fps: " + str(int(clock.get_fps())))
    for sprite in visible_sprites:
        screen.blit(sprite.image, camera.apply(sprite))

    quadtree.show(screen, camera)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
