import math
import pygame
import sys
from settings import *
from pytmx.util_pygame import load_pygame


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        self.image = pygame.image.load("graphics/ship.png").convert_alpha()

        # make a copy of the image untouched for reference later in rotation
        self.base_image = self.image

        # initial x and y position
        self.x, self.y = 300, 220

        # create a vector2 for the sprite position/rect
        self.pos = pygame.Vector2(self.x, self.y)

        # create a rect based on the size of the image
        self.rect = self.image.get_rect()
        # place the rect center at the x,y position
        self.rect.center = self.pos

        # create an alternative rect which is a constant 60,60 width x height
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        # make the centre of the hit-rect based on the normal rect
        self.hit_rect.center = self.rect.center

        # starting rotation
        self.rotation = 0

        self.rotate_speed = 2  # Base rotation speed
        self.max_rotate_speed = 4  # Maximum rotation speed
        self.scaling_factor = 0.7  # Starting value for the scaling factor

        self.thrusting = False
        self.ship_mass = 0.1  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.03  # Gravity affecting the rocket
        self.thrust_power = 1  # Power of thrust

    def update(self):

        if self.thrusting:
            self.update_velocity()
        else:
            self.apply_drag()

        self.update_rotation()
        self.apply_gravity()

        # Update position based on velocity
        self.pos += pygame.Vector2(self.vx, self.vy)

        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=self.pos)
        self.hit_rect.center = self.rect.center

    def update_rotation(self):
        # Calculate velocity magnitude
        velocity_magnitude = pygame.math.Vector2(self.vx, self.vy).length()

        # Dampen rotation speed based on velocity magnitude
        if velocity_magnitude > 0:
            # Calculate a new rotation speed based on velocity magnitude
            new_rotate_speed = self.max_rotate_speed / (
                velocity_magnitude * self.scaling_factor
            )

            # Clamp the rotation speed to avoid it becoming too high
            self.rotate_speed = min(new_rotate_speed, self.max_rotate_speed)
        else:
            # Reset rotation speed when velocity magnitude is zero
            self.rotate_speed = self.max_rotate_speed

    def update_velocity(self):

        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        self.vx += thrust_force_x * self.acceleration
        self.vy += thrust_force_y * self.acceleration

        # Cap velocities
        self.vx = max(min(self.vx, 5), -5)
        self.vy = max(min(self.vy, 5), -5)

    def apply_gravity(self):
        # Apply gravity based on ship orientation
        gravity_vector = pygame.Vector2(0, self.gravity)  # .rotate(self.rotation)
        # print(gravity_vector)
        # self.vx += gravity_vector.x
        self.vy += gravity_vector.y

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    # call when space key pressed
    def start_thrusting(self):
        self.thrusting = True

    # called when space key released
    def stop_thrust(self):
        self.thrusting = False


pygame.init()
screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()

player = Player()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()
    # if keys[pygame.K_w]:
    #     player.move_up()
    # if keys[pygame.K_x]:
    #     player.move_down()
    # if keys[pygame.K_a]:
    #     player.move_left()
    # if keys[pygame.K_d]:
    #     player.move_right()

    screen.fill("#71ddee")
    player.update()

    screen.blit(player.image, player.rect)

    pygame.draw.rect(screen, (255, 255, 255), player.hit_rect, 2)

    pygame.display.update()
    clock.tick(60)
