import pygame
import sys
from Camera_group import CameraGroup

pygame.init()

ROCKET_SIZE = 20
MAX_SPEED = 3
ROTATE_SPEED = 4


WINDOW_SIZE = (600, 400)

display = pygame.Surface(
    (300, 200)
)  # used as the surface for rendering, which is scaled
screen = pygame.display.set_mode(WINDOW_SIZE, 0, 32)  # initiate the window

grass_img = pygame.image.load("graphics/grass.png")
dirt_img = pygame.image.load("graphics/dirt.png")
true_scroll = [0, 0]
clock = pygame.time.Clock()


def load_map(path):
    f = open(path + ".txt", "r")
    data = f.read()
    f.close()
    data = data.split("\n")
    game_map = []
    for row in data:
        game_map.append(list(row))
    return game_map


game_map = load_map("map")
camera_group = CameraGroup()

while True:  # game loop
    display.fill((146, 244, 255))  # clear screen by filling it with blue
    tile_rects = []
    scroll = true_scroll.copy()
    scroll[0] = int(scroll[0])
    scroll[1] = int(scroll[1])

    y = 0
    for layer in game_map:
        x = 0
        for tile in layer:
            if tile == "1":
                display.blit(dirt_img, (x * 16 - scroll[0], y * 16 - scroll[1]))
            if tile == "2":
                display.blit(grass_img, (x * 16 - scroll[0], y * 16 - scroll[1]))
            if tile != "0":
                tile_rects.append(pygame.Rect(x * 16, y * 16, 16, 16))
            x += 1
        y += 1

    for event in pygame.event.get():  # event loop
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.blit(pygame.transform.scale(display, WINDOW_SIZE), (0, 0))
    pygame.display.update()
    clock.tick(60)
