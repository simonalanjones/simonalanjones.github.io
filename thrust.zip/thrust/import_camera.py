import math
from random import randint
import pygame
import sys
from pytmx.util_pygame import load_pygame
from settings import *


class TextSprite(pygame.sprite.Sprite):
    def __init__(self, text, font, color, position):
        super().__init__()
        self.image = font.render(text, True, color)
        self.rect = self.image.get_rect(topleft=position)


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class Player(pygame.sprite.Sprite):
    def __init__(self, group):
        # this is adding this sprite to the camera group which is passed as ref
        super().__init__(group)  # camera group

        pygame.font.init()
        self.font = pygame.font.Font(None, 36)  # You can adjust the font size and style

        # Text rendering variables
        self.font = pygame.font.Font(None, 24)  # Font for rendering text
        self.text_color = (255, 255, 255)  # Text color

        self.image = pygame.image.load("graphics/ship2.png")
        self.o_size = 19, 19
        self.new_size = (
            self.o_size[0] * 3,
            self.o_size[1] * 3,
        )
        self.image = pygame.transform.scale(self.image, self.new_size)
        self.base_image = self.image

        self.x, self.y = 300, 220
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        self.rotation = 0
        self.rotate_speed = 4

        self.rocket_speed_x = 0
        self.rocket_speed_y = 0
        self.thrusting = False
        self.ship_mass = 0.1  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.04  # Gravity affecting the rocket
        self.thrust_power = 1  # Power of thrust

        self.thrust_force_x = 0
        self.thrust_force_y = 0

    def render_velocity_text(self, screen, font):
        # Create text sprites for vx, vy, rotation, thrust_force_x, and thrust_force_y
        text_vx_sprite = TextSprite(f"vx: {self.vx}", font, self.text_color, (10, 10))
        text_vy_sprite = TextSprite(f"vy: {self.vy}", font, self.text_color, (10, 30))
        text_rot_sprite = TextSprite(
            f"Rot: {self.rotation}", font, self.text_color, (10, 50)
        )
        text_tfx_sprite = TextSprite(
            f"TFX: {self.thrust_force_x}", font, self.text_color, (10, 70)
        )
        text_tfy_sprite = TextSprite(
            f"TFY: {self.thrust_force_y}", font, self.text_color, (10, 90)
        )

        # Add text sprites to a sprite group
        text_sprites = pygame.sprite.Group(
            text_vx_sprite,
            text_vy_sprite,
            text_rot_sprite,
            text_tfx_sprite,
            text_tfy_sprite,
        )

        return text_sprites

    def _render_velocity_text(self):
        # Render text for vx and vy
        text_vx = self.font.render(f"vx: {self.vx}", True, self.text_color)
        text_vy = self.font.render(f"vy: {self.vy}", True, self.text_color)
        text_rot = self.font.render(f"Rot: {self.rotation}", True, self.text_color)
        text_tfx = self.font.render(
            f"TFX: {self.thrust_force_x}", True, self.text_color
        )
        text_tfy = self.font.render(
            f"TFY: {self.thrust_force_y}", True, self.text_color
        )

        # Blit the text onto the screen
        screen.blit(text_vx, (10, 10))
        screen.blit(text_vy, (10, 40))
        screen.blit(text_rot, (10, 60))
        screen.blit(text_tfx, (10, 80))
        screen.blit(text_tfy, (10, 100))

    # called when space key pressed
    def start_thrusting(self):
        self.thrusting = True

    # called when space key released
    def stop_thrust(self):
        self.thrusting = False
        # self.acceleration = 0.1

    def rotate(self, amount):
        self.rotation += amount
        if self.rotation > 360:
            self.rotation -= 360
        elif self.rotation < 0:
            self.rotation += 360
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

        self.x += self.vx
        self.y += self.vy

    def get_hits(self, tiles):
        hits = []
        for tile in tiles:
            if self.rect.colliderect(tile):
                hits.append(tile)
        return hits

    def check_collisions_y(self, tiles):
        if self.vy != 0:
            collisions = self.get_hits(tiles)
            for tile in collisions:
                # moving down
                if self.vy > 0:
                    self.rect.bottom = tile.rect.top
                    self.vx = 0
                    self.vy = 0

                # moving up
                elif self.vy < 0:
                    self.vx = 0
                    self.vy = 0
                    self.rect.top = tile.rect.bottom

    def check_collisions_x(self, tiles):
        collisions = self.get_hits(tiles)
        for tile in collisions:
            if self.vx > 0:
                self.rect.right = tile.rect.left
                self.vx = 0

            elif self.vx < 0:
                self.vx = 0
                self.rect.left = tile.rect.right

    def update_velocity_x(self):
        self.thrust_force_x = self.thrust_power * math.cos(
            math.radians(self.rotation + 90)
        )
        self.vx += self.thrust_force_x * self.acceleration
        # cap x velocity
        if self.vx > 5:
            self.vx = 5
        if self.vx < -5:
            self.vx = -5
        # self.vx = max(min(self.vx, 5), -5)

        self.x += self.vx

    def update_velocity_y(self):
        self.thrust_force_y = -self.thrust_power * math.sin(
            math.radians(self.rotation + 90)
        )
        self.vy += self.thrust_force_y * self.acceleration
        # cap y velocity
        # self.vy = max(min(self.vy, 10), -5)
        if self.vy > 10:
            self.vy = 10
        if self.vy < -5:
            self.vy = -5

        self.y += self.vy

    def update(self, tile_sprite_group):
        # self.render_velocity_text()
        # self.tiles = tile_sprite_group
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        if self.thrusting:

            self.update_velocity_x()
            # check tile collisions in the x move function
            # self.check_collisions_x(tile_sprite_group)

            self.update_velocity_y()
            # check tile collisions in the y move function
            # self.check_collisions_y(tile_sprite_group)

        else:
            # self.check_collisions_x(tile_sprite_group)
            # self.check_collisions_y(tile_sprite_group)
            self.apply_drag()

        # self.vy += self.gravity


class CameraGroup(pygame.sprite.Group):
    def __init__(self, sprite_group):
        # sprite group is tiles

        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.sprite_group = sprite_group

        # camera offset
        self.offset = pygame.math.Vector2(400, 200)  # this is an arbitary offset
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2

        # box setup
        self.camera_borders = {"left": 300, "right": 300, "top": 200, "bottom": 200}
        l = self.camera_borders["left"]
        t = self.camera_borders["top"]
        w = self.display_surface.get_size()[0] - (
            self.camera_borders["left"] + self.camera_borders["right"]
        )

        h = self.display_surface.get_size()[1] - (
            self.camera_borders["top"] + self.camera_borders["bottom"]
        )
        self.camera_rect = pygame.Rect(l, t, w, h)

        self.bounding_rect = pygame.Rect(0, 0, 0, 0)
        for sprite in self.sprite_group:
            self.bounding_rect.union_ip(sprite.rect)

        self.ground_rect = pygame.Rect(
            0, 0, self.bounding_rect.width, self.bounding_rect.height
        )
        self.ground_rect.topleft = self.bounding_rect.topleft

    def box_target_camera(self, target):

        if target.rect.left < self.camera_rect.left:
            self.camera_rect.left = target.rect.left
        if target.rect.right > self.camera_rect.right:
            self.camera_rect.right = target.rect.right
        if target.rect.top < self.camera_rect.top:
            self.camera_rect.top = target.rect.top
        if target.rect.bottom > self.camera_rect.bottom:
            self.camera_rect.bottom = target.rect.bottom

        self.offset.x = self.camera_rect.left - self.camera_borders["left"]
        self.offset.y = self.camera_rect.top - self.camera_borders["top"]

    def custom_draw(self, player):

        self.box_target_camera(player)

        # Draw tile sprites
        for sprite in self.sprite_group:
            sprite_offset = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, sprite_offset)

        # Draw player sprite
        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)


pygame.init()

screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
pygame.display.set_caption("Camera Example")

tmx_data = load_pygame("basic.tmx")
tile_sprite_group = pygame.sprite.Group()


for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        Tile(pos=pos, surf=surf, groups=tile_sprite_group)


camera_group = CameraGroup(tile_sprite_group)
player = Player(camera_group)


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()

    screen.fill("#71ddee")

    # this is calling the update on the group which includes the player
    # as the player has been added to the camera_group
    camera_group.update(tile_sprite_group)
    camera_group.custom_draw(player)

    font = pygame.font.Font(None, 36)  # Define your font
    text_sprites = player.render_velocity_text(screen, font)  # Create text sprites

    # Draw the text sprites onto the screen
    text_sprites.draw(screen)

    pygame.display.update()
    clock.tick(60)
