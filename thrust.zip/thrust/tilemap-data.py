import pygame
import pytmx

# Initialize Pygame
pygame.init()
pygame.display.set_mode((800, 600))
# Load the TMX file
tmx_data = pytmx.load_pygame("big-map.tmx")

# Print basic map details
print(f"Map width: {tmx_data.width}")
print(f"Map height: {tmx_data.height}")
print(f"Tile width: {tmx_data.tilewidth}")
print(f"Tile height: {tmx_data.tileheight}")

# Print all layers
for layer in tmx_data.layers:
    if isinstance(layer, pytmx.TiledTileLayer):
        print(f"Layer: {layer.name}, Layer size: {layer.width}x{layer.height}")
        for x, y, gid in layer:
            tile = tmx_data.get_tile_image_by_gid(gid)
            if tile:
                print(f"Tile at ({x}, {y}) with GID: {gid}")
    elif isinstance(layer, pytmx.TiledObjectGroup):
        print(f"Object Group: {layer.name}")
        for obj in layer:
            print(f"Object: {obj.name}, Type: {obj.type}, Position: ({obj.x}, {obj.y})")
    elif isinstance(layer, pytmx.TiledImageLayer):
        print(f"Image Layer: {layer.name}, Image source: {layer.image.source}")

# Print map properties
print("Map Properties:")
for key, value in tmx_data.properties.items():
    print(f"{key}: {value}")

# Quit Pygame
pygame.quit()
