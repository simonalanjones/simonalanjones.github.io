import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# World dimensions
WORLD_WIDTH = 2000
WORLD_HEIGHT = 2000

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# Create the display surface
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Camera Movement Example")


# Define a simple sprite class
class Sprite:
    def __init__(self, x, y, width, height, color):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = color

    def draw(self, surface, offset):
        # Adjust the sprite position based on the camera offset
        adjusted_rect = self.rect.move(-offset.x, -offset.y)
        pygame.draw.rect(surface, self.color, adjusted_rect)


# Create some sprites
sprites = [
    Sprite(100, 100, 50, 50, RED),
    Sprite(400, 300, 50, 50, WHITE),
    Sprite(700, 150, 50, 50, WHITE),
    Sprite(1200, 800, 50, 50, WHITE),
    Sprite(1600, 400, 50, 50, WHITE),
]


# Define the camera class
class Camera:
    def __init__(self, width, height):
        self.rect = pygame.Rect(0, 0, width, height)

    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy

        # Keep the camera within the bounds of the world
        self.rect.x = max(0, min(self.rect.x, WORLD_WIDTH - self.rect.width))
        self.rect.y = max(0, min(self.rect.y, WORLD_HEIGHT - self.rect.height))


# Create a camera instance
camera = Camera(SCREEN_WIDTH, SCREEN_HEIGHT)

# Main loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        camera.move(-5, 0)
    if keys[pygame.K_RIGHT]:
        camera.move(5, 0)
    if keys[pygame.K_UP]:
        camera.move(0, -5)
    if keys[pygame.K_DOWN]:
        camera.move(0, 5)

    # Clear the screen
    screen.fill(BLACK)

    # Draw the sprites
    for sprite in sprites:
        sprite.draw(screen, camera.rect)

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

pygame.quit()
sys.exit()
