import pygame
import sys
from pytmx.util_pygame import load_pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Buffer size for the query range
BUFFER_SIZE = 256  # Adjust this size as needed

# Create the display surface
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Camera Movement with Quadtree")


class Player(pygame.sprite.Sprite):
    def __init__(self, pos, groups):
        super().__init__(groups)
        # Example: Load player image (adjust as per your actual player image)
        self.image = pygame.Surface((32, 32))
        self.image.fill(RED)  # Red square as placeholder
        self.rect = self.image.get_rect(topleft=pos)

    def update(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)

    def draw(self, surface, parallax_camera_rect):
        adjusted_rect = self.rect.move(-parallax_camera_rect.x, -parallax_camera_rect.y)
        surface.blit(self.image, adjusted_rect)


class Camera:
    def __init__(self, width, height):
        self.rect = pygame.Rect(0, 0, width, height)

    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy
        self.rect.x = max(0, min(self.rect.x, WORLD_WIDTH - self.rect.width))
        self.rect.y = max(0, min(self.rect.y, WORLD_HEIGHT - self.rect.height))


class Quadtree:
    def __init__(self, boundary, capacity):
        self.boundary = boundary
        self.capacity = capacity
        self.tiles = []
        self.divided = False

    def count_tiles(self):
        count = len(self.tiles)
        if self.divided:
            count += self.northeast.count_tiles()
            count += self.northwest.count_tiles()
            count += self.southeast.count_tiles()
            count += self.southwest.count_tiles()
        return count

    def subdivide(self):
        x, y, w, h = self.boundary
        half_w, half_h = w // 2, h // 2

        self.northeast = Quadtree(
            pygame.Rect(x + half_w, y, half_w, half_h), self.capacity
        )
        self.northwest = Quadtree(pygame.Rect(x, y, half_w, half_h), self.capacity)
        self.southeast = Quadtree(
            pygame.Rect(x + half_w, y + half_h, half_w, half_h), self.capacity
        )
        self.southwest = Quadtree(
            pygame.Rect(x, y + half_h, half_w, half_h), self.capacity
        )

        self.divided = True

    def insert(self, tile):
        if not self.boundary.colliderect(tile.rect):
            return False
        if len(self.tiles) < self.capacity:
            self.tiles.append(tile)
            return True
        else:
            if not self.divided:
                self.subdivide()
            if self.northeast.insert(tile):
                return True
            if self.northwest.insert(tile):
                return True
            if self.southeast.insert(tile):
                return True
            if self.southwest.insert(tile):
                return True

    def query(self, range, found=None, parallax_factor=1.0):
        if found is None:
            found = []

        # Expand the query range based on parallax factor
        expanded_range = range.inflate(
            self.boundary.width * (parallax_factor - 1),
            self.boundary.height * (parallax_factor - 1),
        )

        if not self.boundary.colliderect(expanded_range):
            return found

        for tile in self.tiles:
            if expanded_range.colliderect(tile.rect):
                found.append(tile)

        if self.divided:
            self.northeast.query(expanded_range, found, parallax_factor)
            self.northwest.query(expanded_range, found, parallax_factor)
            self.southeast.query(expanded_range, found, parallax_factor)
            self.southwest.query(expanded_range, found, parallax_factor)

        return found

    def draw(self, surface, offset):
        adjusted_boundary = self.boundary.move(-offset.x, -offset.y)
        pygame.draw.rect(surface, GREEN, adjusted_boundary, 1)
        if self.divided:
            self.northeast.draw(surface, offset)
            self.northwest.draw(surface, offset)
            self.southeast.draw(surface, offset)
            self.southwest.draw(surface, offset)


class RenderManager:
    def __init__(self, camera, buffer_size):
        self.camera = camera
        self.buffer_size = buffer_size
        self.layers = {}
        self.first_pass = True

    def add_layer(self, layer_name, quadtree, sprite_group, parallax_factor=1.0):
        self.layers[layer_name] = {
            "quadtree": quadtree,
            "sprite_group": sprite_group,
            "parallax_factor": parallax_factor,
            "prev_camera_rect": self.camera.rect.copy(),
            "prev_visible_tiles": [],
            "sprite_positions": [tile.rect.topleft for tile in sprite_group],
        }

    def update_cache(self, layer_data):
        quadtree = layer_data["quadtree"]
        sprite_group = layer_data["sprite_group"]
        parallax_factor = layer_data["parallax_factor"]

        # Calculate the parallax camera rect for this layer
        parallax_camera_rect = self.camera.rect.copy()
        parallax_camera_rect.x *= parallax_factor
        parallax_camera_rect.y *= parallax_factor

        if (
            self.first_pass
            or parallax_camera_rect != layer_data["prev_camera_rect"]
            or layer_data["sprite_positions"]
            != [tile.rect.topleft for tile in sprite_group]
        ):
            query_rect = parallax_camera_rect.inflate(
                self.buffer_size, self.buffer_size
            )
            visible_tiles = quadtree.query(query_rect, parallax_factor=parallax_factor)
            layer_data["prev_visible_tiles"] = visible_tiles
            layer_data["prev_camera_rect"] = parallax_camera_rect.copy()
            layer_data["sprite_positions"] = [
                tile.rect.topleft for tile in sprite_group
            ]
        else:
            visible_tiles = layer_data["prev_visible_tiles"]

        return visible_tiles, parallax_camera_rect

    def render(self, screen):
        screen.fill(BLACK)
        for layer_name, layer_data in sorted(
            self.layers.items(), key=lambda x: x[1]["parallax_factor"]
        ):
            visible_tiles, parallax_camera_rect = self.update_cache(layer_data)

            # print(f"layer {layer_name} has {len(visible_tiles)} tiles")
            for tile in visible_tiles:
                tile.draw(screen, parallax_camera_rect)
            # Uncomment below if you want to draw quadtree boundaries
            # layer_data["quadtree"].draw(screen, self.camera.rect)

        self.first_pass = False


player_group = pygame.sprite.Group()
player = Player((SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), player_group)


parallax_factors = {
    "background": 0.5,
    "midground": 1,
    "foreground": 1.5,
}

# Load the TMX map and create layers
tmx_data = load_pygame("big-map.tmx")

layer_names = ["background", "midground", "foreground"]
# layer_names = ["foreground"]
layers = {name: pygame.sprite.Group() for name in layer_names}

max_x = max_y = 0
for layer in tmx_data.visible_layers:
    if (
        layer.name in layer_names
    ):  # Check if the layer name is in the predefined layer names
        for x, y, surf in layer.tiles():
            pos = (x * 128, y * 128)
            layer_name = layer.name  # Use the layer name from the TMX data
            tile = Tile(pos=pos, surf=surf, groups=layers[layer_name])
            if x > max_x:
                max_x = x
            if y > max_y:
                max_y = y

WORLD_WIDTH = (max_x + 1) * 128
WORLD_HEIGHT = (max_y + 1) * 128

quadtrees = {
    name: Quadtree(pygame.Rect(0, 0, WORLD_WIDTH, WORLD_HEIGHT), 10)
    for name in layer_names
}
for layer_name, sprite_group in layers.items():
    for tile in sprite_group:
        quadtrees[layer_name].insert(tile)

camera = Camera(SCREEN_WIDTH, SCREEN_HEIGHT)
render_manager = RenderManager(camera, BUFFER_SIZE)
for layer_name in layer_names:
    render_manager.add_layer(
        layer_name,
        quadtrees[layer_name],
        layers[layer_name],
        parallax_factors[layer_name],
    )

running = True
clock = pygame.time.Clock()

# Define player bounds within the screen
PLAYER_BOUNDS = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 100, 200, 200)

while running:
    pygame.display.set_caption("Fps: " + str(int(clock.get_fps())))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    player_speed = 5

    keys = pygame.key.get_pressed()

    dx = dy = 0
    if keys[pygame.K_LEFT]:
        dx = -player_speed
    if keys[pygame.K_RIGHT]:
        dx = player_speed
    if keys[pygame.K_UP]:
        dy = -player_speed
    if keys[pygame.K_DOWN]:
        dy = player_speed

    # Update player position within bounds
    player.update(dx, dy)

    # Constrain player within PLAYER_BOUNDS
    if not PLAYER_BOUNDS.contains(player.rect):
        if player.rect.left < PLAYER_BOUNDS.left:
            player.rect.left = PLAYER_BOUNDS.left
            camera.move(dx, 0)
        if player.rect.right > PLAYER_BOUNDS.right:
            player.rect.right = PLAYER_BOUNDS.right
            camera.move(dx, 0)
        if player.rect.top < PLAYER_BOUNDS.top:
            player.rect.top = PLAYER_BOUNDS.top
            camera.move(0, dy)
        if player.rect.bottom > PLAYER_BOUNDS.bottom:
            player.rect.bottom = PLAYER_BOUNDS.bottom
            camera.move(0, dy)

    render_manager.render(screen)
    player_group.draw(screen)
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
