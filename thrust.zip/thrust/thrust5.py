import pygame
import sys
import math
from pygame.math import Vector2

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
ROCKET_SIZE = 20
THRUST_POWER = 0.2  # Adjust this value to control thrust
ROTATE_SPEED = 4

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Create the screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Thrust Game")


class Rocket(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((ROCKET_SIZE, ROCKET_SIZE), pygame.SRCALPHA)
        pygame.draw.polygon(
            self.image,
            WHITE,
            [(0, 0), (ROCKET_SIZE, ROCKET_SIZE // 2), (0, ROCKET_SIZE)],
        )
        self.original_image = self.image
        self.rect = self.image.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.position = Vector2(self.rect.center)
        self.velocity = Vector2(0, 0)
        self.acceleration = Vector2(0, 0)
        self.angle = 0
        self.thrusting = False
        self.ship_mass = 1.5
        self.gravity = Vector2(0, 0.001)
        self.max_gravity = Vector2(0, 0.01)
        self.current_time = 0

    def rotate(self, direction):
        if direction == "left":
            self.angle += ROTATE_SPEED
        elif direction == "right":
            self.angle -= ROTATE_SPEED
        self.image = pygame.transform.rotate(self.original_image, self.angle)
        self.rect = self.image.get_rect(center=self.rect.center)

    def thrust(self):
        thrust_direction = Vector2(0, -1).rotate(self.angle)
        self.acceleration = thrust_direction * (THRUST_POWER / self.ship_mass)

    def update(self):
        # Apply thrust
        if self.thrusting:
            self.thrust()

        # Apply gravity
        self.velocity += self.gravity
        self.velocity = Vector2(
            min(self.max_gravity.x, self.velocity.x),
            min(self.max_gravity.y, self.velocity.y),
        )

        # Update position and reset acceleration
        self.position += self.velocity
        self.rect.center = self.position
        self.acceleration *= 0  # Reset acceleration


# Game loop
clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()
rocket = Rocket()
all_sprites.add(rocket)
running = True

# Dictionary to keep track of keys currently being pressed
keys_pressed = {}

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Track keys being pressed
        if event.type == pygame.KEYDOWN:
            keys_pressed[event.key] = True
            if event.key == pygame.K_SPACE:
                rocket.thrusting = True
        elif event.type == pygame.KEYUP:
            keys_pressed[event.key] = False
            if event.key == pygame.K_SPACE:
                rocket.thrusting = False

    # Rotate the rocket
    if keys_pressed.get(pygame.K_LEFT):
        rocket.rotate("left")
    elif keys_pressed.get(pygame.K_RIGHT):
        rocket.rotate("right")

    # Clear the screen
    screen.fill(BLACK)

    # Update and draw the rocket
    all_sprites.update()
    all_sprites.draw(screen)

    # Update the display
    pygame.display.flip()

    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()
