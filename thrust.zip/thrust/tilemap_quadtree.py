import pygame
import sys
from pytmx.util_pygame import load_pygame
from pygame.math import Vector2


class Rectangle:
    def __init__(self, position, scale):
        self.position = position
        self.scale = scale
        self.color = (255, 255, 255)
        self.lineThickness = 1
        self.rect = pygame.Rect(position.x, position.y, scale.x, scale.y)

    def update(self, position):
        self.rect.topleft = (position.x, position.y)

    def containsSprite(self, sprite):
        return self.rect.colliderect(sprite.rect)

    def intersects(self, _range):
        return self.rect.colliderect(_range.rect)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect, self.lineThickness)


class QuadTree:
    def __init__(self, capacity, boundary):
        self.capacity = capacity
        self.boundary = boundary
        self.sprites = []

        self.northWest = None
        self.northEast = None
        self.southWest = None
        self.southEast = None

    def subdivide(self):
        parent = self.boundary
        half_scale = parent.scale / 2

        boundary_nw = Rectangle(
            Vector2(parent.position.x, parent.position.y), half_scale
        )
        boundary_ne = Rectangle(
            Vector2(parent.position.x + half_scale.x, parent.position.y), half_scale
        )
        boundary_sw = Rectangle(
            Vector2(parent.position.x, parent.position.y + half_scale.y), half_scale
        )
        boundary_se = Rectangle(
            Vector2(parent.position.x + half_scale.x, parent.position.y + half_scale.y),
            half_scale,
        )

        self.northWest = QuadTree(self.capacity, boundary_nw)
        self.northEast = QuadTree(self.capacity, boundary_ne)
        self.southWest = QuadTree(self.capacity, boundary_sw)
        self.southEast = QuadTree(self.capacity, boundary_se)

        for sprite in self.sprites:
            self.northWest.insert(sprite)
            self.northEast.insert(sprite)
            self.southWest.insert(sprite)
            self.southEast.insert(sprite)

    def insert(self, sprite):
        if not self.boundary.containsSprite(sprite):
            return False

        if len(self.sprites) < self.capacity and self.northWest is None:
            self.sprites.append(sprite)
            return True
        else:
            if self.northWest is None:
                self.subdivide()

            if self.northWest.insert(sprite):
                return True
            if self.northEast.insert(sprite):
                return True
            if self.southWest.insert(sprite):
                return True
            if self.southEast.insert(sprite):
                return True

        return False

    def queryRange(self, _rectangle):
        # print(_rectangle)
        spritesInRange = []

        if not self.boundary.intersects(_rectangle):

            return spritesInRange

        for sprite in self.sprites:
            if _rectangle.containsSprite(sprite):
                spritesInRange.append(sprite)

        if self.northWest is not None:
            spritesInRange += self.northWest.queryRange(_rectangle)
            spritesInRange += self.northEast.queryRange(_rectangle)
            spritesInRange += self.southWest.queryRange(_rectangle)
            spritesInRange += self.southEast.queryRange(_rectangle)

        # print(len(spritesInRange))
        return spritesInRange

    def show(self, screen):
        self.boundary.draw(screen)
        if self.northWest is not None:
            self.northWest.show(screen)
            self.northEast.show(screen)
            self.southWest.show(screen)
            self.southEast.show(screen)


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("graphics/ship.png").convert_alpha()
        self.base_image = self.image
        self.pos = pygame.Vector2(300, 1220)
        self.rect = self.image.get_rect(center=self.pos)
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        self.hit_rect.center = self.rect.center

    def move_right(self):
        self.pos += pygame.Vector2(1, 0)
        self.rect.center = self.pos


class CameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.offset = pygame.math.Vector2(0, 0)
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2
        self.camera_borders = {"left": 200, "right": 200, "top": 200, "bottom": 200}
        l = self.camera_borders["left"]
        t = self.camera_borders["top"]
        w = self.display_surface.get_size()[0] - (
            self.camera_borders["left"] + self.camera_borders["right"]
        )
        h = self.display_surface.get_size()[1] - (
            self.camera_borders["top"] + self.camera_borders["bottom"]
        )
        self.camera_rect = pygame.Rect(l, t, w, h)

    def center_target_camera(self, target):

        self.offset.x = target.rect.centerx - self.half_w
        self.offset.y = target.rect.centery - self.half_h

    def custom_draw(self, player, quadtree):
        self.center_target_camera(player)

        # Update range rectangle based on camera offset
        range_rect = Rectangle(self.offset, Vector2(1280, 720))
        sprites_in_range = quadtree.queryRange(range_rect)

        for sprite in sprites_in_range:
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)

        # Draw quadtree for debugging
        quadtree.show(self.display_surface)


pygame.init()
screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()

player = Player()
camera_group = CameraGroup()
tmx_data = load_pygame("big-map.tmx")
tile_sprite_group = pygame.sprite.Group()

for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        Tile(pos=pos, surf=surf, groups=tile_sprite_group)

camera_group.add(player)

NODE_CAPACITY = 50
MAP_WIDTH, MAP_HEIGHT = 5000, 5000  # Adjust based on your map size

quadtree_boundary = Rectangle(Vector2(0, 0), Vector2(MAP_WIDTH, MAP_HEIGHT))
quadtree_boundary.color = (190, 210, 55)
quadtree_boundary.lineThickness = 3
quadtree = QuadTree(NODE_CAPACITY, quadtree_boundary)

# Insert tiles into the quadtree
for sprite in tile_sprite_group:
    quadtree.insert(sprite)


camera_offset = Vector2(0, 0)
camera_speed = 5

while True:

    BLACK = (0, 0, 0)
    screen.fill(BLACK)
    pygame.display.set_caption("Fps: " + str(int(clock.get_fps())))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # keys = pygame.key.get_pressed()
    # if keys[pygame.K_w]:
    #     camera_offset.y -= camera_speed
    # if keys[pygame.K_s]:
    #     camera_offset.y += camera_speed
    # if keys[pygame.K_a]:
    #     camera_offset.x -= camera_speed
    # if keys[pygame.K_d]:
    #     camera_offset.x += camera_speed

    # =========================
    # player.move_right()
    # player.rect.topleft = player.pos - camera_offset

    camera_group.update()
    camera_group.custom_draw(player, quadtree)

    pygame.display.update()
    clock.tick(60)
