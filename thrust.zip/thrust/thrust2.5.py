import pygame
import sys
import math
import time  # Import the time module

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
ROCKET_SIZE = 20
MAX_SPEED = 2
ROTATE_SPEED = 4

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Create the screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Thrust Game")

# Rocket properties
rocket_x = WIDTH // 2
rocket_y = HEIGHT // 2
rocket_angle = 0
rocket_speed_x = 0
rocket_speed_y = 0

# Ship mass (heavier ships require more thrust)
ship_mass = 1.5  # Adjust this value to control the ship's mass

# Initial gravitational force and time
gravity = 0.001  # Smaller starting gravity
max_gravity = 0.01  # Maximum gravity
current_time = 0

# Define thrust variables
thrusting = False
thrust_start_time = 0
thrust_delay = 1.0  # Adjust this value to control thrust delay in seconds

# Game loop
clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                # Check if thrusting is allowed
                if not thrusting and current_time - thrust_start_time >= thrust_delay:
                    thrust_start_time = current_time  # Set the start time of the thrust
                    thrusting = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                thrusting = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        rocket_angle += ROTATE_SPEED
    if keys[pygame.K_RIGHT]:
        rocket_angle -= ROTATE_SPEED

    thrust_power = (
        0.2 / ship_mass
    )  # Adjust this value to control thrust for different ship masses

    if thrusting:
        rocket_speed_x += thrust_power * math.cos(math.radians(rocket_angle))
        rocket_speed_y -= thrust_power * math.sin(math.radians(rocket_angle))

    # Increase gravity over time
    current_time += 1
    gravity = min(
        max_gravity, gravity + 0.001
    )  # Increase gravity over time (capped at max_gravity)

    # Apply gravitational force
    # rocket_speed_y += gravity

    rocket_x += rocket_speed_x
    rocket_y += rocket_speed_y

    # Apply drag to slow down the rocket gradually
    rocket_speed_x *= 0.99
    rocket_speed_y *= 0.99

    # Wrap the rocket around the screen
    rocket_x = rocket_x % WIDTH
    rocket_y = rocket_y % HEIGHT

    # Clear the screen
    screen.fill(BLACK)

    # Draw the rocket
    rocket_image = pygame.Surface((ROCKET_SIZE, ROCKET_SIZE))
    pygame.draw.polygon(
        rocket_image, WHITE, [(0, 0), (ROCKET_SIZE, ROCKET_SIZE // 2), (0, ROCKET_SIZE)]
    )
    rocket_image.set_colorkey(BLACK)
    rotated_rocket = pygame.transform.rotate(rocket_image, rocket_angle)
    rocket_rect = rotated_rocket.get_rect(center=(rocket_x, rocket_y))
    screen.blit(rotated_rocket, rocket_rect)

    # Update the display
    pygame.display.flip()

    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()
