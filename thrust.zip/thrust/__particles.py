#!/usr/bin/python3.4
# Setup Python ----------------------------------------------- #
import pygame
import sys
import random

# Setup pygame/window ---------------------------------------- #
mainClock = pygame.time.Clock()
from pygame.locals import *

pygame.init()
pygame.display.set_caption("game base")
screen = pygame.display.set_mode((500, 500), 0, 32)

# Load sprite image
sprite_image = pygame.image.load("graphics/circle.png")

particles = []


# Particle class definition
class Particle:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.timer = random.randint(4, 6)
        self.vx = random.randint(0, 20) / 10 - 1
        self.vy = -2

        # Scale sprite based on timer (radius of circle)
        self.sprite = pygame.transform.scale(
            sprite_image, (int(self.timer * 0.9), int(self.timer * 0.9))
        )
        # print((int(self.timer * 1), int(self.timer * 1)))
        self.rect = self.sprite.get_rect(center=(self.x, self.y))

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.timer -= 0.1
        self.vy += 0.1

        # Update sprite position
        self.rect.center = (self.x, self.y)

    def draw(self, surface):
        surface.blit(self.sprite, self.rect)


# Loop ------------------------------------------------------- #
while True:

    # Background --------------------------------------------- #
    screen.fill((0, 0, 0))
    mx, my = pygame.mouse.get_pos()

    particles.append(Particle(mx, my))

    for particle in particles[:]:  # Using [:] to create a copy for iteration
        particle.update()
        particle.draw(screen)
        if particle.timer <= 0:
            particles.remove(particle)

    # Buttons ------------------------------------------------ #
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                pygame.quit()
                sys.exit()

    # Update ------------------------------------------------- #
    pygame.display.update()
    mainClock.tick(60)
