# cache when no change to camera rect
# buffer used to prevent premature culling of child nodes
# increase 16x16 tiles to 64x64

import pygame
import sys
from pytmx.util_pygame import load_pygame

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Buffer size for the query range
BUFFER_SIZE = 256  # Adjust this size as needed

# Create the display surface
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Camera Movement with Quadtree")


# class Tile(pygame.sprite.Sprite):
#     def __init__(self, pos, surf, groups):
#         super().__init__(groups)
#         self.image = surf
#         self.rect = self.image.get_rect(topleft=pos)

#     def draw(self, surface, offset):
#         # Adjust the sprite position based on the camera offset
#         adjusted_rect = self.rect.move(-offset.x, -offset.y)
#         surface.blit(self.image, adjusted_rect)


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)
        self.scaled_image = pygame.transform.scale(self.image, (64, 64))
        self.scaled_rect = self.scaled_image.get_rect(topleft=pos)

    def draw(self, surface, offset):
        # Adjust the sprite position based on the camera offset
        adjusted_rect = self.scaled_rect.move(-offset.x, -offset.y)
        surface.blit(self.scaled_image, adjusted_rect)


# Define the camera class
class Camera:
    def __init__(self, width, height):
        self.rect = pygame.Rect(0, 0, width, height)

    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy

        # Keep the camera within the bounds of the world
        self.rect.x = max(0, min(self.rect.x, WORLD_WIDTH - self.rect.width))
        self.rect.y = max(0, min(self.rect.y, WORLD_HEIGHT - self.rect.height))


# Define the Quadtree class
class Quadtree:
    def __init__(self, boundary, capacity):
        self.boundary = boundary
        self.capacity = capacity
        self.tiles = []
        self.divided = False

    def count_tiles(self):
        count = len(self.tiles)
        if self.divided:
            count += self.northeast.count_tiles()
            count += self.northwest.count_tiles()
            count += self.southeast.count_tiles()
            count += self.southwest.count_tiles()
        return count

    def subdivide(self):
        x, y, w, h = self.boundary
        half_w, half_h = w // 2, h // 2

        self.northeast = Quadtree(
            pygame.Rect(x + half_w, y, half_w, half_h), self.capacity
        )
        self.northwest = Quadtree(pygame.Rect(x, y, half_w, half_h), self.capacity)
        self.southeast = Quadtree(
            pygame.Rect(x + half_w, y + half_h, half_w, half_h), self.capacity
        )
        self.southwest = Quadtree(
            pygame.Rect(x, y + half_h, half_w, half_h), self.capacity
        )

        self.divided = True

    def insert(self, tile):
        if not self.boundary.colliderect(tile.rect):
            return False

        if len(self.tiles) < self.capacity:
            self.tiles.append(tile)
            return True
        else:
            if not self.divided:
                self.subdivide()

            if self.northeast.insert(tile):
                return True
            if self.northwest.insert(tile):
                return True
            if self.southeast.insert(tile):
                return True
            if self.southwest.insert(tile):
                return True

    def query(self, range, found=None):
        if found is None:
            found = []

        if not self.boundary.colliderect(range):
            return found

        for tile in self.tiles:
            if range.colliderect(tile.rect):
                found.append(tile)

        if self.divided:
            self.northeast.query(range, found)
            self.northwest.query(range, found)
            self.southeast.query(range, found)
            self.southwest.query(range, found)

        return found

    def draw(self, surface, offset):
        # Adjust the boundary position based on the camera offset
        adjusted_boundary = self.boundary.move(-offset.x, -offset.y)
        pygame.draw.rect(surface, GREEN, adjusted_boundary, 1)

        if self.divided:
            self.northeast.draw(surface, offset)
            self.northwest.draw(surface, offset)
            self.southeast.draw(surface, offset)
            self.southwest.draw(surface, offset)


# Load the TMX map
tmx_data = load_pygame("test16.tmx")
tile_sprite_group = pygame.sprite.Group()

# Calculate the world dimensions based on the tile positions
max_x = max_y = 0
for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 64, y * 64)
        tile = Tile(pos=pos, surf=surf, groups=tile_sprite_group)
        if x > max_x:
            max_x = x
        if y > max_y:
            max_y = y

WORLD_WIDTH = (max_x + 1) * 128
WORLD_HEIGHT = (max_y + 1) * 128

# Create a quadtree instance
boundary = pygame.Rect(0, 0, WORLD_WIDTH, WORLD_HEIGHT)
quadtree = Quadtree(boundary, 10)

# Insert tiles into the quadtree
for tile in tile_sprite_group:
    quadtree.insert(tile)

# Create a camera instance
camera = Camera(SCREEN_WIDTH, SCREEN_HEIGHT)

# Cache variables
prev_camera_rect = camera.rect.copy()
prev_visible_tiles = []
sprite_positions = [tile.rect.topleft for tile in tile_sprite_group]

# Main loop
running = True
clock = pygame.time.Clock()

# Invalidate the cache for the first pass
first_pass = True

while running:
    pygame.display.set_caption("Fps: " + str(int(clock.get_fps())))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        camera.move(-5, 0)  # Increase speed for easier testing
    if keys[pygame.K_RIGHT]:
        camera.move(5, 0)
    if keys[pygame.K_UP]:
        camera.move(0, -5)
    if keys[pygame.K_DOWN]:
        camera.move(0, 5)

    # Check if the camera has moved or sprites have changed, or if it's the first pass
    if (
        first_pass
        or camera.rect != prev_camera_rect
        or sprite_positions != [tile.rect.topleft for tile in tile_sprite_group]
    ):
        # Add buffer to the query range
        query_rect = camera.rect.inflate(BUFFER_SIZE, BUFFER_SIZE)
        # Query the quadtree for tiles in the current camera view
        visible_tiles = quadtree.query(query_rect)
        prev_visible_tiles = visible_tiles
        prev_camera_rect = camera.rect.copy()
        sprite_positions = [tile.rect.topleft for tile in tile_sprite_group]
        first_pass = False
    else:
        visible_tiles = prev_visible_tiles

    # Clear the screen
    screen.fill(BLACK)

    # Draw the visible tiles
    for tile in visible_tiles:
        tile.draw(screen, camera.rect)

    # Draw the quadtree boundaries
    quadtree.draw(screen, camera.rect)

    # Update the display
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
