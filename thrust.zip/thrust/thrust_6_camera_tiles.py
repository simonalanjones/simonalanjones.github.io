import math
import pygame
import sys
from settings import *
from pytmx.util_pygame import load_pygame


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class Player(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)

        self.image = pygame.image.load("graphics/ship.png").convert_alpha()

        # make a copy of the image untouched for reference later in rotation
        self.base_image = self.image

        # initial x and y position
        self.x, self.y = 300, 220

        # create a vector2 for the sprite position/rect
        self.pos = pygame.Vector2(self.x, self.y)

        # create a rect based on the size of the image
        self.rect = self.image.get_rect()
        # place the rect center at the x,y position
        self.rect.center = self.pos

        # create an alternative rect which is a constant 60,60 width x height
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        # make the centre of the hit-rect based on the normal rect
        self.hit_rect.center = self.rect.center

        # starting rotation
        self.rotation = 0

        self.rotate_speed = 2  # Base rotation speed
        self.max_rotate_speed = 4  # Maximum rotation speed
        self.scaling_factor = 0.7  # Starting value for the scaling factor

        self.thrusting = False
        self.ship_mass = 0.1  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.03  # Gravity affecting the rocket
        self.thrust_power = 1  # Power of thrust

    def update(self, tile_sprite_group):
        if self.thrusting:
            self.update_velocity()
        else:
            self.apply_drag()

        self.update_rotation()

        # Update position based on velocity
        self.pos += pygame.Vector2(self.vx, self.vy)

        # Rotate the image and update the rect's position
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=self.pos)

        # Update the hit_rect's position
        self.hit_rect.center = self.rect.center

        # Ensure the rect's position is updated properly after rotation
        self.rect.topleft = self.pos - pygame.Vector2(
            self.rect.width / 2, self.rect.height / 2
        )

    def __update(self, tile_sprite_group):

        if self.thrusting:
            self.update_velocity()
        else:
            self.apply_drag()

        self.update_rotation()
        # self.apply_gravity()

        # Update position based on velocity
        self.pos += pygame.Vector2(self.vx, self.vy)

        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=self.pos)
        self.hit_rect.center = self.rect.center

    def update_rotation(self):
        # Calculate velocity magnitude
        velocity_magnitude = pygame.math.Vector2(self.vx, self.vy).length()

        # Dampen rotation speed based on velocity magnitude
        if velocity_magnitude > 0:
            # Calculate a new rotation speed based on velocity magnitude
            new_rotate_speed = self.max_rotate_speed / (
                velocity_magnitude * self.scaling_factor
            )

            # Clamp the rotation speed to avoid it becoming too high
            self.rotate_speed = min(new_rotate_speed, self.max_rotate_speed)
        else:
            # Reset rotation speed when velocity magnitude is zero
            self.rotate_speed = self.max_rotate_speed

    def update_velocity(self):

        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        self.vx += thrust_force_x * self.acceleration
        self.vy += thrust_force_y * self.acceleration

        # Cap velocities
        self.vx = max(min(self.vx, 5), -5)
        self.vy = max(min(self.vy, 5), -5)

    def apply_gravity(self):
        # Apply gravity based on ship orientation
        gravity_vector = pygame.Vector2(0, self.gravity)  # .rotate(self.rotation)
        # print(gravity_vector)
        # self.vx += gravity_vector.x
        self.vy += gravity_vector.y

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    # call when space key pressed
    def start_thrusting(self):
        self.thrusting = True

    # called when space key released
    def stop_thrust(self):
        self.thrusting = False


class CameraGroup(pygame.sprite.Group):
    def __init__(self, sprite_group):
        # sprite group is tiles

        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.sprite_group = sprite_group

        # camera offset
        self.offset = pygame.math.Vector2(400, 200)  # this is an arbitary offset
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2

        # box setup
        self.camera_borders = {"left": 300, "right": 300, "top": 200, "bottom": 200}
        l = self.camera_borders["left"]
        t = self.camera_borders["top"]
        w = self.display_surface.get_size()[0] - (
            self.camera_borders["left"] + self.camera_borders["right"]
        )

        h = self.display_surface.get_size()[1] - (
            self.camera_borders["top"] + self.camera_borders["bottom"]
        )
        self.camera_rect = pygame.Rect(l, t, w, h)

        self.bounding_rect = pygame.Rect(0, 0, 0, 0)
        for sprite in self.sprite_group:
            self.bounding_rect.union_ip(sprite.rect)

        self.ground_rect = pygame.Rect(
            0, 0, self.bounding_rect.width, self.bounding_rect.height
        )
        self.ground_rect.topleft = self.bounding_rect.topleft

    def box_target_camera(self, target):

        if target.rect.left < self.camera_rect.left:
            self.camera_rect.left = target.rect.left
        if target.rect.right > self.camera_rect.right:
            self.camera_rect.right = target.rect.right
        if target.rect.top < self.camera_rect.top:
            self.camera_rect.top = target.rect.top
        if target.rect.bottom > self.camera_rect.bottom:
            self.camera_rect.bottom = target.rect.bottom

        self.offset.x = self.camera_rect.left - self.camera_borders["left"]
        self.offset.y = self.camera_rect.top - self.camera_borders["top"]

    def custom_draw(self, player):

        self.box_target_camera(player)

        # Draw tile sprites
        for sprite in self.sprite_group:
            sprite_offset = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, sprite_offset)

        # Draw player sprite
        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)

    def custom_draw(self, player):

        self.box_target_camera(player)

        # Draw tile sprites
        for sprite in self.sprite_group:
            sprite_offset = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, sprite_offset)

        # Draw player sprite
        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)


pygame.init()

screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
pygame.display.set_caption("Camera Example")

tmx_data = load_pygame("basic.tmx")
tile_sprite_group = pygame.sprite.Group()


for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        Tile(pos=pos, surf=surf, groups=tile_sprite_group)


camera_group = CameraGroup(tile_sprite_group)
player = Player(camera_group)


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()

    screen.fill("#71ddee")

    # this is calling the update on the group which includes the player
    # as the player has been added to the camera_group
    camera_group.update(tile_sprite_group)
    camera_group.custom_draw(player)

    pygame.display.update()
    clock.tick(60)
