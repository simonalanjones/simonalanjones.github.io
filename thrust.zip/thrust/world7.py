# cache when no change to camera rect
# buffer used to prevent premature culling of child nodes

import pygame
import sys
from pytmx.util_pygame import load_pygame

from classes.particle import Particle
from classes.particle import Particle_container
from classes.particle import Particle_emitter

from classes.Tile import Tile
from classes.Quadtree import Quadtree

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Buffer size for the query range
BUFFER_SIZE = 256  # Adjust this size as needed

# Create the display surface
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Camera Movement with Quadtree")


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        self.image = pygame.image.load("graphics/ship.png").convert_alpha()

        # make a copy of the image untouched for reference later in rotation
        self.base_image = self.image

        # initial x and y position
        self.x, self.y = 300, 220

        # create a vector2 for the sprite position/rect
        self.pos = pygame.Vector2(self.x, self.y)

        # create a rect based on the size of the image
        self.rect = self.image.get_rect()
        # place the rect center at the x,y position
        self.rect.center = self.pos


class CameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()

        # camera offset
        self.offset = pygame.math.Vector2(0, 0)
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2

        # box setup
        self.camera_borders = {"left": 200, "right": 200, "top": 200, "bottom": 200}
        l = self.camera_borders["left"]
        t = self.camera_borders["top"]
        w = self.display_surface.get_size()[0] - (
            self.camera_borders["left"] + self.camera_borders["right"]
        )

        h = self.display_surface.get_size()[1] - (
            self.camera_borders["top"] + self.camera_borders["bottom"]
        )
        self.camera_rect = pygame.Rect(l, t, w, h)

        # ground
        self.ground_surf = pygame.image.load("graphics/ground.png").convert_alpha()
        self.ground_rect = self.ground_surf.get_rect(topleft=(0, 0))

    # ============================
    # use the player centre point?
    def center_target_camera(self, target):
        self.offset.x = target.rect.centerx - self.half_w
        self.offset.y = target.rect.centery - self.half_h
        # print(self.offset)

    def _box_target_camera(self, target):
        player_center_x = target.rect.centerx
        player_center_y = target.rect.centery

        # Calculate the new camera position based on the player's center
        new_camera_left = player_center_x - self.half_w
        new_camera_top = player_center_y - self.half_h

        # Update the camera rectangle
        self.camera_rect.topleft = (new_camera_left, new_camera_top)

        # Clamp the camera within the level boundaries
        self.camera_rect.clamp_ip(self.ground_rect)

        # Update the camera offset based on the camera rectangle
        self.offset = self.camera_rect.topleft - pygame.math.Vector2(
            self.camera_borders["left"], self.camera_borders["top"]
        )

    def custom_draw(self, player):

        self.center_target_camera(player)
        # self.box_target_camera(player)
        ground_offset = self.ground_rect.topleft - self.offset
        # self.display_surface.blit(self.ground_surf, ground_offset)

        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)


# Define the camera class
class Camera:
    def __init__(self, width, height):
        self.rect = pygame.Rect(0, 0, width, height)

    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy

        # Keep the camera within the bounds of the world
        self.rect.x = max(0, min(self.rect.x, WORLD_WIDTH - self.rect.width))
        self.rect.y = max(0, min(self.rect.y, WORLD_HEIGHT - self.rect.height))


# Load the TMX map
tmx_data = load_pygame("big-map.tmx")
tile_sprite_group = pygame.sprite.Group()

# Calculate the world dimensions based on the tile positions
max_x = max_y = 0
for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        tile = Tile(pos=pos, surf=surf, groups=tile_sprite_group)
        if x > max_x:
            max_x = x
        if y > max_y:
            max_y = y

WORLD_WIDTH = (max_x + 1) * 128
WORLD_HEIGHT = (max_y + 1) * 128

# Create a quadtree instance
boundary = pygame.Rect(0, 0, WORLD_WIDTH, WORLD_HEIGHT)
quadtree = Quadtree(boundary, 10)

# Insert tiles into the quadtree
for tile in tile_sprite_group:
    quadtree.insert(tile)

# Create a camera instance
camera = Camera(SCREEN_WIDTH, SCREEN_HEIGHT)

# Cache variables
prev_camera_rect = camera.rect.copy()
prev_visible_tiles = []
sprite_positions = [tile.rect.topleft for tile in tile_sprite_group]

# Main loop
running = True
clock = pygame.time.Clock()

# Invalidate the cache for the first pass
first_pass = True

while running:
    pygame.display.set_caption("Fps: " + str(int(clock.get_fps())))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        camera.move(-5, 0)  # Increase speed for easier testing
    if keys[pygame.K_RIGHT]:
        camera.move(5, 0)
    if keys[pygame.K_UP]:
        camera.move(0, -5)
    if keys[pygame.K_DOWN]:
        camera.move(0, 5)

    # Check if the camera has moved or sprites have changed, or if it's the first pass
    if (
        first_pass
        or camera.rect != prev_camera_rect
        or sprite_positions != [tile.rect.topleft for tile in tile_sprite_group]
    ):
        # Add buffer to the query range
        query_rect = camera.rect.inflate(BUFFER_SIZE, BUFFER_SIZE)
        # Query the quadtree for tiles in the current camera view
        visible_tiles = quadtree.query(query_rect)
        prev_visible_tiles = visible_tiles
        prev_camera_rect = camera.rect.copy()
        sprite_positions = [tile.rect.topleft for tile in tile_sprite_group]
        first_pass = False
    else:
        visible_tiles = prev_visible_tiles

    # Clear the screen
    screen.fill(BLACK)

    # Draw the visible tiles
    for tile in visible_tiles:
        tile.draw(screen, camera.rect)

    # Draw the quadtree boundaries
    quadtree.draw(screen, camera.rect)

    # Update the display
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
