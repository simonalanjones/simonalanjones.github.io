import pygame


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)

    def draw(self, surface, offset):
        # Adjust the sprite position based on the camera offset
        adjusted_rect = self.rect.move(-offset.x, -offset.y)
        surface.blit(self.image, adjusted_rect)
