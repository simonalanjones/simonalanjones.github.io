import random
import pygame
from classes.particle import Particle


class ParticleContainer(pygame.sprite.Group):

    def __init__(self):
        pygame.sprite.Group.__init__(self)
        # self.sprite_group = sprite_group

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def check_collisions(self, sprite_group):
        # only check collisions if container has particle sprites
        if len(self) > 0:
            collisions = pygame.sprite.groupcollide(
                self, sprite_group, False, False, collided=None
            )

            if collisions:
                for particle, tile in collisions.items():
                    particle.vy = -particle.vy
                    random_number = random.uniform(-5, 5)
                    particle.vx = random_number

    def spawn_particle(self, get_ship):
        # print("current ship thrust", ship.current_thrust_power)
        particle = Particle(get_ship)
        self.add(particle)

    def update(self):
        for particle in self.sprites():
            particle.update()
            if particle.timer <= 0:
                particle.kill()
