from classes.particle import Particle


class ParticleEmitter:

    def __init__(self, particle_container, get_ship):
        self.particle_container = particle_container
        self.get_ship = get_ship

    def update(self):
        self.particle_container.update()

    def emit(self, position, rotation):
        particle = Particle(position, rotation)
        self.particle_container.add(particle)

    def emit_from_ship_rear(self):
        ship = self.get_ship()

        position = ship.get_rear_exhaust_position()
        rotation = ship.rotation

        thrust = ship.current_thrust_power
        if thrust > 0.9:
            self.emit(position, rotation)
            self.emit(position, rotation)
            self.emit(position, rotation)
        elif thrust > 0.5:
            self.emit(position, rotation)
            self.emit(position, rotation)
        elif thrust > 0.2 or ship.current_thrust_power > 0:
            self.emit(position, rotation)

    def emit_from_ship_front(self, ship):
        pass

    def get_surface(self):
        return self.particle_container
