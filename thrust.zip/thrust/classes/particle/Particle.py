import math
import random
import pygame


class Particle(pygame.sprite.Sprite):

    def __init__(self, position, rotation):

        super().__init__()

        self.sprite_image = pygame.image.load("graphics/circle.png")
        self.vx = 0
        self.vy = 0

        self.acceleration = 0.7  # Acceleration due to thrust
        self.gravity = 0.7  # Gravity affecting the rocket
        self.thrust_power = 0.6  # Power of thrust
        self.mass = 0.4

        self.timer = random.randint(1, 4)

        offset_x = random.randint(-10, 10)
        offset_y = random.randint(-10, 10)

        self.x = position.x
        self.y = position.y
        self.rotation = rotation

        # Rotate offset based on ship's rotation
        offset_x_rotated = offset_x * math.cos(
            math.radians(rotation)
        ) - offset_y * math.sin(math.radians(rotation))

        offset_y_rotated = offset_x * math.sin(
            math.radians(rotation)
        ) + offset_y * math.cos(math.radians(rotation))

        # Apply offset to particle's position
        self.x += offset_x_rotated
        self.y += offset_y_rotated

        # Scale sprite based on timer (radius of circle)
        self.sprite = pygame.transform.scale(
            self.sprite_image, (int(self.timer / 0.7), int(self.timer / 0.7))
        )
        self.sprite = self.sprite_image
        self.rect = self.sprite.get_rect(center=(self.x, self.y))

    def update(self):
        self.timer -= 0.5

        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        # Calculate acceleration using Newton's second law: F = ma
        acceleration_x = thrust_force_x / self.mass
        acceleration_y = thrust_force_y / self.mass

        # Update velocity based on acceleration
        self.vx += acceleration_x
        self.vy += acceleration_y

        self.x -= self.vx
        self.y -= self.vy

        # Update sprite position
        self.rect.center = (self.x, self.y)

    def __update(self):
        self.timer -= 0.5
        ship_rotation = self.ship_rotation

        thrust_force_x = self.thrust_power * math.cos(math.radians(ship_rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(ship_rotation + 90))

        # Calculate acceleration using Newton's second law: F = ma
        acceleration_x = thrust_force_x / self.mass
        acceleration_y = thrust_force_y / self.mass

        # Update velocity based on acceleration
        self.vx += acceleration_x
        self.vy += acceleration_y

        self.x -= self.vx
        self.y -= self.vy

        # Update sprite position
        self.rect.center = (self.x, self.y)

    def draw(self, surface):
        surface.blit(self.sprite, self.rect)
