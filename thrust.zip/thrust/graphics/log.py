import matplotlib.pyplot as plt
import numpy as np

# Define a range of current thrust power values between 0 and 1
current_thrust_power_values = np.linspace(0, 1, 100)

# Define different values for the thrust_increment_factor
thrust_increment_factors = [0.1, 0.5, 1, 2]

# Plot the effect of the logarithmic function for each thrust_increment_factor
for factor in thrust_increment_factors:
    # Calculate the resulting values after applying the logarithmic function
    result_values = np.log(current_thrust_power_values + 1) * factor
    plt.plot(current_thrust_power_values, result_values, label=f"Factor={factor}")

# Add labels and legend
plt.xlabel("Current Thrust Power")
plt.ylabel("Resulting Value")
plt.title("Effect of Logarithmic Function with Different Factors")
plt.legend()
plt.grid(True)
plt.show()
