#
# https://stackoverflow.com/questions/72581918/how-do-i-move-a-character-based-on-its-rotation
#
import pygame, math

pygame.init()
size = width, height = 600, 600
green = 50, 168, 82
screen = pygame.display.set_mode(size)

WINDOW_SIZE = (600, 400)


screen = pygame.display.set_mode(WINDOW_SIZE, 0, 32)  # initiate the window


class Player:
    def __init__(self):

        self.image = pygame.image.load("graphics/ship.png")
        # self.o_size = 19, 19
        # self.new_size = (
        #     self.o_size[0] * size_multiplier,
        #     self.o_size[1] * size_multiplier,
        # )
        # self.image = pygame.transform.scale(self.image, self.new_size)
        self.base_image = self.image

        self.x, self.y = 300, 300
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        self.rotation = 0

        self.rotate_speed = 4

        self.rocket_speed_x = 0
        self.rocket_speed_y = 0
        self.thrusting = False
        self.ship_mass = 0.1  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.04  # Gravity affecting the rocket
        self.thrust_power = 1  # Power of thrust

    # called when space key pressed
    def start_thrusting(self):
        self.thrusting = True

    # called when space key released
    def stop_thrust(self):
        self.thrusting = False
        # self.acceleration = 0.1

    def rotate(self, amount):
        self.rotation += amount
        if self.rotation > 360:
            self.rotation -= 360
        elif self.rotation < 0:
            self.rotation += 360
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

        self.x += self.vx
        self.y += self.vy

    # releasing the thrust doesn't remove all the horizontal velocity
    # and with the ship pointing up and feathering the thrust it will
    # continue to move horizontally even though the ship is pointing up
    def update_velocity(self):

        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        self.vx += thrust_force_x * self.acceleration
        self.vy += thrust_force_y * self.acceleration

        # cap x velocity
        self.vx = max(min(self.vx, 5), -5)
        # cap y velocity
        self.vy = max(min(self.vy, 10), -5)

        print(self.vx)

        self.x += self.vx
        self.y += self.vy

    def update(self):
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        # if self.thrusting:
        #     self.update_velocity()
        # else:
        #     self.apply_drag()

        # self.vy += self.gravity

        # Wrap the rocket around the screen
        self.x = self.x % 600
        self.y = self.y % 400


player = Player()
fpsClock = pygame.time.Clock()

while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()

    player.update()
    screen.fill(green)
    screen.blit(player.image, player.rect)
    pygame.display.update()
    fpsClock.tick(60)
