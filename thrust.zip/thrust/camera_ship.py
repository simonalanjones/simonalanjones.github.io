import math
from random import randint
import pygame
import sys
from settings import *


class Tree(pygame.sprite.Sprite):
    def __init__(self, pos, group):
        super().__init__(group)
        self.image = pygame.image.load("graphics/tree.png").convert_alpha()
        self.rect = self.image.get_rect(topleft=pos)


class Player(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)
        # def __init__(self, size_multiplier):
        self.image = pygame.image.load("graphics/ship2.png")
        self.o_size = 19, 19
        self.new_size = (
            self.o_size[0] * 3,
            self.o_size[1] * 3,
        )
        self.image = pygame.transform.scale(self.image, self.new_size)
        self.base_image = self.image

        self.x, self.y = 300, 300
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        self.rotation = 0
        self.rotate_speed = 4

        self.rocket_speed_x = 0
        self.rocket_speed_y = 0
        self.thrusting = False
        self.ship_mass = 0.1  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.04  # Gravity affecting the rocket
        self.thrust_power = 1  # Power of thrust

    # called when space key pressed
    def start_thrusting(self):
        self.thrusting = True

    # called when space key released
    def stop_thrust(self):
        self.thrusting = False
        # self.acceleration = 0.1

    def rotate(self, amount):
        self.rotation += amount
        if self.rotation > 360:
            self.rotation -= 360
        elif self.rotation < 0:
            self.rotation += 360
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

        self.x += self.vx
        self.y += self.vy

    # releasing the thrust doesn't remove all the horizontal velocity
    # and with the ship pointing up and feathering the thrust it will
    # continue to move horizontally even though the ship is pointing up
    def update_velocity(self):

        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        self.vx += thrust_force_x * self.acceleration
        self.vy += thrust_force_y * self.acceleration

        # cap x velocity
        self.vx = max(min(self.vx, 5), -5)
        # cap y velocity
        self.vy = max(min(self.vy, 10), -5)

        self.x += self.vx
        self.y += self.vy

    def update(self):
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        if self.thrusting:
            self.update_velocity()
        else:
            self.apply_drag()

        self.vy += self.gravity


class CameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()

        # camera offset
        self.offset = pygame.math.Vector2(300, 100)
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2

        # box setup
        self.camera_borders = {"left": 200, "right": 200, "top": 200, "bottom": 200}
        l = self.camera_borders["left"]
        t = self.camera_borders["top"]
        w = self.display_surface.get_size()[0] - (
            self.camera_borders["left"] + self.camera_borders["right"]
        )

        h = self.display_surface.get_size()[1] - (
            self.camera_borders["top"] + self.camera_borders["bottom"]
        )
        self.camera_rect = pygame.Rect(l, t, w, h)

        # ground
        self.ground_surf = pygame.image.load("graphics/ground.png").convert_alpha()
        self.ground_rect = self.ground_surf.get_rect(topleft=(0, 0))

    # ============================
    # use the player centre point?
    def center_target_camera(self, target):
        self.offset.x = target.rect.centerx - self.half_w
        self.offset.y = target.rect.centery - self.half_h

    def box_target_camera(self, target):
        player_center_x = target.rect.centerx
        player_center_y = target.rect.centery

        # Calculate the new camera position based on the player's center
        new_camera_left = player_center_x - self.half_w
        new_camera_top = player_center_y - self.half_h

        # Update the camera rectangle
        self.camera_rect.topleft = (new_camera_left, new_camera_top)

        # Clamp the camera within the level boundaries
        self.camera_rect.clamp_ip(self.ground_rect)

        # Update the camera offset based on the camera rectangle
        self.offset = self.camera_rect.topleft - pygame.math.Vector2(
            self.camera_borders["left"], self.camera_borders["top"]
        )

    def custom_draw(self, player):
        # self.center_target_camera(player)
        self.box_target_camera(player)
        ground_offset = self.ground_rect.topleft - self.offset
        self.display_surface.blit(self.ground_surf, ground_offset)

        for sprite in sorted(self.sprites(), key=lambda sprite: sprite.rect.centery):
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)
        pygame.draw.rect(self.display_surface, "yellow", self.camera_rect, 5)


pygame.init()

screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
pygame.display.set_caption("Camera Example")

camera_group = CameraGroup()
# player = Player((640, 360), camera_group)
player = Player(camera_group)

for i in range(20):
    random_x = randint(0, 1000)
    random_y = randint(0, 1000)
    Tree((random_x, random_y), camera_group)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()

    screen.fill("#71ddee")
    camera_group.update()
    camera_group.custom_draw(player)
    pygame.draw.rect(screen, (255, 255, 255), player.rect, 2)

    pygame.display.update()
    clock.tick(60)
