import pygame
import sys
import math
from os import path
from settings import *

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
ROCKET_SIZE = 20
MAX_SPEED = 5
ROTATE_SPEED = 4
THRUST_POWER = 0.2
GRAVITY = 0.03
INERTIA_FACTOR = 0.99

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)


# Create the screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Thrust Game")

# Rocket properties
rocket_x = WIDTH // 2
rocket_y = HEIGHT // 2
rocket_angle = 90  # Initially pointing up (0 degrees)
rocket_speed_x = 0
rocket_speed_y = 0

# Game loop
clock = pygame.time.Clock()
running = True


class Map:
    def __init__(self, filename):
        self.data = []
        with open(filename, "rt") as f:
            for line in f:
                self.data.append(line.strip())

        self.tilewidth = len(self.data[0])
        self.tileheight = len(self.data)
        self.width = self.tilewidth * TILESIZE
        self.height = self.tileheight * TILESIZE


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("game")
        self.clock = pygame.time.Clock()
        game_folder = path.dirname(__file__)
        self.map = Map(path.join(game_folder, "map2.txt"))
        self.load_data()


while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        rocket_angle += ROTATE_SPEED
    if keys[pygame.K_RIGHT]:
        rocket_angle -= ROTATE_SPEED
    if keys[pygame.K_SPACE]:
        thrust_x = THRUST_POWER * math.cos(math.radians(rocket_angle))
        thrust_y = -THRUST_POWER * math.sin(math.radians(rocket_angle))
        rocket_speed_x += thrust_x
        rocket_speed_y += thrust_y

    # Apply gravity
    rocket_speed_y += GRAVITY

    # Apply inertia
    rocket_speed_x *= INERTIA_FACTOR
    rocket_speed_y *= INERTIA_FACTOR

    # Limit maximum speed
    rocket_speed_x = max(-MAX_SPEED, min(rocket_speed_x, MAX_SPEED))
    rocket_speed_y = max(-MAX_SPEED, min(rocket_speed_y, MAX_SPEED))

    # Update position
    rocket_x += rocket_speed_x
    rocket_y += rocket_speed_y

    # Wrap the rocket around the screen
    rocket_x %= WIDTH
    rocket_y %= HEIGHT

    # Clear the screen
    screen.fill(BLACK)

    # Draw the rocket
    rocket_image = pygame.Surface((ROCKET_SIZE, ROCKET_SIZE))
    pygame.draw.polygon(
        rocket_image, WHITE, [(0, 0), (ROCKET_SIZE, ROCKET_SIZE // 2), (0, ROCKET_SIZE)]
    )
    rocket_image.set_colorkey(BLACK)
    rotated_rocket = pygame.transform.rotate(rocket_image, rocket_angle)
    rocket_rect = rotated_rocket.get_rect(center=(rocket_x, rocket_y))
    screen.blit(rotated_rocket, rocket_rect)

    # Update the display
    pygame.display.flip()

    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()
