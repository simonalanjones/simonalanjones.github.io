import pygame
import sys
import math
import time

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
FPS = 60
ROCKET_SIZE = 20
MAX_SPEED = 3
ROTATE_SPEED = 3

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Create the screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Thrust Game")


class Rocket(pygame.sprite.Sprite):  # Corrected the superclass
    def __init__(self):
        super().__init__()  # Call the superclass constructor
        self.image_original = pygame.image.load("graphics/ship.png").convert_alpha()
        self.image = self.image_original.copy()
        self.rect = self.image.get_rect()
        WIDTH, HEIGHT = 800, 600
        # Rocket properties
        self.rect.x = WIDTH // 2
        self.rect.y = HEIGHT // 2
        self.rocket_angle = 0  # Initially pointing right (0 degrees)
        self.rocket_speed_x = 0
        self.rocket_speed_y = 0
        # Ship mass (heavier ships require more thrust)
        self.ship_mass = 1.9

        # Initial gravitational force and time
        self.gravity = 0.002
        self.max_gravity = 0.02
        self.current_time = 0

        # Define thrust variables
        self.thrusting = False
        self.thrust_start_time = 0
        self.thrust_delay = 4.5

        # Inertia variables
        self.inertia_factor = 0.99  # Adjust this value to control inertia
        self.thrust_power = 0.1 / self.ship_mass

    def apply_thrust(self):
        if (
            not self.thrusting
            and self.current_time - self.thrust_start_time >= self.thrust_delay
        ):
            self.thrust_start_time = self.current_time
            self.thrusting = True

    def stop_thrust(self):
        self.thrusting = False

    def rotate_left(self):
        self.rocket_angle += ROTATE_SPEED
        self.image = pygame.transform.rotate(self.image_original, self.rocket_angle)
        self.rect = self.image.get_rect(center=self.rect.center)

    def rotate_right(self):
        self.rocket_angle -= ROTATE_SPEED
        self.image = pygame.transform.rotate(self.image_original, self.rocket_angle)
        self.rect = self.image.get_rect(center=self.rect.center)

    def update(self):
        # Print gravity and rocket_speed_y for debugging
        print("Gravity:", self.gravity)
        print("Rocket Speed Y:", self.rocket_speed_y)

        # Apply gravitational force
        self.current_time += 1
        self.gravity = min(self.max_gravity, self.gravity + 0.001)
        self.rocket_speed_y += self.gravity

        if self.thrusting:
            self.thrust_vector_x = self.thrust_power * math.cos(
                math.radians(self.rocket_angle)
            )
            self.thrust_vector_y = -self.thrust_power * math.sin(
                math.radians(self.rocket_angle)
            )

        # Apply inertia to gradually change velocity
        self.rocket_speed_x = (
            self.rocket_speed_x * self.inertia_factor + self.thrust_vector_x
            if self.thrusting
            else 0
        )
        self.rocket_speed_y = (
            self.rocket_speed_y * self.inertia_factor + self.thrust_vector_y
        )

        self.rect.x += self.rocket_speed_x
        self.rect.y += self.rocket_speed_y

        # Wrap the rocket around the screen
        self.rect.x %= WIDTH
        self.rect.y %= HEIGHT


# # Rocket properties
# rocket_x = WIDTH // 2
# rocket_y = HEIGHT // 2
# rocket_angle = 0
# rocket_angle = 90  # Initially pointing up (0 degrees)
# rocket_speed_x = 0
# rocket_speed_y = 0

# # Ship mass (heavier ships require more thrust)
# ship_mass = 1.9

# # Initial gravitational force and time
# gravity = 0.002
# max_gravity = 0.02
# current_time = 0

# # Define thrust variables
# thrusting = False
# thrust_start_time = 0
# thrust_delay = 4.5

# # Inertia variables
# inertia_factor = 0.99  # Adjust this value to control inertia

# thrust_power = 0.1 / ship_mass

# Game loop
clock = pygame.time.Clock()
running = True
player = Rocket()

while running:
    # print(player.rocket_speed_y)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.apply_thrust()

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()

    player.update()
    # Clear the screen
    screen.fill(BLACK)

    screen.blit(player.image, player.rect)
    # Update the display
    pygame.display.flip()
    clock.tick(FPS)


# Quit Pygame
pygame.quit()
sys.exit()
