import math
import pygame
import sys
from pytmx.util_pygame import load_pygame
from settings import *


class TextSprite(pygame.sprite.Sprite):
    def __init__(self, text, font, color, position):
        super().__init__()
        self.image = font.render(text, True, color)
        self.rect = self.image.get_rect(topleft=position)


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class Player(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)

        self.image = pygame.image.load("graphics/ship.png").convert()
        self.base_image = self.image
        self.x, self.y = 300, 220
        self.text_color = (255, 255, 255)  # Text color

        self.thrusting = False
        self.acceleration = 0.1
        self.gravity = 0.02

        self.max_gravity = 1  # Maximum gravity
        self.thrust_power = 1.5
        self.thrust_force_x = 0
        self.thrust_force_y = 0
        self.rotation = 0
        self.rotate_speed = 2

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity

        self.colliding = False
        # self.draw_colored_line()

        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        self.hit_rect = pygame.Rect(0, 0, 65, 65)
        self.hit_rect.center = self.rect.center

    def apply_gravity(self):
        pass
        # self.vy += self.gravity  ### gravity addin

    def update_velocity(self):
        if self.thrusting:
            # Apply thrust
            self.update_velocity_x()
            self.update_velocity_y()

        else:
            # Gradually decrease velocity only when not thrusting
            self.vx *= 0.99

            if abs(self.vy) > 0.01:  # Adjust the threshold as needed
                self.vy *= 0.98
            else:
                self.vy = 0

            if abs(self.vx) > 0.01:  # Adjust the threshold as needed
                self.vx *= 0.99
            else:
                self.vx = 0

    def update(self, tile_sprite_group):

        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        # update hit rect position
        # self.hit_rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        self.update_velocity()
        self.cap_velocities()
        self.apply_gravity()

        self.x += self.vx
        # self.check_collision_x(tile_sprite_group)

        self.y += self.vy

        # self.hit_rect.centerx = self.x
        # self.hit_rect.centery = self.y

        # self.check_collision_y(tile_sprite_group)
        # pygame.draw.rect(self.image, WHITE, self.hit_rect, 2)
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 2)

    def rotate(self, amount):
        self.rotation += amount
        if self.rotation > 360:
            self.rotation -= 360
        elif self.rotation < 0:
            self.rotation += 360
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    def render_velocity_text(self, screen, font):
        # Create text sprites for vx, vy, rotation, thrust_force_x, and thrust_force_y
        text_vx_sprite = TextSprite(f"vx: {self.vx}", font, self.text_color, (10, 10))
        text_vy_sprite = TextSprite(f"vy: {self.vy}", font, self.text_color, (10, 30))
        text_rot_sprite = TextSprite(
            f"Rot: {self.rotation}", font, self.text_color, (10, 50)
        )
        text_tfx_sprite = TextSprite(
            f"TFX: {self.thrust_force_x}", font, self.text_color, (10, 70)
        )
        text_tfy_sprite = TextSprite(
            f"TFY: {self.thrust_force_y}", font, self.text_color, (10, 90)
        )
        text_ship_rect_r = TextSprite(
            f"Shp rect.r: {self.rect.right}", font, self.text_color, (10, 110)
        )
        text_is_colliding = TextSprite(
            f"Colliding: {self.colliding}", font, self.text_color, (10, 130)
        )
        # Add text sprites to a sprite group
        text_sprites = pygame.sprite.Group(
            text_vx_sprite,
            text_vy_sprite,
            text_rot_sprite,
            text_tfx_sprite,
            text_tfy_sprite,
            text_ship_rect_r,
            text_is_colliding,
        )

        return text_sprites

    def start_thrusting(self):
        self.thrusting = True

    def stop_thrust(self):
        self.thrusting = False

    def cap_velocities(self):

        if self.vx > 5.0:
            self.vx = 5.0
        elif self.vx < -5.0:
            self.vx = -5.0

        if self.vy > 10:
            self.vy = 10
        elif self.vy < -10:
            self.vy = -10

    def get_hits(self, tiles):
        hits = []
        for tile in tiles:
            if self.rect.colliderect(tile):
                hits.append(tile)
        return hits

    def clear_collision(self, tile):
        repeats = 0
        if self.colliding:
            if self.vx > 0 and self.rect.right > tile.rect.left:
                print("going right")
                if self.vx < 1:
                    self.vx = 1
                while (
                    self.rect.colliderect(tile.rect)
                    and self.rect.right > tile.rect.left
                ):
                    repeats += 1
                    if repeats > 20:
                        # self.colliding = False
                        return
                    else:
                        self.x -= abs(
                            self.vx
                        )  # Move the sprite back by the same amount it moved forward
                        self.rect.x -= abs(
                            self.vx
                        )  # Update rect's x-coordinate to match new position

                self.vx = -self.vx
                self.colliding = False
                return

            elif self.vx < 0 and self.rect.left < tile.rect.right:
                print("going left")
                while (
                    self.rect.colliderect(tile.rect)
                    and self.rect.left < tile.rect.right
                ):
                    repeats += 1
                    if repeats > 20:
                        # self.colliding = False
                        print("exit loop left")
                        return

                    else:
                        self.x += abs(
                            self.vx
                        )  # Move the sprite back by the same amount it moved forward
                        self.rect.x += abs(self.vx)

                self.vx = -self.vx
                self.colliding = False
                return

    def check_collision_y(self, tilemap):
        return
        # for tile in tilemap:
        #     if self.rect.colliderect(tile.rect):
        #         if self.vy > 0 and self.rect.bottom > tile.rect.top:
        #             self.vy = -self.vy
        #             self.y -= 10
        #             return
        #         if self.vy < 0 and self.rect.top < tile.rect.bottom:
        #             self.vy = -self.vy
        #             self.y += 10
        #             return

    # maybe filter out x collisions if vx < 1
    # need markers on collision spots
    # width of sprite/rect changes depending on rotation

    ########### CHECK BASED ON ROTATION VALUE??? ###############

    def check_collision_x(self, tilemap):

        future_x = self.rect.x + self.vx
        future_y = self.rect.y + self.vy

        # collisions = self.get_hits(tiles)
        # if not self.colliding:
        collided_tiles = []
        for tile in tilemap:
            if tile.rect.colliderect(
                (future_x, self.rect.y, self.rect.width, self.rect.height)
            ):

                # if self.vx > 0:
                #     self.rect.right = tile.rect.left
                # elif self.vx < 0:
                #     self.rect.left = tile.rect.right

                # self.vx = -self.vx
                # self.vx = 0
                # self.vy = 0
                # return

                if self.vx > 0 and self.rect.right > tile.rect.left:
                    self.vx = -self.vx
                    # self.clear_collision(tile)
                    self.colliding = False
                    self.x -= 10
                    return

                elif self.vx < 0 and self.rect.left < tile.rect.right:
                    self.vx = -self.vx
                    # self.clear_collision(tile)
                    self.colliding = False
                    self.x += 10
                    return

        # elif self.vy > 0 and self.rect.bottom > tile.rect.top:
        #     print("here y")
        #     self.vy = -self.vy
        #     self.colliding = False
        #     self.y -= 20
        #     return
        # return

        # print(tile.rect.left)
        # print(self.rect.left)

        # if tile not in collided_tiles:
        #     collided_tiles.append(tile)
        #     collision_area = self.rect.clip(tile.rect)
        #     print(collision_area)
        #     if collision_area.width > collision_area.height:
        #         if self.rect.left < tile.rect.left:
        #             self.rect.right = tile.rect.left
        #         else:
        #             self.rect.left = tile.rect.right
        #         self.vx = -self.vx
        #     else:
        #         if self.rect.top < tile.rect.top:
        #             # Collision happened below the tile
        #             self.rect.bottom = tile.rect.top
        #         else:
        #             # Collision happened above the tile
        #             self.rect.top = tile.rect.bottom
        #         self.vy = -self.vy

        # <rect(680, 256, 72, 27)>
        # x,y w,h
        # precise area of collision

        # collision_area = sprite1.rect.clip(sprite2.rect)
        # for tile in collisions:
        #     print(tile)

        #     # trap collisions while moving right
        #     if self.vx > 0:  # Hit tile moving right
        #         self.x -= 5
        #         self.vx = -self.vx
        #         print("hit right")
        #         return

        #         # print(self.x + self.rect.w)
        #         # self.x -= 5  # tile.rect.left - 2

        #     elif self.vx < 0:  # Hit tile moving left
        #         self.vx = -self.vx
        #         self.x += 5
        #         print("hit left")
        #         return
        #     # self.rect.x = self.position.x

    # def handle_collision(self, collided_tiles):
    #     collision_tile = collided_tiles[0]
    #     self.handle_collision_x(collision_tile)
    #     self.handle_collision_y(collision_tile)

    def update_velocity_x(self):
        # Calculate the horizontal thrust force based on the player's rotation
        # Use the sine function considering the player's rotation
        self.thrust_force_x = (
            -1 * self.thrust_power * math.sin(math.radians(self.rotation))
        )

        # Apply the thrust force to the horizontal velocity only when thrusting
        if self.thrusting:
            self.vx += self.thrust_force_x * self.acceleration

    def update_velocity_y(self):

        self.thrust_force_y = -self.thrust_power * math.sin(
            math.radians(self.rotation + 90)
        )

        if self.thrusting:
            self.vy += self.thrust_force_y * self.acceleration * 0.97

        # self.gravity = min(
        #     self.max_gravity, self.gravity + 0.001
        # )  # Increase gravity over time (capped at max_gravity)


class CameraGroup(pygame.sprite.Group):
    def __init__(self, sprite_group):
        # sprite group is tiles
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.sprite_group = sprite_group

        # camera offset
        self.offset = pygame.math.Vector2(400, 200)  # this is an arbitary offset
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2

        # box setup
        self.camera_borders = {"left": 300, "right": 300, "top": 200, "bottom": 200}
        l = self.camera_borders["left"]
        t = self.camera_borders["top"]
        w = self.display_surface.get_size()[0] - (
            self.camera_borders["left"] + self.camera_borders["right"]
        )

        h = self.display_surface.get_size()[1] - (
            self.camera_borders["top"] + self.camera_borders["bottom"]
        )
        self.camera_rect = pygame.Rect(l, t, w, h)

        self.bounding_rect = pygame.Rect(0, 0, 0, 0)
        for sprite in self.sprite_group:
            self.bounding_rect.union_ip(sprite.rect)

        self.ground_rect = pygame.Rect(
            0, 0, self.bounding_rect.width, self.bounding_rect.height
        )
        self.ground_rect.topleft = self.bounding_rect.topleft

    def box_target_camera(self, target):

        if target.rect.left < self.camera_rect.left:
            self.camera_rect.left = target.rect.left
        if target.rect.right > self.camera_rect.right:
            self.camera_rect.right = target.rect.right
        if target.rect.top < self.camera_rect.top:
            self.camera_rect.top = target.rect.top
        if target.rect.bottom > self.camera_rect.bottom:
            self.camera_rect.bottom = target.rect.bottom

        self.offset.x = self.camera_rect.left - self.camera_borders["left"]
        self.offset.y = self.camera_rect.top - self.camera_borders["top"]

    def custom_draw(self, player):

        self.box_target_camera(player)

        # Draw tile sprites
        for sprite in self.sprite_group:
            sprite_offset = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, sprite_offset)

        # Draw player sprite
        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)


pygame.init()

screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
pygame.display.set_caption("Camera Example")

tmx_data = load_pygame("basic.tmx")
tile_sprite_group = pygame.sprite.Group()


for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        Tile(pos=pos, surf=surf, groups=tile_sprite_group)


camera_group = CameraGroup(tile_sprite_group)
player = Player(camera_group)


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()

    screen.fill("#71ddee")

    # this is calling the update on the group which includes the player
    # as the player has been added to the camera_group
    camera_group.update(tile_sprite_group)
    camera_group.custom_draw(player)
    # player.update()
    font = pygame.font.Font(None, 36)  # Define your font
    text_sprites = player.render_velocity_text(screen, font)  # Create text sprites

    # Draw the text sprites onto the screen
    text_sprites.draw(screen)

    # screen.blit(player.image, player.rect)

    pygame.display.update()
    clock.tick(60)
