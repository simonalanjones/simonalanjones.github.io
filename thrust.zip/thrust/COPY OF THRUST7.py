# COPY OF THRUST7.py
import math
import pygame
import sys
from settings import *
from pytmx.util_pygame import load_pygame


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class PhysicsObject(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        self.image = pygame.image.load("graphics/ship.png").convert_alpha()

        # make a copy of the image untouched for reference later in rotation
        self.base_image = self.image

        # initial x and y position
        self.x, self.y = 300, 220

        # create a vector2 for the sprite position/rect
        self.pos = pygame.Vector2(self.x, self.y)

        # create a rect based on the size of the image
        self.rect = self.image.get_rect()
        # place the rect center at the x,y position
        self.rect.center = self.pos

        # create an alternative rect which is a constant 60,60 width x height
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        # make the centre of the hit-rect based on the normal rect
        self.hit_rect.center = self.rect.center

        # starting rotation
        self.rotation = 0

        self.rotate_speed = 4  # Base rotation speed
        self.max_rotate_speed = 8  # Maximum rotation speed
        self.scaling_factor = 0.5  # Starting value for the scaling factor

        self.thrusting = False
        self.ship_mass = 2.5  # Adjust this value to control the ship's mass

        self.vx = 0  # Initial horizontal velocity
        self.vy = 0  # Initial vertical velocity
        self.acceleration = 0.1  # Acceleration due to thrust
        self.gravity = 0.03  # Gravity affecting the rocket
        self.thrust_power = 0.8  # Power of thrust
        self.landed = False

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def can_land_on_tile(self, sprite):
        left_edge_of_sprite = sprite.rect.left
        left_edge_of_ship = self.rect.left

        right_edge_of_sprite = sprite.rect.right
        right_edge_of_ship = self.rect.right

        if (
            self.rect.bottom < sprite.rect.centery
            and left_edge_of_sprite < left_edge_of_ship
            and right_edge_of_sprite > right_edge_of_ship
        ):
            pass

    def collision_direction_word(self, tile):
        # Check for collision and handle overlaps
        player = self
        collision = pygame.sprite.collide_rect(player, tile)
        if collision:
            player_rect = player.rect
            tile_rect = tile.rect

            # Get the center points of the player and tile sprites
            player_center_x = player_rect.centerx
            player_center_y = player_rect.centery
            tile_center_x = tile_rect.centerx
            tile_center_y = tile_rect.centery

            # Calculate the horizontal and vertical distances between centers
            dx = player_center_x - tile_center_x
            dy = player_center_y - tile_center_y

            # Determine the direction of overlap based on the majority of the player sprite's position
            if abs(dx) > abs(dy):
                # Majority of player sprite is left or right of the tile
                if dx < 0:
                    return "right"
                    # print("Majority of player sprite is to the right of the tile")
                else:
                    return "left"
                    # print("Majority of player sprite is to the left of the tile")
            else:
                # Majority of player sprite is above or below the tile
                if dy < 0:
                    return "bottom"
                    # print("Majority of player sprite is below the tile")
                else:
                    return "top"
                    # print("Majority of player sprite is above the tile")

    def get_collision_direction(self, sprite):

        # set up ship edges
        ship_right = self.hit_rect.right
        ship_left = self.hit_rect.left
        ship_top = self.hit_rect.top
        ship_bottom = self.hit_rect.bottom

        # set up sprite edges
        sprite_right = sprite.rect.right
        sprite_left = sprite.rect.left
        sprite_centerx = sprite.rect.centerx
        sprite_centery = sprite.rect.centery
        sprite_top = sprite.rect.top
        sprite_bottom = sprite.rect.bottom

        right_edge_of_sprite = sprite.rect.right
        right_edge_of_ship = self.rect.right

        # test right side collision
        if ship_right < sprite_centerx and ship_left < sprite_centerx and self.vx > 0:
            return "right"

        # test left side collision
        elif ship_left > sprite_centerx and ship_right > sprite_centerx and self.vx < 0:
            return "left"

        elif (
            ship_top < sprite_top
            and (sprite_left < ship_left or sprite_right > ship_right)
            and self.vy > 0
            # and ship_left > sprite_left
            # and ship_right < sprite_right
        ):
            return "below"

        elif ship_top < sprite_bottom and self.vy < 0:
            return "above"

    def check_collisions(self, sprite_group):
        if not self.landed:
            hits = pygame.sprite.spritecollide(
                self, sprite_group, False, self.collide_hit_rect
            )
            if hits:
                sprite = hits[0]

                collision_word = self.collision_direction_word(sprite)
                print("dir", self.get_collision_direction(sprite))

                left_edge_of_sprite = sprite.rect.left
                left_edge_of_ship = self.rect.left

                right_edge_of_sprite = sprite.rect.right
                right_edge_of_ship = self.rect.right

                if (
                    self.rect.bottom < sprite.rect.centery
                    and left_edge_of_sprite < left_edge_of_ship
                    and right_edge_of_sprite > right_edge_of_ship
                ):

                    # print("Collision happened below the player.")

                    collision_below = True
                else:
                    # print("not below")
                    collision_below = False

                if collision_below and ((self.rotation < 24 or self.rotation > 340)):

                    if self.vy < 3:
                        #### check collision is from below!
                        print("landing")
                        # print(self.rotation)
                        print(self.vy)
                        self.vx = 0
                        self.vy = 0
                        self.landed = True
                        self.rotation = 0
                    else:
                        self.vx = -self.vx
                        self.vy = -self.vy
                        return

                elif self.vx > 0 and self.vy > 0:
                    # print("hit down to right")
                    self.vx = -self.vx
                    self.vy = -self.vy
                    self.pos.x -= 5
                    # self.vel = pygame.Vector2(0, 1)
                    return

                elif self.vx > 0 and self.vy < 0:
                    # print("hit up to right")
                    self.vx = -self.vx
                    self.vy = -self.vy
                    # self.vel = -self.vel
                    return

                elif self.vx < 0 and self.vy < 0:
                    # print("hit up to left")
                    self.vx = -self.vx
                    self.vy = -self.vy
                    # self.vel = -self.vel
                    return

                elif self.vx < 0 and self.vy > 0:
                    # print("hit down to left")
                    self.vx = -self.vx
                    self.vy = -self.vy
                    # self.vel = -self.vel
                    self.pos.x += 5
                    # self.vel = pygame.Vector2(0, 1)
                    return

    def update(self):

        if self.thrusting:
            self.landed = False
            self.update_velocity()
        else:
            self.apply_drag()

        if not self.landed:
            self.update_rotation()
            self.apply_gravity()

        # Update position based on velocity
        self.pos += pygame.Vector2(self.vx, self.vy)

        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=self.pos)
        self.hit_rect.center = self.rect.center

    def update_rotation(self):
        if not self.landed:
            # Calculate velocity magnitude
            velocity_magnitude = pygame.math.Vector2(self.vx, self.vy).length()

            # Dampen rotation speed based on velocity magnitude
            if velocity_magnitude > 0:
                # Calculate a new rotation speed based on velocity magnitude
                new_rotate_speed = self.max_rotate_speed / (
                    velocity_magnitude * self.scaling_factor
                )

                # Clamp the rotation speed to avoid it becoming too high
                self.rotate_speed = min(new_rotate_speed, self.max_rotate_speed)
            else:
                # Reset rotation speed when velocity magnitude is zero
                self.rotate_speed = self.max_rotate_speed

    def update_velocity(self):
        # Calculate thrust force based on thrust power and ship orientation
        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        # Calculate acceleration using Newton's second law: F = ma
        acceleration_x = thrust_force_x / self.ship_mass
        acceleration_y = thrust_force_y / self.ship_mass

        # Update velocity based on acceleration
        self.vx += acceleration_x
        self.vy += acceleration_y

        # Cap velocities
        self.vx = max(min(self.vx, 5), -5)
        self.vy = max(min(self.vy, 5), -5)

    def _update_velocity(self):

        thrust_force_x = self.thrust_power * math.cos(math.radians(self.rotation + 90))
        thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation + 90))

        self.vx += thrust_force_x * self.acceleration
        self.vy += thrust_force_y * self.acceleration

        # Cap velocities
        self.vx = max(min(self.vx, 5), -5)
        self.vy = max(min(self.vy, 5), -5)

    def apply_gravity(self):
        # Apply gravity based on ship orientation and mass
        gravity_force = self.gravity * self.ship_mass

        # Update velocity based on gravity
        self.vy += gravity_force

    def __apply_gravity(self):
        # Apply gravity based on ship orientation
        gravity_vector = pygame.Vector2(0, self.gravity)  # .rotate(self.rotation)
        # print(gravity_vector)
        # self.vx += gravity_vector.x
        self.vy += gravity_vector.y

    def apply_drag(self):
        self.vx *= 0.99
        self.vy *= 0.99

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    # call when space key pressed
    def start_thrusting(self):
        self.landed = False
        self.thrusting = True

    # called when space key released
    def stop_thrust(self):
        self.thrusting = False


class CameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()

        # camera offset
        self.offset = pygame.math.Vector2(0, 0)
        self.half_w = self.display_surface.get_size()[0] // 2
        self.half_h = self.display_surface.get_size()[1] // 2

        # box setup
        self.camera_borders = {"left": 200, "right": 200, "top": 200, "bottom": 200}
        l = self.camera_borders["left"]
        t = self.camera_borders["top"]
        w = self.display_surface.get_size()[0] - (
            self.camera_borders["left"] + self.camera_borders["right"]
        )

        h = self.display_surface.get_size()[1] - (
            self.camera_borders["top"] + self.camera_borders["bottom"]
        )
        self.camera_rect = pygame.Rect(l, t, w, h)

        # ground
        self.ground_surf = pygame.image.load("graphics/ground.png").convert_alpha()
        self.ground_rect = self.ground_surf.get_rect(topleft=(0, 0))

    # ============================
    # use the player centre point?
    def center_target_camera(self, target):
        self.offset.x = target.rect.centerx - self.half_w
        self.offset.y = target.rect.centery - self.half_h

    def _box_target_camera(self, target):
        player_center_x = target.rect.centerx
        player_center_y = target.rect.centery

        # Calculate the new camera position based on the player's center
        new_camera_left = player_center_x - self.half_w
        new_camera_top = player_center_y - self.half_h

        # Update the camera rectangle
        self.camera_rect.topleft = (new_camera_left, new_camera_top)

        # Clamp the camera within the level boundaries
        self.camera_rect.clamp_ip(self.ground_rect)

        # Update the camera offset based on the camera rectangle
        self.offset = self.camera_rect.topleft - pygame.math.Vector2(
            self.camera_borders["left"], self.camera_borders["top"]
        )

    def custom_draw(self, player):

        self.center_target_camera(player)
        # self.box_target_camera(player)
        ground_offset = self.ground_rect.topleft - self.offset
        # self.display_surface.blit(self.ground_surf, ground_offset)

        for sprite in self.sprites():
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)
        # pygame.draw.rect(self.display_surface, "yellow", self.camera_rect, 5)
        # pygame.draw.rect(self.display_surface, (255, 255, 255), player.hit_rect, 2)


pygame.init()
screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()

player = Player()

camera_group = CameraGroup()


tmx_data = load_pygame("basic.tmx")
tile_sprite_group = pygame.sprite.Group()


for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        Tile(pos=pos, surf=surf, groups=tile_sprite_group)

camera_group.add(tile_sprite_group)
camera_group.add(player)
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    if not player.landed:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player.rotate_left()
        if keys[pygame.K_RIGHT]:
            player.rotate_right()

    screen.fill("#71ddee")
    # player.update()
    # tile_sprite_group.draw(screen)

    camera_group.update()
    camera_group.custom_draw(player)

    # screen.blit(player.image, player.rect)

    # pygame.draw.rect(screen, (255, 255, 255), player.hit_rect, 2)

    player.check_collisions(tile_sprite_group)

    pygame.display.update()
    clock.tick(60)
