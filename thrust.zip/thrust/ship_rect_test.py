import math
import pygame
import sys
from settings import *
from pytmx.util_pygame import load_pygame


class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft=pos)


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        self.image = pygame.image.load("graphics/ship_rot_90.png").convert()
        self.base_image = self.image
        self.x, self.y = 300, 220

        self.thrusting = False
        self.acceleration = 0.1

        self.rotation = 0
        self.rotate_speed = 2

        self.pos = pygame.Vector2(self.x, self.y)
        self.vel = pygame.Vector2(0, 0)

        self.rect = self.image.get_rect()
        self.hit_rect = pygame.Rect(0, 0, 60, 60)
        self.hit_rect.center = self.rect.center

        self.thrust_power = 1.5
        self.thrust_force_x = 0
        self.thrust_force_y = 0

    def collide_hit_rect(self, one, two):
        return one.hit_rect.colliderect(two.rect)

    def check_collisions(self, sprite_group):
        hits = pygame.sprite.spritecollide(
            self, sprite_group, False, self.collide_hit_rect
        )
        if hits:
            sprite = hits[0]
            # print(self.rotation)
            # collision_rect = sprite.rect
            # You can then access properties of the collision rectangle, such as its position, size, etc.
            # print("Collision rectangle details:", collision_rect)
            # print("Collision rectangle position:", collision_rect.topleft)
            # print("Collision rectangle size:", collision_rect.size)

            if self.vel.x > 0 and self.vel.y > 0:
                print("hit down to right")
                # self.vel = -self.vel
                self.pos.x -= 20
                self.vel = pygame.Vector2(0, 1)
                return

            elif self.vel.x > 0 and self.vel.y < 0:
                print("hit up to right")
                self.vel = -self.vel
                return

            elif self.vel.x < 0 and self.vel.y < 0:
                print("hit up to left")
                self.vel = -self.vel
                return

            elif self.vel.x < 0 and self.vel.y > 0:
                print("hit down to left")
                # self.vel = -self.vel
                self.pos.x += 20
                self.vel = pygame.Vector2(0, 1)
                return

            self.vel = pygame.Vector2(0, 0)

    def _check_collisions_x(self, sprite_group):

        hits = pygame.sprite.spritecollide(
            self, sprite_group, False, self.collide_hit_rect
        )

        if hits:
            # self.vel = -self.vel
            if self.vel.x > 0:
                print("hit in the right x")
                # self.pos.x = hits[0].rect.left - self.hit_rect.width / 2.0
                self.pos.x -= 30  # hits[0].rect.left - self.hit_rect.width / 2.0
                self.vel.x = +self.vel.x

            if self.vel.x < 0:
                print("hit in the left x")

                # this is adding from centre? - not enough offset ?
                # self.pos.x = hits[0].rect.right + self.hit_rect.width / 2.0
                self.pos.x += 30
                self.vel.x = -self.vel.x

            # self.vel.x = 0
            self.hit_rect.centerx = self.pos.x

    def _check_collisions_y(self, sprite_group):
        hits = pygame.sprite.spritecollide(
            self, sprite_group, False, self.collide_hit_rect
        )
        if hits:
            if self.vel.y > 0:
                print("hit in the bottom y")
                # self.pos.y = hits[0].rect.top - self.hit_rect.height / 2.0
                self.pos.y -= 90
                self.vel.y = -self.vel.y
                self.vel.x = 0

            if self.vel.y < 0:
                print("hit in the top y")
                # self.pos.y = hits[0].rect.bottom + self.hit_rect.height / 2.0
                self.pos.y += 30
                self.vel.y = -self.vel.y

            # self.vel.y = 0
            self.hit_rect.centery = self.pos.y

    def _update_velocity(self):
        if self.thrusting:
            # Apply thrust
            self.update_velocity_x()
            self.update_velocity_y()

        else:
            # Gradually decrease velocity only when not thrusting
            self.vx *= 0.99

            if abs(self.vy) > 0.01:  # Adjust the threshold as needed
                self.vy *= 0.98
            else:
                self.vy = 0

            if abs(self.vx) > 0.01:  # Adjust the threshold as needed
                self.vx *= 0.99
            else:
                self.vx = 0

    def move_up(self):
        self.vel = pygame.Vector2(0, -1)

    def move_down(self):
        self.vel = pygame.Vector2(0, 1)

    def move_left(self):
        self.vel = pygame.Vector2(-1, 0)

    def move_right(self):
        self.vel = pygame.Vector2(1, 0)

    def update_velocity(self):
        if self.thrusting:
            # Apply thrust
            self.update_velocity_x()
            self.update_velocity_y()
        else:
            # Gradually decrease velocity only when not thrusting
            self.vel.x *= 0.99

            if abs(self.vel.y) > 0.01:  # Adjust the threshold as needed
                self.vel.y *= 0.98
            else:
                self.vel.y = 0

            if abs(self.vel.x) > 0.01:  # Adjust the threshold as needed
                self.vel.x *= 0.99
            else:
                self.vel.x = 0

    def update(self, sprite_group):
        self.update_velocity()
        self.pos += self.vel

        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        # print(self.vel)

        self.hit_rect.centerx = self.pos.x
        self.hit_rect.centery = self.pos.y
        self.rect.center = self.hit_rect.center

        self.check_collisions(sprite_group)
        # self.check_collisions_y(sprite_group)
        # self.check_collisions_x(sprite_group)

        # pygame.draw.line(
        #     self.image,
        #     (255, 0, 0),
        #     (0, self.hit_rect.height - 1),
        #     (self.hit_rect.width, self.hit_rect.height - 1),
        #     5,
        # )
        # # right edge
        # pygame.draw.line(
        #     self.image,
        #     (255, 192, 203),
        #     (self.rect.width - 1, 0),
        #     (self.rect.width - 1, self.rect.height),
        #     10,
        # )
        # # left edge
        # pygame.draw.line(self.image, (0, 255, 255), (0, 0), (0, self.rect.height), 10)

        # update hit rect position
        # self.hit_rect = self.image.get_rect(center=(round(self.x), round(self.y)))

        # self.update_velocity()
        # self.cap_velocities()
        # self.apply_gravity()

        # self.x += self.vx
        # self.check_collision_x(tile_sprite_group)

        # self.y += self.vy

        # self.hit_rect.centerx = self.x
        # self.hit_rect.centery = self.y

        # self.check_collision_y(tile_sprite_group)

        self.rect.center = self.pos
        # pygame.draw.rect(self.image, WHITE, self.hit_rect, 2)

    def rotate(self, amount):
        self.rotation += amount
        if self.rotation > 360:
            self.rotation -= 360
        elif self.rotation < 0:
            self.rotation += 360
        self.image = pygame.transform.rotate(self.base_image, self.rotation)
        self.rect = self.image.get_rect(center=(round(self.x), round(self.y)))

    def rotate_left(self):
        self.rotation += self.rotate_speed
        self.rotation %= 360

    def rotate_right(self):
        self.rotation -= self.rotate_speed
        self.rotation %= 360

    def start_thrusting(self):
        self.thrusting = True
        self.vel = pygame.Vector2(0, 0)
        self.vel = pygame.Vector2(1, 0).rotate(-self.rotation)

    def stop_thrust(self):
        self.thrusting = False

    def cap_velocities(self):

        if self.vx > 5.0:
            self.vx = 5.0
        elif self.vx < -5.0:
            self.vx = -5.0

        if self.vy > 10:
            self.vy = 10
        elif self.vy < -10:
            self.vy = -10

    def update_velocity_x(self):
        # Calculate the horizontal thrust force based on the player's rotation
        # Use the sine function considering the player's rotation
        self.thrust_force_x = (
            -1 * self.thrust_power * math.sin(math.radians(self.rotation))
        )

        # Apply the thrust force to the horizontal velocity only when thrusting
        if self.thrusting:
            self.vel.x += self.thrust_force_x * self.acceleration

    def update_velocity_y(self):

        self.thrust_force_y = -self.thrust_power * math.sin(math.radians(self.rotation))

        if self.thrusting:
            self.vel.y += self.thrust_force_y * self.acceleration * 0.97


pygame.init()
screen_width, screen_height = 1280, 720
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
pygame.display.set_caption("Camera Example")

player = Player()
tile_sprite_group = pygame.sprite.Group()
tmx_data = load_pygame("basic.tmx")

for layer in tmx_data.visible_layers:
    for x, y, surf in layer.tiles():
        pos = (x * 128, y * 128)
        Tile(pos=pos, surf=surf, groups=tile_sprite_group)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.start_thrusting()
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                player.stop_thrust()

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.rotate_left()
    if keys[pygame.K_RIGHT]:
        player.rotate_right()
    if keys[pygame.K_w]:
        player.move_up()
    if keys[pygame.K_x]:
        player.move_down()
    if keys[pygame.K_a]:
        player.move_left()
    if keys[pygame.K_d]:
        player.move_right()

    screen.fill("#71ddee")

    player.update(tile_sprite_group)
    tile_sprite_group.draw(screen)
    screen.blit(player.image, player.rect)

    pygame.draw.rect(screen, (255, 255, 255), player.hit_rect, 2)

    pygame.display.update()
    clock.tick(60)
