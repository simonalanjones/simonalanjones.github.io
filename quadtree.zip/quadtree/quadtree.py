import pygame
import sys

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Initialize Pygame
pygame.init()

# Set screen dimensions
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 900
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Quadtree Example")


# Define Point class
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def draw(self):
        pygame.draw.circle(screen, RED, (self.x, self.y), 3)


# Define Boundary class to represent the boundaries of quadtree nodes
class Boundary:
    def __init__(self, x, y, w, h):
        self.x = x
        self.y = y
        self.w = w
        self.h = h

    def contains(self, point):
        return (
            self.x - self.w <= point.x <= self.x + self.w
            and self.y - self.h <= point.y <= self.y + self.h
        )


# Define Quadtree class
class Quadtree:
    def __init__(self, boundary, capacity):
        self.boundary = boundary  # Boundary of the quadtree node
        self.capacity = (
            capacity  # Maximum number of points in a node before subdivision
        )
        self.points = []  # Points within this node
        self.subdivided = False  # Whether this node has been subdivided
        self.northwest = None
        self.northeast = None
        self.southwest = None
        self.southeast = None

    def insert(self, point):

        if not self.boundary.contains(point):
            return False  # Point is outside the boundary of this node

        if len(self.points) < self.capacity:
            self.points.append(point)
            return True
        else:
            if not self.subdivided:
                self.subdivide()

            # Recursively insert the point into the appropriate quadrant
            if self.northwest.insert(point):
                return True
            if self.northeast.insert(point):
                return True
            if self.southwest.insert(point):
                return True
            if self.southeast.insert(point):
                return True

        return False

    def subdivide(self):
        x = self.boundary.x
        y = self.boundary.y
        w = self.boundary.w
        h = self.boundary.h

        nw = Boundary(x - w / 2, y - h / 2, w / 2, h / 2)
        ne = Boundary(x + w / 2, y - h / 2, w / 2, h / 2)
        sw = Boundary(x - w / 2, y + h / 2, w / 2, h / 2)
        se = Boundary(x + w / 2, y + h / 2, w / 2, h / 2)

        self.northwest = Quadtree(nw, self.capacity)
        self.northeast = Quadtree(ne, self.capacity)
        self.southwest = Quadtree(sw, self.capacity)
        self.southeast = Quadtree(se, self.capacity)

        # Redistribute points to children
        for point in self.points:
            if self.northwest.boundary.contains(point):
                self.northwest.insert(point)
            if self.northeast.boundary.contains(point):
                self.northeast.insert(point)
            if self.southwest.boundary.contains(point):
                self.southwest.insert(point)
            if self.southeast.boundary.contains(point):
                self.southeast.insert(point)

        self.points = []  # Clear the points from the current node

        self.subdivided = True

    def __subdivide(self):
        x = self.boundary.x
        y = self.boundary.y
        w = self.boundary.w
        h = self.boundary.h

        nw = Boundary(x - w / 2, y - h / 2, w / 2, h / 2)
        ne = Boundary(x + w / 2, y - h / 2, w / 2, h / 2)
        sw = Boundary(x - w / 2, y + h / 2, w / 2, h / 2)
        se = Boundary(x + w / 2, y + h / 2, w / 2, h / 2)

        self.northwest = Quadtree(nw, self.capacity)
        self.northeast = Quadtree(ne, self.capacity)
        self.southwest = Quadtree(sw, self.capacity)
        self.southeast = Quadtree(se, self.capacity)

        self.subdivided = True

        # Redistribute points to children
        points_to_redistribute = self.points.copy()
        self.points = []  # Clear the points from the current node
        for point in points_to_redistribute:
            self.insert(point)

    def draw(self):
        pygame.draw.rect(
            screen,
            BLACK,
            pygame.Rect(
                self.boundary.x - self.boundary.w,
                self.boundary.y - self.boundary.h,
                self.boundary.w * 2,
                self.boundary.h * 2,
            ),
            1,
        )
        for point in self.points:
            point.draw()

        if self.subdivided:
            self.northwest.draw()
            self.northeast.draw()
            self.southwest.draw()
            self.southeast.draw()

            # Output debug information for each sub-quad
            print("NW Quadrant:", len(self.northwest.points))
            print("NE Quadrant:", len(self.northeast.points))
            print("SW Quadrant:", len(self.southwest.points))
            print("SE Quadrant:", len(self.southeast.points))


# Main function
def main():
    quadtree = Quadtree(
        Boundary(
            SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2
        ),
        4,
    )

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    x, y = pygame.mouse.get_pos()
                    quadtree.insert(Point(x, y))

        screen.fill(WHITE)
        quadtree.draw()
        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
