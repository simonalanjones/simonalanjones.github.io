SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `url-shortener` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `url-shortener`;

DROP TABLE IF EXISTS `links`;
CREATE TABLE `links` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(15) DEFAULT NULL,
  `url` text,
  `visits` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `last_visited` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `visits`;
CREATE TABLE `visits` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(15) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `referer` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

