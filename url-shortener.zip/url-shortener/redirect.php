<?php

include_once('class.php');
$redirector = new UrlRedirector();
exit;
