<?php

/**
 * Base class for common functionality used in redirection and shortener classes
 */
abstract class UrlBase
{
    protected $db;
    protected $base_url;
    protected $subfolder;
    protected $config;

    public function __construct()
    {
        $this->load_config();
        $this->init_error_handling();
        $this->connect_db();
        $this->set_base_url();
    }

    protected function load_config(): void
    {
        require 'config.php';

        $this->config = [
            'dbhost' => $dbhost,
            'dbuser' => $dbuser,
            'dbpass' => $dbpass,
            'dbname' => $dbname,
            'random_chars' => $random_chars,
            'valid_chars' => $valid_chars,
            'slug_length' => $slug_length,
            'url_blank' => $url_blank,
            'url_not_found' => $url_not_found,
            'subfolder' => $subfolder,
        ];
    }

    protected function connect_db(): void
    {
        $dsn = "mysql:host={$this->config['dbhost']};dbname={$this->config['dbname']};charset=utf8mb4";
        try {
            $this->db = new PDO($dsn, $this->config['dbuser'], $this->config['dbpass']);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $this->error('Could not connect to database: ' . $e->getMessage());
        }
    }

    protected function init_error_handling(): void
    {
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
    }

    protected function error($message): void
    {
        throw new Exception($message);
    }

    protected function set_base_url(): void
    {
        $this->subfolder = $this->config['subfolder'];
        $s = empty($_SERVER['HTTPS']) ? '' : ($_SERVER['HTTPS'] == 'on' ? 's' : '');
        $this->base_url = "http$s://" . $_SERVER['HTTP_HOST'] . $this->subfolder . '/';
    }

    protected function validate_slug(string $slug): bool
    {
        $valid_chars = preg_quote($this->config['valid_chars'], '/');
        return preg_match("/^[{$valid_chars}]+$/", $slug);
    }

    protected function validate_url(string $url)
    {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }

    protected function sanitize_url(string $url)
    {
        return filter_var($url, FILTER_SANITIZE_URL);
    }
}

/**
 * Class for handling redirection from slug to long URL.
 */
class UrlRedirector extends UrlBase
{
    public function __construct()
    {
        parent::__construct();
        $this->handle_redirect();
    }

    private function handle_redirect(): void
    {
        $request_uri = $_SERVER['REQUEST_URI'];
        $slug = trim(str_replace($this->subfolder, '', $request_uri), '/');

        if ($this->validate_slug($slug)) {
            $this->process_slug($slug);
        } else {
            $this->error('Slug invalid');
        }
    }

    /**
     * Log the visit using the slug
     *
     * @param string $slug
     * @param ?string $referer
     * @return void
     */
    private function log_visit(string $slug, ?string $referer = null): void
    {
        // Update the visits count and last_visited in the links table
        $stmt = $this->db->prepare("UPDATE links SET visits = visits + 1, last_visited = NOW() WHERE slug = :slug");
        $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
        $stmt->execute();

        // Insert a new visit record in the visits table
        $stmt = $this->db->prepare("INSERT INTO visits (slug, visit_date, referer) VALUES (:slug, NOW(), :referer)");
        $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
        $stmt->bindParam(':referer', $referer, PDO::PARAM_STR);
        $stmt->execute();
    }


    /**
     * Look up slug and redirect to long URL if found
     *
     * @param string $slug
     * @return void
     */
    private function process_slug(string $slug): void
    {
        $stmt = $this->db->prepare("SELECT url FROM links WHERE slug = :slug");
        $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            $this->error('Slug not found');
        }

        $url = $row['url'];

        $referer = $_SERVER['HTTP_REFERER'] ?? null;
        $this->log_visit($slug, $referer);

        header('Location: ' . $url);
        exit;
    }
}


/**
 * Class for shortening a long URL to a slug
 */
class UrlShortener extends UrlBase
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Main entry point for this class
     *
     * @param string|null $url_to_shorten
     * @return string
     */
    public function shorten(string $url_to_shorten = null): string
    {
        if ($url_to_shorten !== null && $this->validate_url($url_to_shorten)) {

            $sanitized_url = $this->sanitize_url($url_to_shorten);

            if ($sanitized_url !== false) {
                return $this->create_link($sanitized_url);
            } else {
                $this->error('URL could not be sanitized');
            }
        } else {
            $this->error('No valid URL provided');
        }
    }


    /**
     * Generate a unique slug. Repeat the function if the generated slug already exists.
     *
     * @param integer $length
     * @param string $chars
     * @return string
     */
    private function generate_unique_slug(int $length, string $chars): string
    {
        do {
            $slug = '';
            for ($i = 0; $i < $length; $i++) {
                $slug .= $chars[rand(0, strlen($chars) - 1)];
            }

            $stmt = $this->db->prepare("SELECT COUNT(*) FROM links WHERE slug = :slug");
            $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
            $stmt->execute();
            $count = $stmt->fetchColumn();
        } while ($count > 0);

        return $slug;
    }


    /**
     * Return a randomly generated slug and save to DB
     *
     * @param string $url_to_shorten
     * @return string|null
     */
    private function create_link(string $url_to_shorten): ?string
    {
        // check if the slug already exists for a given url
        $stmt = $this->db->prepare("SELECT slug FROM links WHERE url = :url LIMIT 1");
        $stmt->bindParam(':url', $url_to_shorten, PDO::PARAM_STR);
        $stmt->execute();
        $existingSlug = $stmt->fetchColumn();

        if ($existingSlug) {
            return $this->base_url . $existingSlug;
        }

        $slug_length = $this->config['slug_length'];
        $random_chars = $this->config['random_chars'];

        $slug = $this->generate_unique_slug($slug_length, $random_chars);

        if ($slug_length > 0) {

            $stmt = $this->db->prepare("INSERT INTO links (slug, url, visits, created) VALUES (:slug, :url, 0, NOW())");
            $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
            $stmt->bindParam(':url', $url_to_shorten, PDO::PARAM_STR);
            $stmt->execute();

            return $this->base_url . $slug;
        } else {
            $this->error('Slug length must be greater than 0');
        }
    }
}
