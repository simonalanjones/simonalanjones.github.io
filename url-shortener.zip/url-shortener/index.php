<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Handle CORS preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

include "class.php";

// Get the JSON input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Validate JSON payload and URL parameter
if ($data === null || empty($data['url']) || !filter_var($data['url'], FILTER_VALIDATE_URL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON payload or missing/invalid URL parameter']);
    exit;
}

$url = filter_var($data['url'], FILTER_SANITIZE_URL);

$shortener = new UrlShortener();

try {
    $short_url = $shortener->shorten($url);
    echo json_encode(['success' => true, 'shortUrl' => $short_url]);
} catch (Exception $e) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
exit;
